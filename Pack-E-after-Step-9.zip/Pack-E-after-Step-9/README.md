# Pack E: after Step 9 (Epic/Feature proposal)

> **Optional reference in the lighter workshop format.** Everyone loads **Pack A** after the research walkthrough and **Pack D** after the prototype test. You don't need Pack E for the main flow. Use it to look at the reference run's files, or to replay the full workshop later on your own. This pack uses the older layout: its files sit in a hidden `.copilot-tracking` folder inside `repo-files/`, so it isn't loaded by drag-and-drop. To read it, just open the unzipped folder; to replay it, use the Terminal commands below.

**Use when:** your pair doesn't have an Epic/Feature proposal by the end of Step 9. Review this proposal, then do **Step 10 (Final review)**. Step 10 doesn't use an agent.

**How it was made:** a facilitator ran the workshop on the current `main` branch with the real agents (HVE Core plugin v3.2.2, Copilot CLI):
- **DT Coach**, Steps 1–6;
- **BRD Builder**, Step 7;
- **PRD Builder**, Step 8;
- a **new PRD Builder chat** for Step 9, as `STEP-09-BACKLOG.md` asks.

Answers came from the persona and decision card. Every file is agent-generated except `workshop-output/prototype-self-test.md`, which the pair writes.

This pack is cumulative. It includes everything from Packs A–D.

## What's inside

> **`repo-files/` looks empty? It isn't.** Some files are inside a hidden folder named `.copilot-tracking`. To see it:
> - **Mac:** press **Cmd+Shift+.**
> - **Windows:** it's normally visible already. If not, choose **View > Show > Hidden items**.
> - **Easiest:** paste the copy command below into **VS Code → Terminal → New Terminal**. It opens at your repo root and copies hidden folders too.
>
> See also `repo-files/READ-ME-FIRST.txt`.

All files go under `repo-files/` in the same paths they need in your repo. Paths starting with `.copilot-tracking/` are inside the hidden folder.

| File | What it is |
|---|---|
| `docs/project-planning/portfolio-tracker-epic-feature-proposal.md` | **The Epic/Feature proposal**, planning only: 3 outcome Epics and 12 capability Features. Each Feature traces to one FR and, through it, to one BR. Each Feature is marked **conditional on** its inherited gates, all Open. It has no Stories, Tasks, estimates or architecture. |
| `docs/project-planning/portfolio-tracker.md` | The approved PRD, v1.0.0. **Step 9 didn't change it**: its SHA-256 is the same before and after Step 9. |
| `docs/project-planning/portfolio-tracker-brd*.md`, `.copilot-tracking/brd-sessions/…`, `.copilot-tracking/prd-sessions/…` | The approved BRD and handoffs (Pack C), plus the PRD session and quality records (Pack D) |
| `.copilot-tracking/dt/portfolio-tracker/…`, `workshop-output/prototype-self-test.md` | DT state, Methods 1–6, the DT→BRD handoff and the self-test (Pack B) |

### Epics → Features → FR → BR (gates are all Open)

| Epic (outcome) | Feature (capability) | Traces to | Conditional on |
|---|---|---|---|
| EPIC-001 Sustainable factual portfolio upkeep | FEAT-001 Attributable starting-position review | FR-001 → BR-001 | GATE-003, 005, 007 |
| | FEAT-004 Reviewed import maintenance | FR-004 → BR-004 | GATE-003, 005, 007 |
| | FEAT-005 Occasional manual maintenance fallback | FR-005 → BR-005 | GATE-003, 005, 007 |
| EPIC-002 Understandable holdings, valuation and limits | FEAT-002 Consolidated holdings orientation | FR-002 → BR-002 | GATE-001, 003, 004, 005, 007 |
| | FEAT-003 Bounded factual history inspection | FR-003 → BR-003 | GATE-003, 004, 005, 007 |
| | FEAT-006 Sourced price and FX updates | FR-006 → BR-006 | GATE-001, 004, 005, 007 |
| | FEAT-007 On-demand valuation provenance inspection | FR-007 → BR-007 | GATE-001, 004, 005, 007 |
| | FEAT-008 Explicit uncertainty and consistent overview status | FR-008 → BR-008 | GATE-004, 005, 006, 007 |
| EPIC-003 Evidence-appropriate recovery without false historical certainty | FEAT-009 Conflict, cause and consequence review | FR-009 → BR-009 | GATE-002, 003, 005, 007 |
| | FEAT-010 Evidence-backed known-cause recovery | FR-010 → BR-010 | GATE-002, 003, 004, 005, 007 |
| | FEAT-011 Current-only unknown-cause verification | FR-011 → BR-011 | GATE-002, 003, 005, 007 |
| | FEAT-012 Recovery consequence continuity | FR-012 → BR-012 | GATE-002, 003, 004, 005, 007 |

**Gates:**

| Gate | Topic |
|---|---|
| GATE-001 | FX/price provider and licensing |
| GATE-002 | Representative-user validation of the Iteration 2 recovery |
| GATE-003 | Import and financial methodology |
| GATE-004 | Valuation/FX timing and uncertainty |
| GATE-005 | Outcome measurement |
| GATE-006 | Overview trust-status consistency (self-test origin) |
| GATE-007 | Viability |

**Kept out of the proposal:**
- **Excluded:** trading, advice, forecasts, tax reporting, goal tracking and real personal data.
- **Deferred alternatives:** composition breakdown and FX on the main screen.
- **Not committed:** gain/loss and cost-basis views.
- **Dropped:** silent overwrite.

## Full file list (copy into your repo root, same paths)

```text
.copilot-tracking/brd-sessions/portfolio-tracker.govern-quality-report.yml
.copilot-tracking/brd-sessions/portfolio-tracker.govern-standard-findings.yml
.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml
.copilot-tracking/brd-sessions/portfolio-tracker.quality-report.yml
.copilot-tracking/brd-sessions/portfolio-tracker.standard-findings.yml
.copilot-tracking/brd-sessions/portfolio-tracker.state.json
.copilot-tracking/dt/portfolio-tracker/coaching-state.md
.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-01-scope-notes.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/findings-summary.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/research-plan.md
.copilot-tracking/dt/portfolio-tracker/method-03-synthesis/synthesis.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/divergent-ideas.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-notes.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-plan.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/theme-clusters.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concept-comparison.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concepts.yml
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/method-06-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/our-concept.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/constraint-discoveries.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-01-learning.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-02-learning.md
.copilot-tracking/prd-sessions/portfolio-tracker.finalize-quality-report.yml
.copilot-tracking/prd-sessions/portfolio-tracker.finalize-standard-findings.yml
.copilot-tracking/prd-sessions/portfolio-tracker.quality-report.yml
.copilot-tracking/prd-sessions/portfolio-tracker.standard-findings.yml
.copilot-tracking/prd-sessions/portfolio-tracker.state.json
docs/project-planning/portfolio-tracker-brd-to-prd-handoff.md
docs/project-planning/portfolio-tracker-brd-v0.1.0.md
docs/project-planning/portfolio-tracker-brd.md
docs/project-planning/portfolio-tracker-epic-feature-proposal.md
docs/project-planning/portfolio-tracker.md
workshop-output/prototype-self-test.md
```

## Copy the files into your repo

**Heads-up:** the `.copilot-tracking` folder inside `repo-files/` is hidden. On Mac, show it with **Cmd+Shift+.**. On Windows it's normally visible (if not, use **View > Show > Hidden items**). Or use the Terminal command below, run in **VS Code → Terminal → New Terminal**, which copies it for you.

1. Download `Pack-E-after-Step-9.zip` from https://github.com/costastselios/hve-core-workshop-pm-tpm-design-thinking-lite/raw/main/Pack-E-after-Step-9.zip (also posted in the workshop Teams channel) and unzip it.
   - **Windows:** right-click the zip → **Extract All…** → **Extract**, and keep the suggested folder in `Downloads`. The Windows command below finds the pack even if Extract All creates a doubled folder (`…\Pack-E-after-Step-9\Pack-E-after-Step-9\repo-files`).
2. Copy everything **inside** `repo-files/` into the **root** of your workshop clone. You should end up with:
   ```text
   docs/project-planning/portfolio-tracker-epic-feature-proposal.md
   ```
   - **Easiest:** in VS Code, open **Terminal → New Terminal**. It opens at your repo root. Paste the macOS or Windows command below. It merges the files into your repo and doesn't delete anything.
   - ⚠️ **Don't drag `docs`, `.copilot-tracking` or `workshop-output` onto your repo's folders of the same name.** If VS Code asks whether to **Replace** a *folder*, choose **Cancel**: Replace deletes the existing folder first, including the workshop's own docs.
   - **macOS Terminal**, from your repo root: `cp -R ~/Downloads/Pack-E-after-Step-9/repo-files/. .`
   - **Windows (PowerShell, the VS Code default)**, from your repo root: paste this single line. It finds the unzipped pack under `Downloads`, merges everything from `repo-files` into your repo (never deletes; skips `READ-ME-FIRST.txt`), and prints `OK - copied from …`. If the terminal prompt doesn't start with `PS`, it's cmd.exe: type `powershell`, press Enter, then paste.
     ```powershell
     $pack='Pack-E-after-Step-9'; $src=(Get-ChildItem "$HOME\Downloads" -Directory -Recurse -Depth 3 -Filter repo-files -ErrorAction SilentlyContinue | Where-Object FullName -like "*$pack*" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName; if (-not (Test-Path workshop)) { 'STOP: run this in the VS Code terminal of your workshop repo (the folder with docs, workshop, workshop-output)' } elseif (-not $src) { "STOP: $pack not found under $HOME\Downloads - unzip the pack there first" } else { robocopy "$src" . /XF READ-ME-FIRST.txt /E /NFL /NDL /NJH /NJS /NP; if ($LASTEXITCODE -lt 8) { "OK - copied from $src" } else { "ERROR: robocopy exit code $LASTEXITCODE" } }
     ```
   - The macOS command also copies `READ-ME-FIRST.txt` into your repo; delete it from your repo root afterwards. The Windows command skips it.
3. Rename any of your own files with the same names first, for example by adding `-ours`.

## Step 9: review (if you're catching up)
Check the proposal against `docs/WORKED-EXAMPLES.md` and the Backlog section of `docs/ARTIFACT-CHECKLIST.md`:
- Are the Epics outcomes and the Features capabilities?
- Does every Feature trace to a PRD FR?
- Is deferred scope left out?
- Is every gated Feature conditional?
- Are there no Stories or Tasks?

## Continue with Step 10: final review (no agent)

Open `workshop/05-common/STEP-10-REVIEW.md`. Using the files above, create `workshop-output/WORKSHOP-CONFIDENCE.md` with these five headings, and write it yourselves:

```markdown
# Workshop Confidence
## Evidenced
## Decided
## Gated
## Unvalidated
## First gate to resolve
```

Hints, without giving the answers away:
- **Evidenced:** only the two participant summaries and the Iteration 1 test finding, all low confidence.
- **Decided:** look for "Decision (not evidence)" labels, for example AED, import-first, adopting Iteration 2, and the waivers.
- **Gated:** reference the GATE-00x records.
- **Unvalidated:** Iteration 2 must appear here.
