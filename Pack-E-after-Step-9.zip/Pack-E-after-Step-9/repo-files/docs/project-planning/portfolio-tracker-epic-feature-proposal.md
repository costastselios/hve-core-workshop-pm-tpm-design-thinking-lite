# Portfolio Tracker Epic/Feature Proposal

## Authority and planning limits

**Status:** Proposed; planning only. **Date:** 2026-11-17.
**Accountable owner:** Workshop Product Owner (requesting user; STK-002).

Source: [Portfolio Tracker PRD](portfolio-tracker.md), **PRD-2026-Q4-001
v1.0.0, Approved**, approved as the workshop product planning baseline for
Epic/Feature decomposition only. This proposal uses that baseline and the
[Worked Examples](../WORKED-EXAMPLES.md) and
[Artifact Checklist](../ARTIFACT-CHECKLIST.md), not earlier conversation.
FR and BR numbering below comes from the approved PRD, not the illustrative
numbering in the Worked Examples. BR references retain the PRD's mapping to
BRD-2026-Q4-001 v1.0.0; this is not a new business-scope interpretation.

**Decision (not evidence):** Group the twelve approved FR capabilities into
three intended outcome Epics and twelve capability Features. Proposal IDs are
local document references, not tracker items. Numbering is not sequencing.
No release allocation, first-release subset, estimates, architecture, Stories,
Tasks, RPI, code, tracker upload or Functional Planner handoff is proposed.
The approved PRD is unchanged; no new PRD is created.

All Features remain **conditional**, including baseline-wide GATE-005 and
GATE-007. Every gate remains **Open** and all inherited acceptance remains
**Not Started**. PRD MUST priority is retained within the conditional planning
scope, not promoted into delivery readiness, funding or engineering authorization.
The owner of every proposed Epic and Feature is STK-002; the intended beneficiary
is the self-directed multi-broker investor, STK-001.

Evidence confidence is unchanged: supplied participant summaries are
low-confidence directional signals; Iteration 1 completion did not establish
comprehension; Iteration 2 remains an **unvalidated redesign hypothesis** with
PO self-test only. Neither decomposition nor baseline approval validates demand,
financial correctness, recovery comprehension or viability.

## Outcome Epics

These are intended user outcomes, not validated benefits or measurable commitments.
All inherit the Open gates of their child Features.

| Epic | Intended outcome | Goal trace | Child Features |
| --- | --- | --- | --- |
| EPIC-001: Sustainable factual portfolio upkeep | The investor can establish and maintain an attributable cross-broker record without unacceptable repetitive re-entry, while retaining control over accepted changes. | GOAL-001 -> BG-001; establishment also supports GOAL-002 -> BG-002. | FEAT-001, FEAT-004, FEAT-005 |
| EPIC-002: Understandable holdings, valuation and limits | The investor can explain what is held, where, its factual dated value and basis, and what remains uncertain without mistaking partial information for certainty. | GOAL-002 -> BG-002; bounded history and uncertainty also support GOAL-003 -> BG-003; sourced updates also support GOAL-001 -> BG-001. | FEAT-002, FEAT-003, FEAT-006, FEAT-007, FEAT-008 |
| EPIC-003: Evidence-appropriate recovery without false historical certainty | The investor can judge recovery consequences and later distinguish current verification from known historical activity and unresolved history. | GOAL-003 -> BG-003; consequence continuity also supports GOAL-002 -> BG-002. | FEAT-009, FEAT-010, FEAT-011, FEAT-012 |

GOAL-001, GOAL-002 and GOAL-003 retain **SMART FAIL**. Candidate signals remain
maintenance effort, factual explanation and recovery comprehension respectively;
their protocols, baselines, targets and evaluation dates are not established.
No improvement claim or numeric outcome target is added.

WVR-001 remains BRD-planning-only. Separate WVR-PRD-001 covers the three
non-SMART product goals for this workshop planning baseline and decomposition
only. Neither waiver is enlarged or renewed here. Their event-based expiry at
the GATE-005 next decision trigger or before any outcome-performance commitment,
whichever occurs first, is preserved; no performance commitment is made here.

## Capability Features

Each Feature maps to exactly one approved FR and, through it, its source BR.
The full inherited gate set is repeated on each row so extraction cannot lose
GATE-005 or GATE-007. **Every listed gate has status Open.** AC references point
to the PRD's existing boundaries, not new criteria or completed acceptance.

### EPIC-001: Sustainable factual portfolio upkeep

| Feature | Capability and retained boundary | PRD -> BRD trace | Inherited acceptance | Conditional status |
| --- | --- | --- | --- | --- |
| FEAT-001: Attributable starting-position review | Review a synthetic starting-position proposal with broker/source, evidence date, asset, units, currency and missing/unsupported fields. Establish the baseline only after explicit confirmation; cancellation accepts nothing. Do not assert pre-baseline transaction history. | FR-001 -> BR-001 | AC-001, AC-002; Not Started | conditional on GATE-003, GATE-005, GATE-007 (all Open) |
| FEAT-004: Reviewed import maintenance | Review proposed update-file changes and included/excluded/unresolved dispositions for ready, possible-duplicate, conflicting and unsupported records. Only the explicitly confirmed accepted set changes the record; unresolved records are not silently accepted and cancellation applies nothing. | FR-004 -> BR-004 | AC-005, AC-006; Not Started | conditional on GATE-003, GATE-005, GATE-007 (all Open) |
| FEAT-005: Occasional manual maintenance fallback | Review a dated, source/manual-labelled change and its intended effect when import is unavailable or occasional manual maintenance is chosen. Explicit confirmation is required; cancellation or non-confirmation changes no accepted information. This is not an entirely manual operating baseline. | FR-005 -> BR-005 | AC-007; Not Started | conditional on GATE-003, GATE-005, GATE-007 (all Open) |

### EPIC-002: Understandable holdings, valuation and limits

| Feature | Capability and retained boundary | PRD -> BRD trace | Inherited acceptance | Conditional status |
| --- | --- | --- | --- | --- |
| FEAT-002: Consolidated holdings orientation | Inspect holdings with broker, asset type, native currency and dated AED valuation or explicit unvalued state. Label any total with excluded holdings partial and make exclusions identifiable. The fictional three-broker stock/ETF/crypto scenario is not a coverage commitment. | FR-002 -> BR-002 | AC-003; Not Started | conditional on GATE-001, GATE-003, GATE-004, GATE-005, GATE-007 (all Open) |
| FEAT-003: Bounded factual history inspection | Distinguish attributable dated facts, corrections and unsupported intervals. Do not invent pre-baseline activity, imply complete history or provide forecasts. | FR-003 -> BR-003 | AC-004; Not Started | conditional on GATE-003, GATE-004, GATE-005, GATE-007 (all Open) |
| FEAT-006: Sourced price and FX updates | Request available attributable price/FX inputs within approved coverage without re-keying every price/rate. Preserve source/effective-time context; identify missing or unsupported inputs as unavailable, not invented values or fulfilled automation. No provider or connection method is selected. | FR-006 -> BR-006 | AC-008; Not Started | conditional on GATE-001, GATE-004, GATE-005, GATE-007 (all Open) |
| FEAT-007: On-demand valuation provenance inspection | Inspect position basis, price source/effective time, applicable FX source/effective time/rate direction, reporting currency and calculation basis, with explicit unavailable/non-applicable states. On-demand inspection remains the baseline, not main-screen FX. | FR-007 -> BR-007 | AC-009; Not Started | conditional on GATE-001, GATE-004, GATE-005, GATE-007 (all Open) |
| FEAT-008: Explicit uncertainty and consistent overview status | See affected holding values and summaries qualified when inputs/history are stale, missing, disputed or incomplete. Fresh prices must not imply verified positions or complete history. Exact timing policy and status vocabulary remain unresolved; the overview concern retains its self-test-only origin. | FR-008 -> BR-008 | AC-010, AC-011; Not Started | conditional on GATE-004, GATE-005, GATE-006, GATE-007 (all Open) |

### EPIC-003: Evidence-appropriate recovery without false historical certainty

| Feature | Capability and retained boundary | PRD -> BRD trace | Inherited acceptance | Conditional status |
| --- | --- | --- | --- | --- |
| FEAT-009: Conflict, cause and consequence review | Inspect conflicting evidence and current/history implications before a known/unknown-cause choice. Review the selected branch's changes, non-changes and remaining uncertainty before confirmation; either branch can be cancelled without applying changes. | FR-009 -> BR-009 | AC-012, AC-013; Not Started | conditional on GATE-002, GATE-003, GATE-005, GATE-007 (all Open) |
| FEAT-010: Evidence-backed known-cause recovery | Record evidenced missing activity after confirmation of its preview and recalculate only affected history under the agreed methodology. A quantity difference alone does not establish cause; unrelated facts and other unresolved uncertainty remain unchanged. | FR-010 -> BR-010 | AC-014; Not Started | conditional on GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 (all Open) |
| FEAT-011: Current-only unknown-cause verification | Confirm a preview to record dated, attributable evidence of today's position when its cause is unknown. Historical transactions remain unchanged; no invented explanatory activity or claim of historical completeness follows from current verification. | FR-011 -> BR-011 | AC-015; Not Started | conditional on GATE-002, GATE-003, GATE-005, GATE-007 (all Open) |
| FEAT-012: Recovery consequence continuity | Inspect recovery results and later holding/history views with current verification, historical changes/non-changes and unresolved history distinguished. Preserve suspected mistaken-cause assertions and affected-history evidence for a governed correction decision, not as proven facts. Unknown-cause verification does not verify historical gain/loss or cost basis; no such analytics view is added. | FR-012 -> BR-012 | AC-016, AC-017; Not Started | conditional on GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 (all Open) |

**Authored coverage:** 12/12 approved FRs and their 12/12 BR parents are represented,
each once, with all 17 inherited AC references retained. This is proposal
traceability, not execution coverage, test success or gate-exit evidence.

## Inherited quality and scope boundaries

All Features retain CON-001 through CON-003 and RULE-001 through RULE-003:
facts stay attributable or explicitly unsupported; today's position does not
prove historical activity/completeness; proposed changes require review and
explicit confirmation. Only safe synthetic/non-identifying material is permitted.

The PRD's quality obligations remain constraints, not extra Features:

| Inherited obligation | Retained meaning and relevant Features |
| --- | --- |
| NFR-001: Reconciliation or explicit uncertainty | Agreed synthetic valuation/import/recovery cases must reconcile to independently reviewed expected results or show documented unsupported/uncertain states; no unexplained difference is represented as verified. Retain the PRD mappings to FR-002/004/006/007/010/011, hence FEAT-002/004/006/007/010/011. Precision, rounding and tolerances remain GATE-003/004 decisions. |
| NFR-002: Recovery-comprehension evidence boundary | FEAT-009 through FEAT-012 cannot be claimed validated from completion or PO self-test. The inherited future validation boundary covers conflict/cause interpretation, branch choice, prediction, explanation and later interpretation for known, unknown and mistaken causes. No research is initiated by this proposal. |
| NFR-003: Historical preservation during unknown-cause recovery | FEAT-011/012 retain unchanged historical transactions and visible unresolved history on later review. The inherited future acceptance boundary requires before/after factual comparison and observed outcomes, not fixed-data confirmation screens. |

| Disposition | Scope kept outside the proposed Features |
| --- | --- |
| Excluded, not later-release candidates | Trading/order execution; advice/recommendations; forecasts; tax reporting; goal tracking; real personal financial data. Factual recorded buys/sells are history, not execution. |
| Deferred alternatives, no Feature or delivery allocation | Composition breakdown; main-screen FX source/as-of. Re-entry requires the explicit PO scope decision described in the PRD under GATE-005, with applicable GATE-001/004 limits preserved for FX. |
| Unselected alternatives | Fully connected/import-only operation; entirely manual operation. Import-first with occasional manual fallback remains the baseline. |
| Not committed | Gain/loss or cost-basis views; no new analytics or tax scope follows from discussing recovery limitations. |
| Dropped, not deferred | Silent overwrite of historical transactions to match today's position. Unknown cause never authorizes invented history. |

USD/EUR/AED inputs, AED reporting, three brokers, stocks, ETFs and some crypto
remain fictional scenario choices, not validated segment or support commitments.
No market-size, adoption, payment, outcome-performance, service-level or
financial-return claim is introduced.

## Inherited Open gates

These records carry the PRD's gate meaning, owner, evidence boundary and trigger
forward, with proposal Feature references added. The
[PRD gate register](portfolio-tracker.md#dependency-and-validation-gate-register)
remains authoritative for the complete inherited wording. No gate is closed,
waived or assigned new exit evidence by this proposal.

### GATE-001

- **Gate ID:** GATE-001.
- **Title:** Price/FX provider coverage and licensing.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; availability and rights not committed.
- **Affected requirements/features:** FR-002 -> BR-002 / FEAT-002; FR-006 -> BR-006 / FEAT-006; FR-007 -> BR-007 / FEAT-007; inherited NFR-001.
- **Exit evidence:** Dated provider/terms references; agreed asset/currency/date coverage matrix; permitted use/display/retention and relevant redistribution; access/rate limits, costs and explicit gaps; PO-recorded scope/rights decision with specialist review where needed.
- **Next decision trigger:** Before committing provider-dependent valuation/automation Features for engineering planning or claiming their coverage.
- **Remaining uncertainty:** Whether needed price/FX evidence can be obtained, used and retained at acceptable cost/frequency; no provider selected or rights verified.

### GATE-002

- **Gate ID:** GATE-002.
- **Title:** Representative-user validation of Iteration 2 recovery.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; redesign hypothesis, self-test only.
- **Affected requirements/features:** FR-009 through FR-012 -> BR-009 through BR-012 / FEAT-009 through FEAT-012; inherited NFR-002.
- **Exit evidence:** PO-approved protocol, participant/context rationale, consent and safe synthetic tasks; criteria and evaluation date agreed before testing; source-located conflict/cause/branch observations, pre-action prediction, post-action explanation, mistaken-cause recovery and later uncertain-history interpretation; failures/limits and PO disposition. Completion and PO self-test cannot substitute.
- **Next decision trigger:** Before claiming recovery comprehension validated or committing its dependent workflow as validated for engineering planning.
- **Remaining uncertainty:** Whether non-author representative users distinguish present from history, recognize unknown/mistaken cause and retain the correct uncertainty model later.

### GATE-003

- **Gate ID:** GATE-003.
- **Title:** Import/baseline coverage and financial methodology.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; support boundaries and correction rules unverified.
- **Affected requirements/features:** FR-001/002/003/004/005/009/010/011/012 -> same-numbered BR parents and FEAT-001/002/003/004/005/009/010/011/012; inherited NFR-001/003.
- **Exit evidence:** Reviewed statement/history/format support matrix; synthetic expected-result cases for fractions, duplicate/uncertain imports, fees, corporate actions, baseline-history gaps, unsupported assets/formats, known/unknown cause and mistaken-cause correction; agreed correction/reversal procedure and relevant gain/loss/cost-basis limitations without tax scope; appropriate financial expertise and PO decision.
- **Next decision trigger:** Before accepting import/history/recovery behavior as financially correct or committing dependent Features for engineering planning.
- **Remaining uncertainty:** Statement sufficiency, history availability, asset/format variation, duplicate/corporate-action logic, financial calculation rules and safe mistaken-cause correction.

### GATE-004

- **Gate ID:** GATE-004.
- **Title:** Valuation/FX meaning, timing and uncertainty.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no agreed timing/precision/freshness policy.
- **Affected requirements/features:** FR-002/003/006/007/008/010/012 -> same-numbered BR parents and FEAT-002/003/006/007/008/010/012; inherited NFR-001.
- **Exit evidence:** PO-approved definitions and reviewed synthetic cases for completed-market price basis, cutoffs/timezones and crypto timing; price versus FX effective time, rate direction, precision/rounding/tolerances, stale/missing policy, partial totals and current/history uncertainty propagation; explicit provenance availability and unresolved exceptions.
- **Next decision trigger:** Before claiming current/complete/correct AED valuations or committing valuation/history behavior for engineering planning.
- **Remaining uncertainty:** Meaningful and sourceable timing/FX policies, and how incomplete inputs and uncertain history constrain factual values.

### GATE-005

- **Gate ID:** GATE-005.
- **Title:** Outcome measurement and broader-context coverage.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; goals remain SMART FAIL; workshop-only WVR-001 and separate WVR-PRD-001 do not establish prevalence or measured benefit.
- **Affected requirements/features:** FR-001 through FR-012 -> BR-001 through BR-012 / all twelve Features; inherited NFR-002; GOAL-001/002/003 -> BG-001/002/003. Any proposed composition/main-screen-FX addition remains outside this proposal.
- **Exit evidence:** PO-approved operational measures, safe baseline source/data, meaningful targets, dates and decision criteria for maintenance effort and factual/recovery understanding; documented user/context/accessibility coverage and adjacent-role disposition; remaining generalizability limits. No prevalence/market-growth claim without appropriate separate evidence.
- **Next decision trigger:** Before adopting outcome-performance commitments, claiming broader demand/benefit or approving expanded user/context scope.
- **Remaining uncertainty:** Magnitude, baseline effort, achievable improvement, representative contexts, adjacent roles and value of retained alternatives.

### GATE-006

- **Gate ID:** GATE-006.
- **Title:** Overview trust-status consistency.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; self-test concern, no participant finding or verified fix.
- **Affected requirements/features:** FR-008 -> BR-008 / FEAT-008; inherited AC-011.
- **Exit evidence:** PO decision separating price freshness, position verification and historical completeness; synthetic mismatch/fresh-price/uncertain-history cases showing qualified overview status and links to affected holdings; source-located comprehension observations and failure dispositions, preserving self-test-only origin.
- **Next decision trigger:** Before accepting overview status semantics or claiming the reported inconsistency resolved.
- **Remaining uncertainty:** Appropriate summary vocabulary/aggregation and whether users interpret it correctly while unresolved exceptions remain.

### GATE-007

- **Gate ID:** GATE-007.
- **Title:** Viability, support burden and operating assumptions.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no viable operating model established.
- **Affected requirements/features:** FR-001 through FR-012 -> BR-001 through BR-012 / all twelve Features; GOAL-001/002/003 -> BG-001/002/003; continued investment in the proposed baseline.
- **Exit evidence:** Documented provider/import/correction support costs and assumptions; operating/support responsibilities and capacity; non-sensitive adoption/payment evidence appropriate to the intended model; PO-recorded proceed/revise/stop decision with explicit remaining limits.
- **Next decision trigger:** Before treating this baseline as an investable business case, making operational commitments or authorizing engineering expenditure.
- **Remaining uncertainty:** Coverage/licensing economics, ongoing reconciliation/support effort, adoption/payment and who can sustain operation; no budget or service promise inferred.

This file is the proposal only. It neither initiates gate work nor constitutes
approval of these proposed groupings, a tracker-ready handoff, financial
validation or engineering authorization.
