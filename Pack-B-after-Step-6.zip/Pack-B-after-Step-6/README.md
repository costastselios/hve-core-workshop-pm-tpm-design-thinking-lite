# Pack B: after Step 6 (Prototype learning and DT→BRD handoff)

> **Optional reference in the lighter workshop format.** Everyone loads **Pack A** after the research walkthrough and **Pack D** after the prototype test. You don't need Pack B for the main flow. Use it to look at the reference run's files, or to replay the full workshop later on your own. This pack uses the older layout: its files sit in a hidden `.copilot-tracking` folder inside `repo-files/`, so it isn't loaded by drag-and-drop. To read it, just open the unzipped folder; to replay it, use the Terminal commands below.

**Use when:** your pair hasn't finished Step 6 by the end of the prototype step. After the prototype regroup, start **Step 7 (BRD)** with **BRD Builder** from this saved state.

**How it was made:** a facilitator ran the workshop on the current `main` branch using the real **DT Coach** agent (HVE Core plugin v3.2.2, Copilot CLI). Answers came from the persona and decision card.
- **Agent-generated:** all `.copilot-tracking/...` files, including the DT→BRD handoff.
- **Written by the pair (facilitator acting as the pair):** `workshop-output/prototype-self-test.md`, written after clicking through both prototypes end to end in a browser. This is normal: the step asks *you* to write your self-test notes.

This pack is cumulative. It includes everything from Pack A.

## What's inside

> **`repo-files/` looks empty? It isn't.** The files are inside a hidden folder named `.copilot-tracking`. On Mac, show it with **Cmd+Shift+.**. On Windows it's normally visible (if not, use **View > Show > Hidden items**). Or skip Finder entirely: paste the copy command below into **VS Code → Terminal → New Terminal**, which opens at your repo root and copies hidden folders too. See also `repo-files/READ-ME-FIRST.txt`.

All files go under `repo-files/` in the same paths they need in your repo. Every path that starts with `.copilot-tracking/` is inside the hidden folder.

| File | What it is |
|---|---|
| `.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md` | **The DT→BRD handoff.** You attach this in Step 7. It covers M1–M6, P01 and P02 evidence kept separate with low confidence, the canonical concept, recorded differences, the recovery failure, the Iteration 2 hypothesis, the validation gap, and candidate gates. |
| `.copilot-tracking/dt/portfolio-tracker/coaching-state.md` | DT Coach state. Methods 2–6 are complete for the workshop. Method 1 was handed forward provisionally, which is expected. |
| `.copilot-tracking/dt/portfolio-tracker/method-01…03…` | Scope, research protocol and evidence register, and synthesis (the same files as in Pack A) |
| `.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/` | 16 divergent ideas, then mapped onto the 3 shared directions. Parked ideas are kept, not deleted. |
| `.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/` | The pair's own concept, the comparison with the canonical snapshot (differences recorded as decision, alternative or open question), and the canonical baseline adopted for Method 6 |
| `.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/` | Iteration 1 learning (concept-comprehension failure), Iteration 2 learning (redesign hypothesis, not validated), and constraint discoveries |
| `workshop-output/prototype-self-test.md` | **Completed self-test.** It covers Iteration 1 end to end, the prediction made before clicking, both Iteration 2 branches, and a final comparison. It's kept separate from the supplied participant evidence. |

**Where this pair landed:**
- Recovery in Iteration 1 is a **concept failure**, not a wording problem. It doesn't separate *today's holding* from *history*.
- Iteration 2 is adopted as the concept baseline by **Product Owner decision**. Silent overwrite is dropped. Iteration 2 is still a **redesign hypothesis**, and representative-user validation is still open.
- Self-test-only observation: after an import creates a mismatch, the portfolio still says "Trust status: Up to date".
- Our differences from the canonical concept, recorded rather than discarded:
  - FX source and as-of time on the main screen, kept as an alternative;
  - statement-first establishment, kept as an alternative;
  - "overwrite today's quantity", which became an open question and is now superseded.

## Full file list (copy into your repo root, same paths)

```text
.copilot-tracking/dt/portfolio-tracker/coaching-state.md
.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-01-scope-notes.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/findings-summary.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/research-plan.md
.copilot-tracking/dt/portfolio-tracker/method-03-synthesis/synthesis.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/divergent-ideas.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-notes.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-plan.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/theme-clusters.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concept-comparison.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concepts.yml
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/method-06-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/our-concept.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/constraint-discoveries.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-01-learning.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-02-learning.md
workshop-output/prototype-self-test.md
```

## Copy the files into your repo

**Heads-up:** the `.copilot-tracking` folder inside `repo-files/` is hidden. On Mac, show it with **Cmd+Shift+.**. On Windows it's normally visible (if not, use **View > Show > Hidden items**). Or use the Terminal command below, run in **VS Code → Terminal → New Terminal**, which copies it for you.

1. Download `Pack-B-after-Step-6.zip` from https://github.com/costastselios/hve-core-workshop-pm-tpm-design-thinking-lite/raw/main/Pack-B-after-Step-6.zip (also posted in the workshop Teams channel) and unzip it.
   - **Windows:** right-click the zip → **Extract All…** → **Extract**, and keep the suggested folder in `Downloads`. The Windows command below finds the pack even if Extract All creates a doubled folder (`…\Pack-B-after-Step-6\Pack-B-after-Step-6\repo-files`).
2. Copy everything **inside** `repo-files/` into the **root** of your workshop clone (the folder that contains `docs/`, `workshop/` and `workshop-output/`). You should end up with:
   ```text
   .copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md
   workshop-output/prototype-self-test.md
   ```
   - **Easiest:** in VS Code, open **Terminal → New Terminal**. It opens at your repo root. Paste the macOS or Windows command below. It merges the files into your repo and doesn't delete anything.
   - ⚠️ **Don't drag `docs`, `.copilot-tracking` or `workshop-output` onto your repo's folders of the same name.** If VS Code asks whether to **Replace** a *folder*, choose **Cancel**: Replace deletes the existing folder first, including the workshop's own docs.
   - **macOS Terminal**, from your repo root: `cp -R ~/Downloads/Pack-B-after-Step-6/repo-files/. .`
   - **Windows (PowerShell, the VS Code default)**, from your repo root: paste this single line. It finds the unzipped pack under `Downloads`, merges everything from `repo-files` into your repo (never deletes; skips `READ-ME-FIRST.txt`), and prints `OK - copied from …`. If the terminal prompt doesn't start with `PS`, it's cmd.exe: type `powershell`, press Enter, then paste.
     ```powershell
     $pack='Pack-B-after-Step-6'; $src=(Get-ChildItem "$HOME\Downloads" -Directory -Recurse -Depth 3 -Filter repo-files -ErrorAction SilentlyContinue | Where-Object FullName -like "*$pack*" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName; if (-not (Test-Path workshop)) { 'STOP: run this in the VS Code terminal of your workshop repo (the folder with docs, workshop, workshop-output)' } elseif (-not $src) { "STOP: $pack not found under $HOME\Downloads - unzip the pack there first" } else { robocopy "$src" . /XF READ-ME-FIRST.txt /E /NFL /NDL /NJH /NJS /NP; if ($LASTEXITCODE -lt 8) { "OK - copied from $src" } else { "ERROR: robocopy exit code $LASTEXITCODE" } }
     ```
   - The macOS command also copies `READ-ME-FIRST.txt` into your repo; delete it from your repo root afterwards. The Windows command skips it.
   - `.copilot-tracking` is hidden in Finder. Press **Cmd+Shift+.** to show it.
3. **Keep your own notes:** before copying, rename your own `workshop-output/prototype-self-test.md`, for example to `prototype-self-test-ours.md`. If you have your own `.copilot-tracking/dt/portfolio-tracker/`, rename that too. Compare your notes with ours at Regroup 3.

## Resume in Step 7 with BRD Builder

1. Open a **new** Copilot Chat and select **BRD Builder** (`hve-core:brd-builder`).
2. Attach these files with **Add Context** or `#file`:
   - `.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md`
   - `workshop/05-common/BRD-SKELETON.md`
   - `docs/GATE-RECORD.md`
   - `docs/DECISION-RUBRIC.md`
3. Paste:

```text
Create a BRD for the Portfolio Tracker (BRD name: portfolio-tracker) from the attached DT→BRD handoff and the DT artifacts it links in .copilot-tracking/dt/portfolio-tracker/. Do not restart discovery; treat the completed Design Thinking outputs as the evidence base and preserve their evidence labels and low confidence (two supplied participant summaries, no prevalence). Stakeholders: the self-directed multi-broker investor is the user; brokers and price/FX data providers are data sources; I am the Product Owner, decision owner and sign-off authority for this workshop planning baseline. Keep unresolved dependencies — e.g., FX/price provider coverage and licensing, representative-user validation of the Iteration 2 recovery model — as gates with every Gate Record field completed (Gate ID, Title, Owner, Status, Affected requirements, Exit evidence, Next decision trigger, Remaining uncertainty). Use stable BR IDs with measurable or reviewable acceptance conditions and traceability to the DT evidence/decisions. Out of scope: trading, investment advice, forecasts, tax reporting, goal tracking, real personal financial data. No architecture. Decline any RPI research segment. Ask me only what you genuinely need.
```

4. Then follow Step 7 (`workshop/05-common/STEP-07-BRD.md`). Review with the Step 7 Review Card. Approve **only** as the workshop BRD planning baseline, keeping gates open. Save the BRD and the BRD→PRD handoff as files.

**Running short on time?** When the Step 7 timebox ends, **Pack C** has an approved BRD you can review and approve instead.
