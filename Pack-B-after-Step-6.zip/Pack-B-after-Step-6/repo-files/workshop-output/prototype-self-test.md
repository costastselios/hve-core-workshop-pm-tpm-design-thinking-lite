# Prototype Self-Test

> **Workshop self-test only.** These are our own observations from clicking through the fixed-data prototypes as Product Owner. They are **not** representative-user research. Supplied participant-test evidence is quoted separately in the third column and is attributed to `workshop/04-prototype/iteration-01/test-results.md` (low confidence, directional, no raw notes).

## Iteration 1 — exercised end to end

| Observation | My interpretation | Supplied participant evidence | Open question |
|---|---|---|---|
| Setup offers **Use workshop statement** first and **Add holding manually** as a fallback; the preview says "3 holdings detected from Broker 1 and Broker 3 · source context will be retained". | Import-first, not import-only, is understandable. Source broker is visibly retained per holding. | Supplied finding: basic navigation/import/provenance were understandable. | Does a real statement give enough detail to establish holdings (fractional units, crypto)? |
| Portfolio shows "3 source platforms · reporting currency AED", 4 holdings each with broker, asset type and currency; the Broker 2 holding is labelled "manually entered". | The consolidated view and per-holding source are clear. "Manually entered" is a useful trust signal. | — (not tested separately) | Should manually entered holdings carry a lower trust level? |
| "Current total" says **Consolidated** with no figure (fixed-data prototype). History panel says "directional history for workshop testing". | Deliberate: the test is about workflow and trust, not numbers. History reads as factual, not forecast. | — | — |
| Only **Global Equity ETF** opens; the other holdings aren't clickable. | Fixed-data click-through; one path is wired. Not a finding about the concept. | — | — |
| Holding view: 120 units, Broker 3, Buy 40 / Buy 80 / Fee. **View provenance** reveals "Price: completed market valuation · source recorded" and "FX: daily reference conversion · as-of context recorded". | Provenance on demand increases trust; price evidence vs FX evidence vs reporting currency are distinguishable. Our own concept would put FX source/as-of on the main screen (recorded as an alternative in Method 5). | Supplied finding: provenance was understandable. | Is "on demand" enough when FX is stale, or must staleness be shown on the overview? |
| Add transaction: Buy/Sell/Fee, date, units, price, currency, fee → **Review transaction** ("This activity will change the recorded quantity") → **Save**. Quantity does not change (fixed data). | Review-before-save is clear; the transaction model matches the primer. | — | — |
| Import: three staged records (Ready / Possible duplicate / Needs attention). **Apply** stays disabled until we decided the duplicate (**Skip**) and reviewed the sell. Reviewed note: "kept as broker evidence… flagged for reconciliation instead of being overwritten silently". | Staging before commitment is obvious; ready vs duplicate vs uncertain are distinguishable. | Supplied finding: import was understandable. | How should "possible duplicate" be decided when the user isn't sure? |
| After applying, the holding shows "Holding needs attention… Resolve mismatch", **but the portfolio's "Trust status" still says "Up to date"**. | Trust status does not reflect an open mismatch. That undermines the trust model at portfolio level. | — (self-test only) | Should any unresolved mismatch downgrade portfolio-level trust status? |
| **Prediction recorded before clicking:** we expected **Update holding** = set today's quantity to the broker's lower number; **Fix history** = add or edit a past transaction. We weren't sure whether Update holding also writes a hidden adjusting transaction. | Our prediction already contained an unanswerable question: does "update" touch history? | — | — |
| Chose **Update holding** → "Correction recorded." The screen still shows "120 units recorded" and the text "The interface does not explain the consequence of either option." | **We cannot explain whether today's holding, history, or both changed, nor what is still uncertain.** The two options are different mental models (current state vs history) presented as interchangeable buttons. | Supplied finding: "recovery was completed mechanically without understanding whether current state, historical activity, or both changed. Treat this as a concept-comprehension failure." | Can users even tell whether they know the cause of a mismatch? |

## Comparison with supplied participant evidence (read only after the recovery exercise)
- Our self-test **agrees** with the supplied finding: recovery can be completed mechanically without understanding the consequence.
- We treat it as a **concept-comprehension failure**, not a wording or visual-design defect: the concept doesn't separate *current-state correctness* from *historical completeness*. Better button labels wouldn't fix that.
- Our self-test is **one pair's interaction**, not participant evidence, and doesn't raise the confidence of the supplied finding.

## Iteration 2 — both branches exercised

| Observation | My interpretation | Supplied participant evidence | Open question |
|---|---|---|---|
| Conflict screen first: "New evidence says: current quantity should be lower" vs "Your portfolio currently says: 120 units"; "Why this is flagged"; **Current impact:** today's holding may be incorrect; **Historical impact:** history may be incomplete. | Explains the conflict before any action, and separates current vs historical impact. | None. Iteration 2 has **not** been tested with participants. | Will users read this, or skip to the buttons? |
| Asks "Do you know what caused the difference?" → two paths based on the evidence the user actually has. | The cause question is the key new mental model. | None. | Can users reliably judge whether they "know" the cause? |
| **Known cause** → preview: **Will change:** historical activity (record missing activity, recalculate affected history). **Will not change:** unrelated records. **Will remain uncertain:** unexplained evidence stays visible. → "Missing activity recorded and affected history recalculated." | We can explain what changed, what didn't, and what is uncertain. | None. | What if the user records the wrong missing activity? |
| **Unknown cause** → preview: **Will change:** today's verified holding. **Will not change:** historical transactions aren't rewritten. **Will remain uncertain:** historical cause and completeness. → "Today's holding verified without rewriting historical transactions." | Today's state becomes trustworthy without inventing history. Gain/loss and cost basis for this holding stay uncertain. | None. | How is the "historical cause uncertain" state shown later, e.g., in gain/loss or history? |

## Final comparison
1. **What failed in Iteration 1?** Recovery offered two actions without explaining whether each changes today's holding, history or both. Users (supplied evidence) and we (self-test) could complete it without understanding it. This is a concept failure.
2. **Mental model Iteration 2 introduces:** understand the conflict → separate current vs historical impact → declare whether the cause is known → known cause repairs history; unknown cause verifies today only → preview consequences before confirming.
3. **Why more trustworthy despite uncertainty:** it never pretends to know how the portfolio got here. Uncertainty is stated, not hidden.
4. **Still needs representative-user validation:** whether users understand the conflict explanation and the cause question, pick the right branch, and can explain the outcome. Also whether the "uncertain history" state stays understandable later. **Iteration 2 is a redesign hypothesis, not a validated solution.**

## Tooling notes
- Both prototypes opened and responded in the browser, with no tooling failures. Fixed-data limitations (no totals, quantities don't recalculate, single clickable holding) are expected and aren't findings.
