# Method 6: Iteration 2 learning and workshop exit

Status: workshop learning complete; redesign remains a hypothesis, not a
representative-user-validated solution. No new prototype built or modified.

## Sources and evidence boundary

- R2: `workshop/04-prototype/iteration-02/recovery-model.md`, model paragraph
  and status. Supplied redesign description, not test evidence.
- S2: `workshop-output/prototype-self-test.md`, Iteration 2 table and Final
  comparison. Product Owner self-test observations/interpretations, not
  representative-user research; no supplied Iteration 2 participant results.
- P1: `workshop/04-prototype/iteration-01/test-results.md`, Provenance/Finding.
  Low-confidence supplied participant summary: recovery mechanically completed
  without understanding current/history effects. Run ID/raw notes absent;
  representative validation not established. See `iteration-01-learning.md`.
- D2: Product Owner live-conversation Decision (not evidence), 2026-11-17:
  adopt R2 as concept baseline, drop silent overwrite; unknown cause verifies
  today without rewriting history. Prior Method 5 recovery question is answered
  as a decision, not an empirically validated finding.

Sources read; originals unchanged. Coach did not execute either prototype or
verify calculation/persistence. Fixed-data responses illustrate consequences,
not actual financial processing. Self-test agreement does not raise P1 confidence.

## Concept change and motivation

Iteration 1 offered Update holding / Fix history without explaining the
relationship between today's correctness and historical completeness. P1
motivates a concept-level repair, not simply button renaming. The separate
Product Owner pre-click prediction/confusion is supporting workshop learning,
not another participant test.

R2 changes the mental model: explain evidence conflict first -> distinguish
current and historical impact -> establish whether the cause is known -> choose
the evidence-appropriate branch -> preview consequences before commitment.

| Branch | What changes, per R2/S2 | What does not change | What remains uncertain |
|---|---|---|---|
| Known cause | Record missing historical activity and recalculate affected history. | Unrelated records. | Other unexplained evidence stays visible; whether the asserted activity/cause is correct is not independently established. |
| Unknown cause | Verify today's holding only. | Historical transactions are not rewritten; no invented activity explains the difference. | Historical cause/completeness; gain/loss and cost basis remain uncertain in the self-test interpretation, not validated calculations. |

S2 reports the Product Owner exercised both branches and could explain the
previewed effects. This supports inspectability to that tester only. It does
not demonstrate representative comprehension, branch-choice accuracy, truthful
inputs, actual recalculation, persistence or financial correctness.

Why potentially more trustworthy (hypothesis): evidence about today's quantity
is no longer treated as proof of the path that produced it; unresolved history
is exposed rather than fabricated. D2 selects that principle despite remaining
uncertainty. It does not assert every conflict has a known missing transaction.

## Decision updates and retained questions

D2 supersedes the tentative silent-overwrite proposal. Preserve the earlier
proposal/comparison as historical records; it is no longer an active alternative.
The canonical workshop concept plus R2 recovery is the current adopted baseline.
The main-screen FX source/as-of Alternative remains unchanged.

Open question, self-test only: holding mismatch versus portfolio Trust status
Up to date. No participant evidence establishes the appropriate overview
status or confirms a redesign fixed it; keep it separate from recovery findings.

## Representative-user validation still open

With appropriate consent and safe synthetic tasks, test whether non-author
users understand the conflict, distinguish present/history effects, judge whether
they know the cause, choose the appropriate branch, and predict consequences
before clicking. Afterward ask what changed, did not change and remains uncertain.
Include mistaken-cause and unknown-cause cases, not just successful completion.

Observe whether uncertainty remains understandable later in history and any
gain/loss/cost-basis views; whether users mistake verified-today for verified-
history; whether they can recover from a wrong assertion; and whether source/
as-of information is found when needed. These are future validation questions,
not test results. No prevalence claim or numeric success threshold is invented.

## Method 6 exit check

| Workshop check | Assessment |
|---|---|
| Supplied prototypes and script used, no new build | Met through reported Product Owner walkthroughs; coach did not claim independent runtime execution. |
| Iteration 1 failure identified | Met: supplied Low-confidence participant summary kept separate from self-test; concept comprehension, not cosmetic defect. |
| Redesign and both branches explained | Met at model/self-test level; effects, non-effects and uncertainty recorded. |
| Evidence -> conceptual failure -> redesign hypothesis traceable | Met; R2 not misrepresented as participant validation. |
| Decision on earlier overwrite question | Met by D2, explicitly not evidence: unknown cause verifies today only, silent overwrite dropped. |
| Remaining validation and open questions explicit | Met; representative-user work, trust-status question and technical/financial validation remain open. |
| One concept baseline carried forward | Met by facilitator/Product Owner decisions; not a comparative research winner. |

Disposition: bounded workshop Method 6 completion satisfied. HVE's full exit
requires 3-5 variations tested with real users in real environments, constraint
discoveries across categories, evidence-backed assumption outcomes and a
Method 7 handoff. Those real-world gates are not satisfied: two supplied
iterations, only Low-confidence prior participant evidence for Iteration 1,
self-test-only Iteration 2, no representative or environmental validation.
Do not fabricate missing variation tests or mark redesign validated.

Current method stays 6, Solution Space. Methods 7-9 are explicitly outside this
workshop: no Method 7 transition, implementation, backlog or delivery handoff.
