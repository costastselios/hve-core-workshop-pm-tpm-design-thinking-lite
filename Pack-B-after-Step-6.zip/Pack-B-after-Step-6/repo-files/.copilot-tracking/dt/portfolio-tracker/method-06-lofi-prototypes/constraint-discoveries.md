# Method 6: workshop constraint discoveries

| Constraint / category | Source | Severity / status |
|---|---|---|
| Mechanical recovery completion does not establish understanding of present versus historical effects (conceptual/workflow). | Iteration 1 supplied participant summary, Low confidence; Product Owner self-test separately records confusion. | Blocker for recovery-comprehension objective in reported test; no prevalence inferred. |
| Today's verified position cannot establish an unknown historical cause (conceptual/evidence boundary). | Iteration 2 supplied model and Product Owner decision, not validated test result. | Adopted design principle/hypothesis; representative comprehension still open. |
| Overview Up to date can conflict with unresolved holding mismatch (trust/workflow). | Product Owner Iteration 1 self-test only. | Open question; potential trust friction, not participant-established severity or a verified runtime defect. |
| Fixed-data prototypes do not calculate/store transactions, totals or history (prototype scope). | Supplied test script and self-test report. | Expected limitation, not concept defect; no financial-correctness result. |
| Physical/environmental and diverse-user constraints. | Not supplied. | Unknown, not inferred absent or satisfied. |

Current selected baseline: canonical combined concept plus the Product Owner-
adopted Iteration 2 recovery model. No narrowing to an empirically proven solution
is claimed. See `iteration-02-learning.md` for branch effects, remaining tests
and qualified workshop exit. This is a learning record, not implementation
requirements or a Method 7 handoff; Methods 7-9 are out of workshop scope.
