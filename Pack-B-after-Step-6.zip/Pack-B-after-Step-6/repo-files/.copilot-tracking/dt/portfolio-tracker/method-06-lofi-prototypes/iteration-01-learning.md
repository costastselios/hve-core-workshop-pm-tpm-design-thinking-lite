# Method 6: Iteration 1 learning

Status: Iteration 1 recorded; Method 6 ongoing. Canonical combined concept is the
adopted baseline by facilitator decision, not a validated solution.
No prototype was built, modified or browser-tested by the coach.

## Scope and source register

| ID | Source and locator | Status / limits |
|---|---|---|
| B | `workshop/03-concept-checkpoint/canonical-concept-snapshot.md`, adopted in Method 5 handoff | Baseline: establish, orient, inspect provenance, maintain/import, review uncertainty, understand conflicts, recover without inventing history. |
| T | `workshop/04-prototype/test-script.md`, Purpose, fixed-data notice and B3 | Supplied protocol, not test results. B3 asks for predictions before clicking and explanation of current/history effects and remaining uncertainty. |
| P-I1 | `workshop/04-prototype/iteration-01/test-results.md`, Provenance and Finding | Supplied prior participant-test summary. Low confidence, directional; run ID/raw notes/transcript absent; representative validation not established. Participant identity/environment/date not supplied. |
| S-I1 | `workshop-output/prototype-self-test.md`, Iteration 1 table and Comparison with supplied participant evidence | Product Owner workshop self-test report, not representative-user research. Original observations and interpretations are separate columns; participant column refers back to P-I1, not another test/source. |

Supplied prototype references: `workshop/04-prototype/iteration-01/index.html`
and `workshop/04-prototype/iteration-02/index.html`. Existing fixed-data workshop
artifacts only. No source inspection or runtime result is claimed here.
Received/read: 2026-11-17. Source files left unchanged.
The self-test and script contain Iteration 2 material; it is deliberately not
analyzed in this Iteration 1 record. No Iteration 2 outcome is inferred.

## Hypothesis and supplied participant evidence

Hypothesis under examination, reconstructed from T/B3: a person completing
recovery can explain whether today's holding, historical activity, or both
change, and what remains uncertain.

P-I1 reported result (summary paraphrase): basic navigation/import/provenance
were understandable, but recovery was completed mechanically without
understanding whether current state, historical activity, or both changed.

Assessment: concept-comprehension failure; the recovery-completion-implies-
understanding assumption is not supported and fails in this reported test.
This is not a demonstrated population effect, technical-calculation defect, or
proof that every recovery option fails. Positive navigation findings do not
validate recovery, arithmetic, full data handling or the entire concept.
Confidence remains Low; no completion rate, time, count or direct quote invented.

## Product Owner self-test observations - separate, not participant evidence

| ID | Reported observation | Interpretation / open question, not participant finding |
|---|---|---|
| S1 | Statement setup/source context, consolidated AED view, manual fallback, on-demand provenance and staged import were exercised. | Product Owner found these understandable; this does not establish representative-user comprehension or support every path. |
| S2 | Before clicking, predicted Update holding sets today's quantity; Fix history adds/edits past activity; unsure whether update creates hidden adjusting activity. | Prediction already exposed uncertainty about current-state versus history semantics. Preserve this as a pre-click prediction, not a post-hoc participant result. |
| S3 | Chose Update holding; received Correction recorded; still could not explain current/history effect or residual uncertainty. | Completion without an understood consequence supports the self-test's concept concern, not correctness of any actual mutation. Fixed-data screens cannot prove what changed. |
| S4 | Holding had an unresolved mismatch while portfolio Trust status still said Up to date. | Self-test-only trust-consistency concern: should unresolved holding uncertainty affect overview status? Not reported in P-I1 and not independently runtime-verified by coach. |
| S5 | No numeric total, unchanged quantity after saving and only one clickable holding. | Declared fixed-data click-through limitations per T, not defects or concept failures; no calculator/persistence conclusion. |

S-I1's embedded supplied-evidence column and later agreement are not independent
participant corroboration. The Product Owner reports reading the participant
evidence after the recovery exercise; preserve that reported sequence without
claiming independently verified research execution. Self-test agreement does not
raise P-I1 confidence.

## Concept-level constraint discovered

The recovery concept does not make the relationship between current-state
correctness and historical completeness understandable before commitment.
Interchangeable-looking actions leave the person unable to predict or explain
what evidence is being asserted and what history remains unknown.

Classification: conceptual/workflow constraint. Severity: blocker for the
concept's recovery-understanding objective, not inability to click through.
Do not reduce it to button wording, layout or visual polish. Better labels alone
are not evidence that the underlying mental model is repaired.

Learning for the Method 5 open question: overwriting today's quantity is not
established as safe or understandable. Do not equate reconciling today's position
with knowing the historical cause, and do not silently invent activity to explain
the difference. On-demand vs main-screen provenance remains an alternative, not
settled by basic provenance comprehension.

## Next learning boundary

Redesign requirement to explore, not a validated implementation: distinguish
current holding from historical activity and expose the consequences and remaining
uncertainty before confirmation. A future test should require prediction and
post-action explanation, not merely successful navigation.

Open: can a person distinguish known cause from unknown cause; explain current
versus historical effects; recover when the cause is unknown without invented
history; and understand unresolved uncertainty later? Whether the overview
should downgrade trust is an additional self-test-derived question.

Physical/environmental constraints, real-user diversity, data correctness,
financial methodology and runtime behavior are not established. No new test,
prototype, wording fix, Method 6 completion or Method 7 handoff. Await the
user's Iteration 2 input.
