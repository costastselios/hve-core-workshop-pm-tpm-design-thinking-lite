# DT -> BRD handoff: Portfolio Tracker

## Status and use

- **Decision (not evidence):** Prepared for BRD Builder using the [workshop checklist](../../../workshop/05-common/DT-TO-BRD-HANDOFF.md). This is discovery context, not BRD requirements, delivery authorization or validated research.
- **Decision (not evidence):** Methods 2-6 are complete only under bounded workshop criteria; Method 1 scope was handed forward provisionally. Full HVE research/validation gates remain unmet. Methods 7-9 are outside scope. See [state and decision history](coaching-state.md).
- **Decision (not evidence):** Preserve the labels below downstream; never promote a Product Owner choice or self-test to representative-user evidence. If discovery fails, explicitly attach this file and its linked sources; do not reconstruct missing evidence.

## M1: scope

- **Decision (not evidence):** Fictional self-directed investor, not the Product Owner, without an adviser; three brokers, stocks/ETFs/some crypto in USD/EUR/AED; AED reporting. These are scenario choices, not participant characteristics.
- **Assumption:** Manual cross-broker upkeep can create effort and uncertainty about holdings/value. The month-end spreadsheet story and stale hand-typed FX causing a wrong total are fictional, not observed incidents.
- **Decision (not evidence):** Desired outcome: factual, trustworthy consolidated understanding of what is held, where, its value, calculation basis and as-of context.
- **Decision (not evidence):** Explore sustainable maintenance and trustworthy valuation/FX. Exclude trading, advice, forecasts, tax reporting, real personal financial data and goal tracking from the opportunity frame.
- **Open question:** Real-world problem magnitude, adjacent accountant/partner roles, actual constraints and measurable success remain unknown. [Scope, stakeholder map and original assumptions](method-01-scope-notes.md).

## M2: evidence and confidence

| Label | Separate record | Supplied signal and limit |
|---|---|---|
| Evidence | [P01 supplied summary](../../../workshop/02-research-evidence/participant-01-research-summary.md) | Multiple brokers/manual consolidation; manual close/FX maintenance reduces trust; factual history/facts over forecasts; occasional entry acceptable; goal tracking matters here only. Low confidence, directional. |
| Evidence | [P02 supplied summary](../../../workshop/02-research-evidence/participant-02-research-summary.md) | Multiple brokers/markets, regular fractional purchases; repeated entry unacceptable, import acceptable; wants review before commitment, automatic prices/FX, composition and factual history; facts over forecasts. Low confidence, directional. |
| Open question | Provenance/coverage | No raw transcripts/verbatim quotes, collection dates, setting or recruitment details; source independence and representative validation unestablished. Two records establish no prevalence or market growth. |
| Decision (not evidence) | Workshop acceptance | Product Owner accepts these as completed workshop research, without raising confidence. |

- **Evidence:** [Source-located register](method-02-research/findings-summary.md) preserves participant identities and paraphrases; it supplies no additional independent research.
- **Decision (not evidence):** [Accepted protocol](method-02-research/research-plan.md) defines provenance/confidence handling; its planned observations are not evidence of execution.

## M3: synthesis and opportunity

- **Evidence:** Both records mention multiple brokers, factual history and facts over forecasts. Goal tracking is P01-specific; composition, fractional-purchase context and pre-commit review are P02-specific.
- **Evidence:** P01 tolerates occasional entry; P02 rejects repetitive re-entry. Different burdens are not necessarily contradictory. P01's trust concern and P02's automation preference are related, not identical reports of failure.
- **Assumption:** Focused opportunity: make factual cross-broker portfolio maintenance sustainable across purchase cadences while making valuation/currency conversion understandable and trustworthy.
- **Decision (not evidence):** Prioritize import-first with manual fallback, not import-only, and visible provenance; these are Product Owner choices, not jointly validated needs. Measures/baselines and coverage beyond two participants remain accepted workshop limitations. [Synthesis, HMW frame and five-dimension check](method-03-synthesis/synthesis.md).

## M4: divergence and convergence

- **Assumption:** [Sixteen divergent ideas](method-04-brainstorming/divergent-ideas.md) are untested possibilities, including deliberate opposites; no effectiveness is established.
- **Decision (not evidence):** Facilitator selected exactly three direction names for comparability; overlapping contributions do not select a proven winner:

| Label | Direction | Philosophy / mapped ideas |
|---|---|---|
| Decision (not evidence) | Adaptive Maintenance Portfolio | Adapt upkeep with reviewed import, manual fallback and recovery: M1, M5, M6, M7, M8. |
| Decision (not evidence) | Factual Portfolio Story | Explain dated facts/changes, not forecasts: M4, M8, V3, V6. |
| Decision (not evidence) | Progressive Valuation Transparency | Expose valuation/FX basis, timing and uncertainty: M6, V1-V6, V8. |

- **Decision (not evidence):** Parked, not deleted: M2 fully connected, M3 entirely manual, V7 no conversion. [Mapping, rationale, constraints and parked alternatives](method-04-brainstorming/theme-clusters.md).

## M5: concept, shared baseline and differences

- **Assumption:** [Our original concept](method-05-user-concepts/our-concept.md) promises understandable AED factual holdings with sustainable upkeep. [Rough concept cards](method-05-user-concepts/concepts.yml) are descriptions/prompts, not validated interfaces.
- **Decision (not evidence):** Our choices: statement-first establishment; reviewed import primary for upkeep, manual fallback secondary; accept reviewed changes with cancel/detail actions; FX source/as-of on main screen; AED reporting. Detailed action placement is not specified by the canonical snapshot.
- **Decision (not evidence):** Adopt the [canonical snapshot](../../../workshop/03-concept-checkpoint/canonical-concept-snapshot.md) for shared workshop comparison: establish -> orient -> inspect provenance -> maintain/import -> review uncertainty -> understand conflicts -> recover without inventing history. Trust: freshness/provenance on demand, uncertainty explicit.
- **Assumption:** D/F/V remains preliminary: factual consolidation may be desirable; coverage/import/correction feasibility is unproven; provider/licensing/support costs and adoption viability are unknown. No comprehension/resonance or technical-validation pass is claimed.

| Label | Difference and current disposition |
|---|---|
| Decision (not evidence) | Main-screen FX source/as-of retained as our **alternative**; baseline remains on-demand provenance. |
| Decision (not evidence) | Our explicit AED promise retained as local scenario context; canonical does not state currency or a separate promise. |
| Decision (not evidence) | Statement-first, reviewed-import/manual fallback and our action hierarchy retained as local choices/alternatives where canonical is silent, not silently inserted into canonical text. |
| Decision (not evidence) | Canonical journey order and explicit orientation/uncertainty/conflict review adopted. |
| Open question | Both D/F/V concern lists retained: coverage/import/provider rights plus support burden, adoption/payment, operating model, fractional quantities and correction handling. |
| Open question | Union of unresolved details retained: fees, duplicates, corporate actions, cost basis, methodology, unsupported assets/formats, baseline history, timing/cutoffs and stale inputs. Cost-basis inquiry does not authorize tax reporting. |
| Decision (not evidence) | Tentative quantity overwrite became a Method 6 open question; now resolved by Product Owner adoption of Iteration 2, **dropping silent overwrite**, not by participant validation. |

- **Decision (not evidence):** [Full comparison and qualified exit](method-05-user-concepts/concept-comparison.md) and [original Method 6 handoff](method-05-user-concepts/method-06-handoff.md) preserve earlier proposals. Later recovery decision below supersedes the earlier open-question status; originals remain historical records.

## M6: prototype -> failure -> redesign hypothesis

- **Decision (not evidence):** Use supplied [Iteration 1](../../../workshop/04-prototype/iteration-01/index.html), [Iteration 2](../../../workshop/04-prototype/iteration-02/index.html) and [test script](../../../workshop/04-prototype/test-script.md); no new prototype built. Fixed-data interactions do not prove calculation, persistence or financial correctness.
- **Evidence:** [Iteration 1 supplied participant summary](../../../workshop/04-prototype/iteration-01/test-results.md): navigation/import/provenance understandable; recovery mechanically completed without understanding whether current holding, historical activity or both changed. Low confidence/directional; run ID/raw notes absent, representative validation unestablished.
- **Evidence:** [Product Owner self-test](../../../workshop-output/prototype-self-test.md), **workshop observation only**, separately records pre-click predictions, unresolved current/history consequences, and portfolio Up to date despite a holding mismatch. Its embedded participant references repeat the supplied source, not independent evidence; self-test agreement does not raise confidence.
- **Assumption:** Concept interpretation: recovery lacked a comprehensible distinction between current-state correctness and historical completeness. This is a concept-comprehension failure, not merely wording/visual design; completion is not comprehension. [Iteration 1 learning](method-06-lofi-prototypes/iteration-01-learning.md).
- **Assumption:** [Iteration 2 recovery model](../../../workshop/04-prototype/iteration-02/recovery-model.md) is evidence-informed, not validated: explain conflict -> separate current/history impact -> ask whether cause is known -> preview consequences before confirmation.

| Label | Branch | Changes / unchanged / uncertain |
|---|---|---|
| Assumption | Known cause | Model records missing activity/recalculates affected history; unrelated records unchanged; other unexplained evidence remains uncertain. |
| Assumption | Unknown cause | Model verifies today only; historical transactions unchanged; historical cause/completeness remain uncertain, with gain/loss/cost-basis implications unvalidated. |

- **Evidence:** Product Owner reports exercising and explaining both Iteration 2 branches; this is **self-test only**, not Iteration 2 participant evidence or verified data mutation.
- **Decision (not evidence):** Adopt canonical concept plus Iteration 2 recovery as current concept baseline: unknown cause verifies today without rewriting history; silent overwrite dropped.
- **Open question:** Representative-user validation of conflict comprehension, cause judgment, branch choice, predicted/post-action consequences, mistaken-cause recovery and later uncertain-history interpretation is outstanding. No Iteration 2 participant results supplied.
- **Open question:** Portfolio Up to date versus unresolved mismatch remains **self-test-only**; no participant result or fix claimed.
- **Decision (not evidence):** [Iteration 2 learning/exit](method-06-lofi-prototypes/iteration-02-learning.md) and [constraint discoveries](method-06-lofi-prototypes/constraint-discoveries.md) record workshop completion, not full HVE real-user/environment/variation-testing completion or readiness for implementation.

## Open assumptions, questions and candidate gates

- **Assumption:** Sustainable effort, trust benefit of provenance placement, statement sufficiency and redesign comprehension remain unproven. The fictional month-end error and growth in multi-app investing are not established facts.
- **Decision (not evidence):** The gates below are suggested review checkpoints, not approved requirements or claimed satisfied controls. Suggested accountable owner for each: **Product Owner**; specialist input may be needed.

| Label | Candidate gate / unresolved dependency | Suggested owner and closure evidence |
|---|---|---|
| Open question | FX/price provider coverage and rights | Product Owner: sourceable coverage for needed assets/currencies/dates, licensed use/retention rights, access limits and costs; gaps explicit before treating availability as committed. |
| Open question | Recovery comprehension with representative users | Product Owner: consented, source-located observations of correct conflict/cause/branch understanding and explanation of effects/uncertainty, including unknown/mistaken cause. Agree success criteria first; self-test is insufficient. |
| Open question | Import/baseline and financial methodology | Product Owner: verify statement/history coverage, fractional quantities, duplicate/corporate-action/fee handling, unsupported assets and correction rules with appropriate expertise; no invented history or implied tax scope. |
| Open question | Valuation/FX meaning and uncertainty | Product Owner: agree cutoffs/timezones/crypto timing, rate direction, stale/missing-input behavior, provenance availability and uncertainty propagation; record unresolved cases. |
| Open question | Outcome measurement and broader context | Product Owner: define meaningful measures/baselines/targets, relevant stakeholders and research coverage; no numeric thresholds or prevalence inferred here. |
| Open question | Overview trust consistency | Product Owner: investigate self-test mismatch and determine/test appropriate status semantics; retain source distinction. |

- **Decision (not evidence):** BRD Builder may use this evidence-labelled context for subsequent human-reviewed business analysis. This file creates no BRD requirements, launches no BRD workflow, and makes no Method 7 transition.
