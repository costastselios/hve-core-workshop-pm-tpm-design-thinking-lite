# Method 5: concept comparison and workshop exit

Sources read in full: `our-concept.md` and
`workshop/03-concept-checkpoint/canonical-concept-snapshot.md`.
The former and `concepts.yml` remain unchanged as the pre-comparison proposal.
Canonical means shared workshop reference, not validated or superior evidence.
All dispositions below are Decisions (not evidence), Alternatives or Open
questions; no new participant evidence or confidence increase.

## Meaningful differences and dispositions

| Topic | Our proposal | Canonical snapshot | Recorded disposition |
|---|---|---|---|
| Promise | Explicit sustainable upkeep and understandable AED factual record. | Three shared directions and factual-consolidation desirability; no separate promise sentence or reporting currency. | Decision: adopt canonical direction combination; retain our promise/AED as local decision context, not claimed canonical text. AED is not reversed. |
| Establishment | Statement first, review baseline; no invented pre-statement history. | Says establish, without specifying starting mechanism. | Alternative: retain statement-first as our concrete establishment choice; do not silently make it mandatory in the shared baseline. Starting coverage/history remains Open question. |
| Journey order | Establish, maintain, understand, reconcile. | Establish -> orient -> inspect provenance -> maintain/import -> review uncertainty -> understand conflicts -> recover without inventing history. | Decision: adopt canonical order, including explicit orientation, uncertainty and conflict understanding before recovery. |
| Action hierarchy | Import primary once established; manual fallback; accept/cancel and row correction proposed. | Journey mentions maintain/import but specifies no button hierarchy or manual fallback. | Alternative: preserve our primary/secondary action proposal and manual fallback; do not treat snapshot silence as rejection or add these as canonical facts. Detailed action placement remains Open question. |
| Provenance placement | FX source/as-of directly on main portfolio screen; deeper detail on demand. | Freshness/provenance on demand; uncertainty explicit. | Alternative: preserve main-screen FX source/as-of as ours, per explicit Product Owner decision. Decision: use on-demand freshness/provenance for the shared baseline. |
| Recovery | Tentatively overwrite today's quantity; recovery/history semantics unresolved. | Recover without inventing history. | Open question for Method 6: can/how should quantity overwrite preserve evidence, prior state and effective date without inventing history? Decision: baseline keeps the canonical recovery principle, not overwrite as its default. Traceable correction remains an untested alternative, not a resolved answer. |
| Uncertainty | Staleness, missing inputs and disputes noted, but much behavior left open. | Explicit uncertainty review is part of the journey and trust model. | Decision: make uncertainty review explicit in the shared baseline; actual display, thresholds and behavior remain Open questions. |
| Desirability | Factual history, differing maintenance tolerances and provenance hypotheses. | Desirability of factual consolidation. | Decision: retain canonical D lens; our finer hypotheses remain evaluation questions, not established desirability. |
| Feasibility | Statement formats, snapshot/transaction distinction, fractional quantities, duplicates, corrections, FX times/access. | Coverage/import feasibility. | Open questions: preserve our specifics under coverage/import; no feasibility pass or implementation choice inferred. |
| Viability | Costs/rights, support burden, adoption/payment and operating model unknown. | Provider/licensing viability. | Open questions: retain our additional concerns alongside canonical provider/licensing focus; no viability proof. |
| Open-decision coverage | Baseline history, recovery, duplicates, formats, stale inputs, cutoffs, FX display and success measures. | Provider coverage, valuation cutoffs, fees, duplicates, corporate actions, cost basis, financial methodology, licensing, unsupported assets. | Open questions: union both lists. Canonical adds explicit fees, corporate actions, cost basis and financial methodology; it does not resolve or erase ours. |
| Validation boundary | Low-confidence evidence; comprehension, resonance and technical validation not performed. | Evidence-informed, not validated. | Decision: retain both boundaries. Adoption is a facilitator comparability constraint, not user validation. |

Both use exactly Adaptive Maintenance Portfolio, Factual Portfolio Story and
Progressive Valuation Transparency. No difference in direction names. Factual
history remains evidence-informed; goal tracking remains P01-specific and outside
the opportunity. Existing exclusions and synthetic-data-only boundary persist.
The snapshot's cost-basis/methodology questions do not authorize tax reporting.

## Workshop Method 5 exit check

| Requested check | Result / locator |
|---|---|
| Promise | Present in `our-concept.md`; retained as a hypothesis above. |
| Journey | Both sequences recorded; canonical sequence adopted. |
| Action hierarchy | Primary/secondary proposals recorded in `our-concept.md`; preserved as local alternatives where canonical is silent. |
| Trust model | Baseline on-demand provenance and explicit uncertainty; main-screen FX alternative retained. |
| D/F/V | All three assessed directionally, limitations retained; no pass verdicts or invented evidence. |
| Open decisions | Both lists retained, including overwrite as an explicit Method 6 test question. |
| Validation boundary | Evidence-informed, not validated; limited to two supplied Low-confidence summaries. |
| Recorded differences | Comparison above; original proposal and cards preserved. |

Disposition: requested workshop exit checks satisfied. Mark Method 5 complete
for workshop only; select the canonical combined concept as the sole shared
Method 6 baseline by facilitator decision. This does not claim that HVE's full
Silent Review -> Understanding Check -> Gap Identification -> Resonance Assessment
has occurred: no stakeholder comprehension/resonance results, participant
endorsement, validated D/F/V or usability results exist. These remain unperformed,
not passed. Success measures/baselines and wider coverage remain known gaps.

No optional canonical deck generation is implied by reading this supplied
snapshot; none was requested or performed. Optional offers/board writes are
deferred to honor the requested stop, not recorded as declined.
Stay at Method 5 completion; Method 6 has not started.
