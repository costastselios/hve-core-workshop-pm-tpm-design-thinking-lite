# Method 5: our workshop concept

Status: concept hypothesis, not validated requirements. Combines the three
selected directions; no canonical concept has been read or compared.
Evidence = the two supplied summaries, Low confidence, referenced through
`../method-02-research/findings-summary.md`. D = Product Owner Decision (not
evidence), 2026-11-17. H = generated hypothesis; OQ = Open question.

## Promise and direction roles

H: Keep a factual cross-broker portfolio understandable in AED without making
ongoing maintenance a repetitive burden, while showing the basis of its value.

| Selected direction | Role and basis |
|---|---|
| Adaptive Maintenance Portfolio | D: establish from broker statement first; maintain through reviewed imports with manual fallback. P02-E2/E3 supports import/review directionally; P01-E4 accepts occasional entry. Statement-first is not a participant-validated choice. |
| Factual Portfolio Story | H: dated holdings/history and visible changes explain the record over time. P01-E3/P02-E4 support factual history, not every proposed interaction. Goal tracking stays excluded by D; composition remains P02-specific. |
| Progressive Valuation Transparency | D: FX source and as-of time directly on the main screen; H: deeper calculation detail on demand. P01-E2 and P02-E3 are related trust/input signals, not evidence that either tested this presentation. |

## Key journey and action hierarchy

Concept-only sequence, not implementation requirements:

1. Establish: D statement-first; H review the statement's broker, date and
   holdings before accepting a starting position. A position snapshot does not
   establish pre-statement transaction history.
2. Maintain: D reviewed imports, manual fallback; H inspect proposed changes
   before accepting or cancelling them.
3. Understand: D AED reporting and always-visible FX source/as-of time; H inspect
   holdings, factual history and the valuation calculation.
4. Reconcile: D (tentative, explicitly unsure) let the user overwrite today's
   quantity when the record disagrees with broker evidence. This is retained as
   proposed, not silently replaced by an adjustment workflow.

| Context | Primary action | Secondary actions |
|---|---|---|
| Empty record | D: establish from statement | H: inspect statement coverage/date or cancel; manual entry is maintenance fallback, not an assumed alternative onboarding route. |
| Established portfolio | D: import an update for review | D: manual entry fallback; H: inspect history, valuation detail or discrepancies. |
| Import review | H: accept reviewed changes | H: correct/exclude proposed rows or cancel; duplicate handling is open. |
| Quantity disagreement | D tentative: overwrite today's quantity | H: inspect broker evidence first or leave unresolved; overwrite confirmation/recovery semantics remain open. |

## Trust model and rough sketch

D: FX source and as-of time are visible without opening detail; AED is reporting
currency. H: distinguish holdings date, price time and FX time, and expose
calculation basis rather than imply one timestamp guarantees all inputs are fresh.
Multiple FX pairs may require multiple source/time labels; presentation is open.

```text
[Statement] -> [Review baseline] -> [Portfolio: AED]
                                   FX source | as-of
                                   [Import update] primary
                                   Manual fallback | History | Details
                                          |
                                   [Review -> accept/cancel]
```

OQ / trust conflict: an unexplained quantity overwrite could break the factual
story, conceal the effective date/cause, or leave historical valuations
inconsistent. A quantity difference might reflect a missing event or bad
baseline, not merely today's error. No participant evidence establishes overwrite
as safe, and the decision does not specify whether prior state is retained.
H for evaluation, not an adopted replacement: compare overwrite with a dated,
source-linked correction that preserves prior state and can be reversed.

## D/F/V - preliminary assessment, no pass verdicts

| Lens | Directional basis | Unvalidated assumptions / risks |
|---|---|---|
| Desirability | P01/P02 factual-history preference; different entry tolerances; P01 trust concern and P02 automatic-input preference. | H: statement-first plus imports reduces burden; always-visible provenance aids understanding. No concept comprehension, resonance or usability evidence. |
| Feasibility | Concept can be represented with synthetic paper cards. | Statement formats, snapshot-versus-transaction handling, fractional quantities, duplicates, corrections, FX/price coverage and timestamps, licensing/access all unverified; quantity overwrite may undermine history. No technical proof. |
| Viability | D prioritizes sustainable upkeep and trust. | Provider costs/rights, support/reconciliation burden, willingness to adopt/pay and operating model unknown; no business case or viability evidence. |

## Open decisions

OQ: overwrite versus traceable correction, effective date, reason, evidence link
and undo; what history exists before the starting statement; import duplicates,
missing events and unsupported formats; staleness/missing-input behavior;
completed-market/crypto cutoff definitions; how multiple FX sources/times fit
on the main screen; success measures and baselines. Do not equate automatic with
accurate or visible provenance with verified truth.

## Validation boundary

Only P01/P02 supplied-summary evidence and labelled Product Owner decisions
support this draft; no new interviews, simulations of participant feedback or
prevalence claims. No canonical comparison, real personal financial data,
implementation, trading/advice/forecasts/tax reporting or goal tracking.

Method 5 evaluation remains pending: Silent Review -> Understanding Check
(30-second comprehension target, not a passed test) -> Gap Identification ->
Resonance Assessment. Using synthetic examples, test establishing a baseline,
reviewing an update, locating FX source/time and explaining a discrepancy.
Keep decision endorsement separate from observed task results.
The three YAML cards are rough views of this combined concept, not three
validated competing products; filenames are optional image targets, not images
produced. Method 5 is not complete, no Method 6 handoff or canonical snapshot.
