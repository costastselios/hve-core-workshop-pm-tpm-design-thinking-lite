# Method 6 handoff - shared workshop baseline, not started

Authority: Product Owner/facilitator Decision (not evidence), 2026-11-17:
adopt `workshop/03-concept-checkpoint/canonical-concept-snapshot.md` as the
shared baseline for comparable workshop testing. One combined concept, not a
winner established by participant evaluation.

Selected directions: Adaptive Maintenance Portfolio + Factual Portfolio Story +
Progressive Valuation Transparency.

Canonical journey: establish -> orient -> inspect provenance -> maintain/import
-> review uncertainty -> understand conflicts -> recover without inventing history.

Canonical trust: freshness/provenance on demand; uncertainty explicit.

Canonical D/F/V: desirability of factual consolidation; feasibility of
coverage/import; viability of provider/licensing. Evidence-informed, not validated.

Canonical open questions: provider coverage, valuation cutoffs, fees, duplicates,
corporate actions, cost basis, financial methodology, licensing, unsupported assets.

Local differences, not silent modifications to shared baseline:
`concept-comparison.md` preserves statement-first, reviewed-import/manual fallback
and action hierarchy as local alternatives/decisions. AED reporting remains a
Product Owner scenario choice, not a statement in the canonical snapshot.
Main-screen FX source/as-of remains an Alternative, not baseline trust placement.
Today's-quantity overwrite versus recovery without inventing history remains an
Open question to test in Method 6; do not resolve or build it here.

Our original proposal/cards remain in `our-concept.md` and `concepts.yml`.
They are not re-labelled as canonical. No evidence-based comparative selection,
stakeholder comprehension/resonance test or D/F/V proof is claimed.
Any later alternative test must be identified separately from the shared baseline
to preserve comparability. No prototype, test script or result is created now.

Constraints: synthetic data only; no trading, advice, forecasts, tax reporting,
real personal financial data or goal tracking in the opportunity frame.
Low-confidence evidence, unresolved measures/baselines and data/rights constraints
carry forward. Stop before Method 6.
