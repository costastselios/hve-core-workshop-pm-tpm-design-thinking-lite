# Method 4: divergent ideas

All ideas are untested hypotheses, not recommendations or validated requirements.
P01/P02 refer to the supplied participant summaries and the Method 2 evidence
register; evidence remains Low confidence. D-M = Product Owner import-first/manual
fallback decision; D-V = Product Owner trustworthy valuation/FX with visible
provenance decision. A relationship is an inspiration, not proof of effectiveness.
Opposites deliberately challenge decisions without changing them. Synthetic
examples only; no real financial data or actual connections. No ranking or selection.

## A. Sustainable maintenance

- M1: Import-first reconciliation inbox previews changes, permits manual fallback and undoes an accepted batch. [P02-E2/E3; P01-E4; D-M]
- M2: Fully automatic read-only broker connections keep records current, expose sync gaps and replay failed updates. [P02-E1/E2; opposite to D-M; hypothetical broker-access angle]
- M3: No automation: a monthly manual ledger ritual uses source checklists, checkpoints and reversible corrections. [P01-E1/E4; opposite to D-M and P02-E2]
- M4: Statement snapshots only preserve dated cross-broker positions, flag missing months and replace erroneous snapshots without reconstructing purchases. [P01-E3/P02-E4; opposite to transaction-by-transaction maintenance; statement access unverified]
- M5: A recurring-purchase template drafts expected entries for confirmation, marks missed confirmations and supports exceptions or cancellation. [P02-E1/E2/E3; extrapolation, not observed need]
- M6: An exception-only maintenance queue asks for attention when sources disagree, leaving disputed changes quarantined and reversible. [P01-E2; P02-E2/E3; untested maintenance hypothesis]
- M7: A local spreadsheet companion accepts the user's existing table as input, shows reconciliation differences and restores prior versions. [P01-E1/E4; spreadsheet is a workshop assumption, not participant evidence]
- M8: A minimal change diary records purchases, sales or corrections as they happen, then reconciles against periodic broker totals with a repair trail. [P01-E4; contrasts with P02-E2; untested incremental-effort angle]

## B. Trustworthy valuation and currency conversion

- V1: Automatic completed-market prices/FX carry a calculation receipt showing source, effective time, rate direction and AED arithmetic, with prior versions retained. [P01-E2; P02-E3; D-V; AED is a scenario decision]
- V2: User-maintained prices/FX show age and consistency warnings, require acknowledgement and preserve correction history without fetching replacements. [P01-E2; D-V; deliberate opposite to P02-E3]
- V3: Broker-statement valuations stay frozen at their stated dates, show the statement's FX basis where available and expose corrections as new snapshots. [P01-E3/P02-E4; D-V; snapshot-only opposite]
- V4: Independent price/FX sources appear side by side, exposing disagreement and allowing a sourced choice to be reversed. [P01-E2; D-V; untested provider-comparison angle]
- V5: A fail-closed view withholds a complete AED total when inputs are missing or stale, showing excluded holdings and what would restore completeness. [P01-E2; D-V; untested completeness-over-convenience opposite]
- V6: A replayable valuation timeline reconstructs an earlier total from its original prices/FX and contrasts it with later corrections. [P01-E3/P02-E4; D-V; untested reproducibility angle]
- V7: A native-currency-only view shows dated factual values but refuses cross-currency totals until the user explicitly chooses a conversion basis. [D-V; deliberate opposite to the AED-total scenario decision]
- V8: A user-chosen valuation cutoff locks the source policy for each asset/market, exposes timing mismatches including crypto and permits an explicit policy reset. [P02-E1/E3; D-V; crypto is a scenario decision, not participant evidence]

Sixteen ideas recorded; none scored, filtered, selected or converged. The two
sections are requested focus rounds, not converged solution themes. Method 4
remains in divergent execution.
