# Method 4: selected workshop directions

Decision (not evidence), Product Owner/facilitator, 2026-11-17: converge using
only the following three direction names for later Step 6 comparison. All three
are selected for concept development, not one winning solution. Evidence remains
Low confidence; selection does not validate desirability, feasibility or viability.
Idea IDs refer to `divergent-ideas.md`; source IDs to the Method 2 register.

| Direction | One-line philosophy | Contributing ideas | Main evidence / decision |
|---|---|---|---|
| Adaptive Maintenance Portfolio | Adapt upkeep to purchase cadence through import-first review, manual fallback and recoverable changes. | M1, M5, M6, M7, M8 | P02-E1/E2/E3 repeated purchases, re-entry burden and review; P01-E4 occasional entry tolerance; D-M import-first/manual fallback. |
| Factual Portfolio Story | Explain holdings over time through dated factual records and visible corrections rather than forecasts. | M4, M8, V3, V6 | P01-E3 and P02-E4 factual history/facts over forecasts; goal tracking excluded by Product Owner decision. |
| Progressive Valuation Transparency | Reveal valuation/FX basis, source, timing and uncertainty from understandable totals through inspectable details. | M6, V1, V2, V3, V4, V5, V6, V8 | P01-E2 manual close/FX trust concern; P02-E3 automatic prices/FX preference; D-V visible provenance. Progressive disclosure is a generated hypothesis, not a participant request. |

These are philosophy-based groupings: sustainable upkeep, historical explanation,
and inspectable valuation. Overlap is intentional, not three implementation
bundles. M4 contributes its snapshot/history principle without mandating
snapshot-only behavior for every direction. V2 contributes explicit overrides
and warnings as an alternative, not a decision to abandon automatic inputs.
No idea is rewritten as research evidence.

## Parked alternatives - retained, not deleted

| Idea | Parking rationale for this workshop |
|---|---|
| M2 fully automatic broker connections | Alternative to import-first; connection availability, permissions and recovery feasibility are unverified. Retained for later reconsideration, not declared infeasible. |
| M3 entirely manual ledger | Opposite maintenance philosophy; does not preserve the selected import-first direction or P02's repeated-entry concern. |
| V7 no conversion | Opposite to the chosen AED-reporting scenario; native-currency-only alternative remains in the original idea record. |

Coverage: M1-M8 and V1-V8 are all mapped or explicitly parked. Mapping is
contribution, not ranking; no fourth direction is introduced.

## Constraint integration and concept-development handoff

All three inherit factual-only scope, synthetic data only, no trading/advice/
forecasts/tax reporting, no goal tracking in the opportunity frame, and the
scenario's AED reporting decision. Maintenance/recovery and valuation details
remain hypotheses; access/licensing and success measures/baselines are open.

Later concept-development questions, not concepts built now: does adaptable
upkeep reduce effort without obscuring changes; does historical explanation
support factual understanding; does progressive provenance make valuation
understandable without overwhelming the user? Desirability is untested,
feasibility depends on data/rights and recovery behavior, and viability has no
cost/licensing evidence. No answer or numeric target is assumed.

Method 4 exit: sixteen rough ideas preserved, three distinct philosophies with
representative ideas/rationale/constraints recorded, and all three selected
under the facilitator constraint. Complete for workshop only. Current method
stays 4; stop before Method 5, concept sketches, prototypes or implementation.
Optional board export is deferred at the requested stop; no board writes occur.
