# Pack C: after Step 7 (approved BRD and BRD→PRD handoff)

> **Optional reference in the lighter workshop format.** Everyone loads **Pack A** at 12:00 and **Pack D** at 14:40. You don't need Pack C for the main flow. Use it to look at the reference run's artifacts, or to replay the full workshop later on your own. The times below come from the original full-day plan.

**Use when:** your pair hasn't got an approved BRD at **15:05**. Review this BRD with the Step 7 Review Card, make your own approval decision, then start **Step 8 (PRD)** with **PRD Builder**.

**How it was made:** a facilitator ran the workshop on the current `main` branch with the real **DT Coach** and **BRD Builder** agents (HVE Core plugin v3.2.2, Copilot CLI). Answers came from the persona and decision card. Every file is agent-generated except `workshop-output/prototype-self-test.md`, which the pair writes.

This pack is cumulative. It includes everything from Packs A and B.

## What's inside

> **`repo-files/` looks empty? It isn't.** The files are inside a hidden folder named `.copilot-tracking`. On Mac, show it with **Cmd+Shift+.**. On Windows it's normally visible (if not, use **View > Show > Hidden items**). Or skip Finder entirely: paste the copy command below into **VS Code → Terminal → New Terminal**, which opens at your repo root and copies hidden folders too. See also `repo-files/READ-ME-FIRST.txt`.

All files go under `repo-files/` in the same paths they need in your repo. Every path that starts with `.copilot-tracking/` is inside the hidden folder.

| File | What it is |
|---|---|
| `docs/project-planning/portfolio-tracker-brd.md` | **The approved BRD** (BRD-2026-Q4-001 v1.0.0): 12 BRs (BR-001…BR-012), 17 acceptance criteria, 3 rules, 3 constraints, 3 NFRs and 7 gates. **Approved as the workshop BRD planning baseline only.** |
| `docs/project-planning/portfolio-tracker-brd-to-prd-handoff.md` | **BRD→PRD handoff** in the workshop skeleton format. Each BR has its intent, PRD destination, acceptance boundary, inherited exclusions, inherited gates and unresolved product decision. |
| `.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml` | BRD Builder's own machine-readable handoff. It records the approved BRD's SHA-256. |
| `.copilot-tracking/brd-sessions/portfolio-tracker.state.json` | BRD Builder session state |
| `.copilot-tracking/brd-sessions/*quality-report.yml`, `*standard-findings.yml` | BRD Quality Reviewer results for the Define and Govern reviews |
| `docs/project-planning/portfolio-tracker-brd-v0.1.0.md` | The draft before approval, kept for lineage |
| `.copilot-tracking/dt/portfolio-tracker/…`, `workshop-output/prototype-self-test.md` | Everything from Pack B: the DT state, Methods 1–6, the DT→BRD handoff and the self-test |

**Which handoff should you use?** Use the agent's `.handoff.yml` as *the* handoff. Use the markdown handoff, which follows the workshop skeleton, to read and review it. Attach both in Step 8.

### Gates carried forward (all Open; owner: Workshop Product Owner)

| Gate | Title | Main BRs affected |
|---|---|---|
| GATE-001 | Price/FX provider coverage and licensing | BR-002, BR-006, BR-007 |
| GATE-002 | Representative-user validation of Iteration 2 recovery | BR-009 to BR-012 |
| GATE-003 | Import/baseline coverage and financial methodology | BR-001 to BR-005, BR-009 to BR-012 |
| GATE-004 | Valuation/FX meaning, timing and uncertainty | BR-002, BR-003, BR-006, BR-007, BR-008, BR-010, BR-012 |
| GATE-005 | Outcome measurement and broader-context coverage | all BRs (goals) |
| GATE-006 | Overview trust-status consistency (from the self-test only) | BR-008 |
| GATE-007 | Viability, support burden and operating assumptions | all BRs |

Every gate has all the Gate Record fields: ID, title, owner, status, affected requirements, exit evidence, next decision trigger and remaining uncertainty. See the BRD section **Dependency and Validation Gate Register**.

**Approval facts the facilitator should know:**
- BRD Quality Reviewer found **no approval blockers**.
- The formal SMART check on the three business goals is **FAIL**: they have no baselines or targets, and none were invented. The Product Owner recorded a **scoped waiver (WVR-001)**, governed by GATE-005, for this planning baseline only.
- This is the "open governed dependency vs approval blocker" teaching point from Step 7.

## Full file list (copy into your repo root, same paths)

```text
.copilot-tracking/brd-sessions/portfolio-tracker.govern-quality-report.yml
.copilot-tracking/brd-sessions/portfolio-tracker.govern-standard-findings.yml
.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml
.copilot-tracking/brd-sessions/portfolio-tracker.quality-report.yml
.copilot-tracking/brd-sessions/portfolio-tracker.standard-findings.yml
.copilot-tracking/brd-sessions/portfolio-tracker.state.json
.copilot-tracking/dt/portfolio-tracker/coaching-state.md
.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-01-scope-notes.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/findings-summary.md
.copilot-tracking/dt/portfolio-tracker/method-02-research/research-plan.md
.copilot-tracking/dt/portfolio-tracker/method-03-synthesis/synthesis.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/divergent-ideas.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-notes.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/session-plan.md
.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/theme-clusters.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concept-comparison.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concepts.yml
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/method-06-handoff.md
.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/our-concept.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/constraint-discoveries.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-01-learning.md
.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-02-learning.md
docs/project-planning/portfolio-tracker-brd-to-prd-handoff.md
docs/project-planning/portfolio-tracker-brd-v0.1.0.md
docs/project-planning/portfolio-tracker-brd.md
workshop-output/prototype-self-test.md
```

## Copy the files into your repo

**Heads-up:** the `.copilot-tracking` folder inside `repo-files/` is hidden. On Mac, show it with **Cmd+Shift+.**. On Windows it's normally visible (if not, use **View > Show > Hidden items**). Or use the Terminal command below, run in **VS Code → Terminal → New Terminal**, which copies it for you.

1. Download `Pack-C-after-Step-7.zip` from https://github.com/costastselios/hve-core-workshop-reference/raw/main/Pack-C-after-Step-7.zip (also posted in the workshop Teams channel) and unzip it.
   - **Windows:** right-click the zip → **Extract All…** → **Extract**, and keep the suggested folder in `Downloads`. The Windows command below finds the pack even if Extract All creates a doubled folder (`…\Pack-C-after-Step-7\Pack-C-after-Step-7\repo-files`).
2. Copy everything **inside** `repo-files/` into the **root** of your workshop clone. You should end up with:
   ```text
   docs/project-planning/portfolio-tracker-brd.md
   docs/project-planning/portfolio-tracker-brd-to-prd-handoff.md
   .copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml
   ```
   - **Easiest:** in VS Code, open **Terminal → New Terminal**. It opens at your repo root. Paste the macOS or Windows command below. It merges the files into your repo and doesn't delete anything.
   - ⚠️ **Don't drag `docs`, `.copilot-tracking` or `workshop-output` onto your repo's folders of the same name.** If VS Code asks whether to **Replace** a *folder*, choose **Cancel**: Replace deletes the existing folder first, including the workshop's own docs.
   - **macOS Terminal**, from your repo root: `cp -R ~/Downloads/Pack-C-after-Step-7/repo-files/. .`
   - **Windows (PowerShell, the VS Code default)**, from your repo root: paste this single line. It finds the unzipped pack under `Downloads`, merges everything from `repo-files` into your repo (never deletes; skips `READ-ME-FIRST.txt`), and prints `OK - copied from …`. If the terminal prompt doesn't start with `PS`, it's cmd.exe: type `powershell`, press Enter, then paste.
     ```powershell
     $pack='Pack-C-after-Step-7'; $src=(Get-ChildItem "$HOME\Downloads" -Directory -Recurse -Depth 3 -Filter repo-files -ErrorAction SilentlyContinue | Where-Object FullName -like "*$pack*" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName; if (-not (Test-Path workshop)) { 'STOP: run this in the VS Code terminal of your workshop repo (the folder with docs, workshop, workshop-output)' } elseif (-not $src) { "STOP: $pack not found under $HOME\Downloads - unzip the pack there first" } else { robocopy "$src" . /XF READ-ME-FIRST.txt /E /NFL /NDL /NJH /NJS /NP; if ($LASTEXITCODE -lt 8) { "OK - copied from $src" } else { "ERROR: robocopy exit code $LASTEXITCODE" } }
     ```
   - The macOS command also copies `READ-ME-FIRST.txt` into your repo; delete it from your repo root afterwards. The Windows command skips it.
   - `.copilot-tracking` is hidden in Finder. Press **Cmd+Shift+.** to show it.
3. If you have your own BRD or self-test files with the same names, rename them first, for example by adding `-ours`.

## Step 7: review and approve (if you're catching up)
Open `workshop/05-common/STEP-07-REVIEW-CARD.md` and check the BRD against:
- the BRD skeleton;
- the Decision Rubric;
- the Gate Record;
- the Artifact Checklist.

Decide: *is anything an approval blocker, or is every open item a governed gate?* If you agree, your decision is: **"Approve as the workshop BRD planning baseline; GATE-001…007 stay open."**

## Resume in Step 8 with PRD Builder

1. Open a **new** Copilot Chat and select **PRD Builder** (`hve-core:prd-builder`).
2. Attach these files with **Add Context** or `#file`:
   - `docs/project-planning/portfolio-tracker-brd.md`
   - `docs/project-planning/portfolio-tracker-brd-to-prd-handoff.md`
   - `.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml`
   - `workshop/05-common/PRD-SKELETON.md`
   - `docs/DECISION-RUBRIC.md`
   - `docs/ARTIFACT-CHECKLIST.md`
   - `docs/GATE-RECORD.md`
3. Paste:

```text
Create a PRD (name: portfolio-tracker) from the attached approved BRD (BRD-2026-Q4-001 v1.0.0, approved as the workshop BRD planning baseline) and its BRD→PRD handoff. No new discovery, no architecture (no APIs, data models, technology or provider choices), no tracker upload, no RPI. Carry every BRD gate (GATE-001 to GATE-007) forward as Open with all Gate Record fields — don't close any by assumption. Keep exclusions and deferred scope explicit (trading, advice, forecasts, tax reporting, goal tracking, real personal financial data; composition breakdown and main-screen FX remain alternatives/deferred, not committed). Give FR IDs (FR-###) that each trace to BR IDs, with testable acceptance boundaries. Preserve evidence labels and low confidence; Iteration 2 recovery stays an unvalidated redesign hypothesis. I am the Product Owner and sign-off authority for this workshop planning baseline. Keep success metrics/NFRs proportionate — no invented targets or SLOs. Ask me only what you genuinely need.
```

4. Then follow Step 8 (`workshop/05-common/STEP-08-PRD.md`). Approve explicitly as the product planning baseline for Epic/Feature decomposition, with gates carried forward as Open. Make sure the PRD is **saved as a file**.

**Running short on time?** At 15:28, **Pack D** has an approved PRD.
