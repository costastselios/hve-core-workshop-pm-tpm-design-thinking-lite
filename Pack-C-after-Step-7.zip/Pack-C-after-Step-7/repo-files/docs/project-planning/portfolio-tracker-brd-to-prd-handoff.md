# Portfolio Tracker BRD-to-PRD Handoff

## Authority and use

Source: [BRD-2026-Q4-001, version 1.0.0](portfolio-tracker-brd.md).
Canonical machine-readable manifest:
[portfolio-tracker.handoff.yml](../../.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml).
The manifest records the exact approved BRD SHA-256, Govern report, counts and
coverage. It must validate before this handoff is consumed.

**Decision (not evidence):** The Workshop Product Owner approved the **workshop
BRD planning baseline only** at 2026-11-17T09:55:28.411Z. This is not research
validation, gate closure, financial-correctness approval or engineering
authorization. All seven gates below remain **Open**. Govern publication is
limited to that scope and requires the linked Govern report to permit release.

**WVR-001:** The same Product Owner owns and grants the waiver for non-SMART
BG-001, BG-002 and BG-003, solely for this workshop planning baseline. Rationale:
no baselines or targets exist and none will be invented. Governance: GATE-005.
Expiry: at the GATE-005 next decision trigger or before any outcome-performance
commitment, whichever occurs first. No calendar expiry is invented. SMART
remains **FAIL**; the unwaived Define-exit result is not relabelled PASS.
Neither the waiver nor planning approval closes any gate.

**Evidence:** Two supplied participant summaries remain low-confidence,
directional and establish no prevalence. The separate Iteration 1 supplied
participant-test summary does not establish representative validation or source
independence. Iteration 2 is an adopted redesign hypothesis with PO self-test
only, not participant-validated or verified financial processing. Preserve
Evidence / Decision (not evidence) / Assumption / Open question and the
[BRD source register](portfolio-tracker-brd.md#evidence-and-source-register).

## Shared inherited boundaries

Every row below inherits **CON-001, CON-002 and CON-003**, without exception:

- **CON-001:** No trading/order execution, investment advice, forecasts, tax
  reporting or goal tracking. Recording factual purchases/sales is not executing
  trades. Cost-basis uncertainty does not authorize tax or new analytics scope.
- **CON-002:** No real personal financial data; safe synthetic/non-identifying
  workshop material only, no live holdings, credentials, balances or account IDs.
- **CON-003:** No architecture, implementation, restarted discovery or RPI
  research segment. This task creates no PRD and starts no RPI or tracker handoff.

RULE-001 through RULE-003 remain binding planning policies: attribution,
no invented history and review before commitment. NFR-001 through NFR-003
remain inherited quality boundaries, not claims that testing passed.
All AC-001 through AC-017 are **Not Started**. All BRs retain MUST priority,
PO ownership and existing goal/decision links; no requirement is renumbered.

## Per-BR routing

The destination column names **future product requirement/decision topics**, not
authored PRD requirements, assigned product IDs, completed decisions or work
items. Product elaboration must retain each BR source ID and its AC boundary.
Detailed wording/flows remain product decisions under the named gates, not
permission to reopen or silently expand approved business scope.

| Source ID / existing DT basis | Business intent | Destination product requirement/decision (not created) | Acceptance boundary | Inherited exclusions | Inherited gates, all Open | Unresolved product decision |
| ------------------------------ | ----------------- | ------------------------------------------------------- | --------------------- | ---------------------- | --------------------------- | ----------------------------- |
| BR-001; P02-E2/E3; DT-5; DD-003 | Establish an attributable position baseline without claiming earlier history. | Future establishment/review requirement; decide statement coverage and unsupported-field handling. | AC-001/002: broker/source, date, asset, units, currency and limits reviewable; no invented pre-baseline history; cancel applies nothing. | CON-001, CON-002, CON-003 | GATE-003, GATE-005, GATE-007 | Which statement formats/assets establish sufficient starting evidence, and how are unsupported baselines dispositioned? |
| BR-002; P01-E1; P02-E1; DT-1; CAN; DD-002/003 | Explain what is held, where and its dated AED valuation/status. | Future consolidated-portfolio requirement; decide supported view content and qualified-total semantics. | AC-003: each scenario holding retains broker/type/native currency and dated AED value or explicit unvalued state; exclusions identify partial totals. | CON-001, CON-002, CON-003 | GATE-001, GATE-003, GATE-004, GATE-005, GATE-007 | Which holdings/dates can be valued with rights and what counts as a complete versus partial total? Composition is not silently added. |
| BR-003; P01-E3; P02-E4; CAN; DT-5; DD-002/004 | Preserve bounded factual history and distinguish corrections from source facts. | Future factual-history requirement; decide baseline intervals and correction representation. | AC-004: unsupported earlier intervals explicit; no invented transactions/forecasts; corrections distinguishable. | CON-001, CON-002, CON-003 | GATE-003, GATE-004, GATE-005, GATE-007 | What historical coverage/methodology is supportable, including corrected and uncertain periods? |
| BR-004; P02-E2/E3; DT-3; CAN; DD-003 | Maintain through reviewed imports rather than forced repetitive re-entry. | Future staged-import requirement; decide supported records, duplicate/conflict disposition and accepted-set rules. | AC-005/006: included/excluded/unresolved dispositions explicit; unresolved rows cannot silently enter accepted set; cancel applies nothing. | CON-001, CON-002, CON-003 | GATE-003, GATE-005, GATE-007 | How are duplicate uncertainty, unsupported records and conflicts dispositioned within the supported formats? |
| BR-005; P01-E4 versus P02-E2; DT-3; DD-003 | Preserve occasional manual fallback without making maintenance import-only. | Future manual-maintenance requirement; decide reviewable activity/evidence fields. | AC-007: dated/source-labelled intended effect reviewable and cancellable; unconfirmed proposals do not change accepted records. | CON-001, CON-002, CON-003 | GATE-003, GATE-005, GATE-007 | Which manual activities and source-quality limitations are supported without silently assuming historical completeness? |
| BR-006; P01-E2; P02-E3; DD-003 | Update attributable prices/FX without repeatedly re-keying each input. | Future sourced-input requirement; decide provider scope and update policy. | AC-008: approved available inputs retain source/time without re-keying each; unavailable is explicit, never invented. | CON-001, CON-002, CON-003 | GATE-001, GATE-004, GATE-005, GATE-007 | Which providers, assets/currencies/dates, licensed uses, costs and update frequencies are supportable? |
| BR-007; P01-E2; P02-E3; DT-1; CAN; DD-002 | Explain valuation inputs, conversion and effective-time context. | Future inspectable-provenance requirement; decide calculation receipt and unavailable/not-applicable states. | AC-009: position/price/FX evidence and times, rate direction, reporting currency and basis distinguishable on demand or explicitly unavailable. | CON-001, CON-002, CON-003 | GATE-001, GATE-004, GATE-005, GATE-007 | Which provenance is available/licensed and how are differing input times explained? Main-screen FX remains an alternative, not a requirement. |
| BR-008; CAN; SELF Iteration 1 only; DT-6C; DD-002/004 | Prevent fresh inputs from implying verified holdings or complete history. | Future uncertainty/overview-status requirement; decide distinct freshness, position and history semantics. | AC-010/011: qualify stale/missing/partial values and totals; unresolved mismatch/history visible at overview, not hidden by unqualified freshness. | CON-001, CON-002, CON-003 | GATE-004, GATE-005, GATE-006, GATE-007 | What stale/missing policy and aggregate status vocabulary users understand? The overview concern remains self-test-only, not a verified fix. |
| BR-009; I1; DT-6A; R2; DD-004 | Make conflict and current/history consequences understandable before recovery. | Future conflict/cause/preview requirement; decide cause judgment and consequence-review interaction. | AC-012/013: evidence conflict and impacts distinguishable before cause choice; branch changes/non-changes/uncertainty reviewable before confirmation; cancel applies nothing. | CON-001, CON-002, CON-003 | GATE-002, GATE-003, GATE-005, GATE-007 | Can representative users judge known/unknown cause and predict consequences, including mistaken-cause cases? Completion is not comprehension. |
| BR-010; R2; DT-6B; SELF separately; DD-004 | Repair evidence-backed missing activity without changing unrelated records. | Future known-cause recovery requirement; decide acceptable cause evidence and affected-history recalculation rules. | AC-014: record evidenced missing activity, recalculate affected history only, preserve unrelated records/other uncertainty; difference alone does not establish cause. | CON-001, CON-002, CON-003 | GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 | What proves a cause, which history is affected and how are wrong assertions corrected? No processing correctness has been validated. |
| BR-011; R2; DT-6B D2; DD-004 | Verify today's holding without asserting an unknown historical cause. | Future unknown-cause verification requirement; decide dated/source-linked current-verification representation. | AC-015: today's verification attributable and dated; historical transactions unchanged; no invented explanatory transaction. | CON-001, CON-002, CON-003 | GATE-002, GATE-003, GATE-005, GATE-007 | What evidence suffices to verify today, and can users distinguish that from complete history? Silent overwrite is not an active alternative. |
| BR-012; DT-6B; SELF Iteration 2 open questions; DD-004 | Keep recovery consequences and unresolved history understandable on later review. | Future recovery-result/history-continuity requirement; decide mistaken-cause correction and persistent uncertainty handling. | AC-016/017: effects/non-effects/uncertainty identifiable later; no implied verified gain/loss/cost basis; mistaken assertion traceable for governed correction. No new analytics views required. | CON-001, CON-002, CON-003 | GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 | How are mistaken causes corrected and uncertain history interpreted later without invented facts or expanded tax/analytics scope? |

## Inherited gate records

The complete records are incorporated by reference to the **exact approved BRD
bytes pinned by the standard handoff SHA-256**, not to an unversioned future
decision. All eight fields (Gate ID, Title, Owner, Status, Affected
requirements/features, Exit evidence, Next decision trigger, Remaining
uncertainty) remain authoritative and mandatory. The YAML handoff also carries
complete structured copies. A later PRD/extract must preserve these records,
not substitute a feature label or silently close them.

| Gate / complete record | Owner | Status | Carry-forward effect |
| ------------------------ | ------- | -------- | ---------------------- |
| [GATE-001: Provider coverage and licensing](portfolio-tracker-brd.md#gate-001) | Workshop Product Owner | Open | No source/rights/coverage commitment until exit evidence and PO decision. |
| [GATE-002: Recovery validation](portfolio-tracker-brd.md#gate-002) | Workshop Product Owner | Open | Iteration 2 remains a hypothesis; known/unknown/mistaken-cause comprehension and later interpretation unvalidated. |
| [GATE-003: Import/baseline and methodology](portfolio-tracker-brd.md#gate-003) | Workshop Product Owner | Open | Supported formats/assets/history, fractions, fees, duplicates, corporate actions and corrections require reviewed boundaries. |
| [GATE-004: Valuation/FX meaning](portfolio-tracker-brd.md#gate-004) | Workshop Product Owner | Open | Cutoffs, timezones/crypto timing, FX direction, precision, stale/missing policies and uncertainty propagation unresolved. |
| [GATE-005: Outcome measurement/context](portfolio-tracker-brd.md#gate-005) | Workshop Product Owner | Open | Inherited by every BR; WVR-001 expires at its next trigger or before outcome-performance commitment. No proven benefit/prevalence. |
| [GATE-006: Overview trust consistency](portfolio-tracker-brd.md#gate-006) | Workshop Product Owner | Open | Self-test concern, no participant finding or verified fix; status semantics and comprehension require explicit disposition. |
| [GATE-007: Viability/operation](portfolio-tracker-brd.md#gate-007) | Workshop Product Owner | Open | Inherited by every BR; no investment, support or operational commitment from planning approval. |

## Consumer checkpoint

Validate the standard manifest's BRD hash, version, prefix map, waived signoff,
Govern report, waiver expiry and all open gate records before use. Preserve the
12 BR / 17 AC / 3 NFR / 3 CON / 3 RULE / 3 BG counts and both 100.0% authored
traceability measures; these are not test-pass rates. Product Owner remains the
decision owner; brokers and price/FX providers are data sources, not users or
signatories. No new evidence, PRD, RPI or tracker artifact is created here.
