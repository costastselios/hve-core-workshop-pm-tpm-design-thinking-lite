---
brd_id: "BRD-2026-Q4-001"
title: "Portfolio Tracker Business Requirements"
status: "in-review"
version: "0.1.0"
owners: ["Workshop Product Owner (requesting user)"]
reviewers: ["Workshop Product Owner (requesting user)"]
created_date: "2026-11-17"
last_updated: "2026-11-17"
business_goal_ids: ["BG-001", "BG-002", "BG-003"]
business_goal_smart_status: "deferred"
fr_to_ac_coverage_threshold_pct: 80.0
diagram_format: "none"
lineage:
  supersedes: []
  superseded_by: []
  last_brd_id: null
requirement_id_prefixes:
  fr: "BR"
  ac: "AC"
  nfr: "NFR"
  con: "CON"
  br: "RULE"
license: "CC-BY 4.0 (Microsoft HVE-Core)"
---

# Portfolio Tracker Business Requirements

> **BRD-2026-Q4-001** | In review | Version 0.1.0 | 2026-11-17
>
> Proposed workshop planning baseline; **not yet approved**. No architecture,
> engineering authorization, validated research, or financial-correctness claim.

## Executive Summary

The proposed business outcome is factual, trustworthy consolidated understanding
of what a self-directed multi-broker investor holds, where it is held, its value,
how that value was calculated, and as of when. Sustainable maintenance and
understandable valuation are the focus, not investment performance.

**Evidence:** Two supplied participant summaries provide low-confidence,
directional signals. P01 describes manual consolidation and reduced trust in
manually maintained closing values/FX; P02 rejects repetitive re-entry and prefers
imports, review before commitment, and automatic prices/FX. Both mention factual
history and facts over forecasts. Neither these records nor the separate
Iteration 1 test summary establish prevalence, market growth, or representative
validation. No participant counts or independence are inferred for that test.

**Decision (not evidence):** Carry forward the canonical combined concept and
the Product Owner-adopted Iteration 2 recovery model. Import-first/manual fallback
and AED reporting remain local workshop choices. Unknown-cause recovery verifies
today without rewriting historical transactions; silent overwrite is dropped.
Iteration 2 remains a redesign hypothesis, supported only by a Product Owner
self-test, not representative-user results or working financial processing.

The primary candidate outcome measure is maintenance effort per comparable
portfolio-update task; baseline, meaningful target, measurement protocol, and
evaluation date are **not established**. GATE-005 governs those decisions.
Acceptance conditions below are proposed review boundaries, not measured
benefits. Open dependencies are governed gates, not silently satisfied promises.

## Business Context

### Problem and evidence boundary

**Assumption:** A factual cross-broker record may make maintenance sustainable
across purchase cadences while making valuation/FX understandable and trustworthy.
Problem magnitude, adoption, payment, support burden, and operating viability
are unknown. The month-end spreadsheet story, stale-FX error, and growth in
multi-app investing remain fictional or untested; none is a business-case fact.

The completed DT outputs are the intake evidence base. Discovery is **not**
restarted. Methods 2-6 were completed under bounded workshop criteria; Method 1
was provisional and full HVE research/validation gates remain unmet. The present
request authorizes BRD authoring, not a retrospective upgrade to DT validation.
RPI research is declined by the Product Owner; none is proposed or initiated.

### Scope and exclusions

| Boundary | Workshop baseline |
| ---------- | ------------------- |
| In scope | Source-attributed establishment, consolidated holdings, factual dated history, reviewed import, manual maintenance fallback, inspectable valuation/FX, explicit uncertainty, conflict understanding and evidence-appropriate recovery. |
| Scenario, not researched segment | Fictional self-directed investor without an adviser; three brokers; stocks, ETFs and some crypto; USD/EUR/AED inputs and AED reporting. Coverage is conditional on GATE-001 and GATE-003, not a provider commitment. |
| Excluded | Trading/order execution, investment advice or recommendations, forecasts, tax reporting, goal tracking, and any real personal financial data. |
| Not specified | Architecture, integrations, storage, technology, APIs, implementation tasks, delivery dates, budgets, or service-level commitments. |
| Not silently promoted | Composition is P02-specific and not a committed breakdown requirement. Main-screen FX source/as-of remains an alternative to baseline on-demand provenance. Fully connected/import-only and entirely manual operation are not the selected baseline. |

### Evidence and source register

Paths are relative to this BRD. Source IDs below are locators, not new independent
evidence. Preserve **Evidence / Decision (not evidence) / Assumption /
Open question** in downstream use.

| Source ID | Artifact and locator | Label and limit |
| ----------- | ---------------------- | ----------------- |
| DT-H | [DT-to-BRD handoff](../../.copilot-tracking/dt/portfolio-tracker/dt-to-brd-handoff.md), M1-M6 and candidate gates | Evidence-labelled synthesis/intake, not approved requirements. |
| DT-S | [DT state](../../.copilot-tracking/dt/portfolio-tracker/coaching-state.md), qualifications and decision history | Decision history; workshop completion is not validation. Historical stop instructions remain historical. |
| DT-1 | [Scope notes](../../.copilot-tracking/dt/portfolio-tracker/method-01-scope-notes.md), Product Owner input and exit check | Decisions, fictional assumptions, and open questions; not observed incidents. |
| P01 | [Participant 01 summary](../../workshop/02-research-evidence/participant-01-research-summary.md), narrative paragraph | Evidence: supplied summary, low confidence, single participant; no transcript/verbatim quotes. |
| P02 | [Participant 02 summary](../../workshop/02-research-evidence/participant-02-research-summary.md), narrative paragraph | Evidence: supplied summary, low confidence, single participant; no transcript/verbatim quotes. |
| DT-2 | [Source-located register](../../.copilot-tracking/dt/portfolio-tracker/method-02-research/findings-summary.md), P01-E1-E5 and P02-E1-E4 | Paraphrases of P01/P02 only. Dates, recruitment, consent, setting and collection independence not supplied; received date is not collection date. |
| DT-P | [Research plan](../../.copilot-tracking/dt/portfolio-tracker/method-02-research/research-plan.md), protocol and confidence rules | Decision/methodology, not evidence that planned observations occurred. |
| DT-3 | [Synthesis](../../.copilot-tracking/dt/portfolio-tracker/method-03-synthesis/synthesis.md), shared/individual signals and PO decisions | Low-confidence interpretation; preserves occasional versus repetitive entry distinction. |
| DT-4 | [Direction mapping](../../.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/theme-clusters.md) and [16 ideas](../../.copilot-tracking/dt/portfolio-tracker/method-04-brainstorming/divergent-ideas.md) | Decision: three directions selected for comparability; ideas are untested possibilities, not committed features. |
| DT-5 | [Original concept](../../.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/our-concept.md), [cards](../../.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concepts.yml), [comparison](../../.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/concept-comparison.md) and [historical handoff](../../.copilot-tracking/dt/portfolio-tracker/method-05-user-concepts/method-06-handoff.md) | Assumptions/decisions/alternatives; earlier tentative overwrite is superseded by DT-6B, not deleted. |
| CAN | [Canonical concept](../../workshop/03-concept-checkpoint/canonical-concept-snapshot.md), journey and trust | Decision: shared baseline, evidence-informed not validated. |
| I1 | [Iteration 1 supplied participant-test summary](../../workshop/04-prototype/iteration-01/test-results.md), Provenance/Finding | Evidence: low-confidence directional summary; raw notes/run ID absent, representative validation unestablished. Not assumed independent of P01/P02. |
| SELF | [Product Owner self-test](../../workshop-output/prototype-self-test.md), separate iteration tables | Evidence: workshop observation only, not representative-user research. Embedded participant references repeat I1. |
| R2 | [Iteration 2 recovery model](../../workshop/04-prototype/iteration-02/recovery-model.md), model/status | Assumption: redesign hypothesis, not a test result. |
| DT-6A | [Iteration 1 learning](../../.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-01-learning.md), source register and failure | Low-confidence interpretation: completion was not comprehension; overview mismatch is self-test-only. |
| DT-6B | [Iteration 2 learning](../../.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/iteration-02-learning.md), D2 and branch table | Decision (not evidence): PO adopts R2 and drops silent overwrite. No Iteration 2 participant results. |
| DT-6C | [Constraint discoveries](../../.copilot-tracking/dt/portfolio-tracker/method-06-lofi-prototypes/constraint-discoveries.md) | Conceptual/evidence boundaries; no runtime-correctness certification. |
| TEST | [Prototype script](../../workshop/04-prototype/test-script.md), fixed-data notice and B3/C1-C3 | Protocol, not results. Supplied [Iteration 1](../../workshop/04-prototype/iteration-01/index.html) and [Iteration 2](../../workshop/04-prototype/iteration-02/index.html) are fixed-data illustrations, not calculation/persistence evidence. |
| PO-20261117 | User's BRD creation instruction, 2026-11-17; recorded in the accompanying state | Decision (not evidence): ownership, boundaries, no discovery restart/research/architecture, complete gates and stable BR IDs. Not approval of the unseen BRD. |

## Stakeholders

Role-based identification is sufficient for this workshop: **Workshop Product
Owner (requesting user)** uniquely identifies the accountable person here.
Unappointed specialists are not invented approvers.

| ID / party | Relationship | Power / interest | Engagement and accountability |
| ------------ | -------------- | ------------------ | ------------------------------- |
| STK-001: self-directed multi-broker investor | Primary user; not the Product Owner | Low formal decision power / high intended interest (planning classification) | Consult through appropriately consented representative-user validation, especially GATE-002. P01/P02 are limited supplied perspectives, not a representative panel. |
| STK-002: Workshop Product Owner (requesting user) | Product Owner, decision owner and sole planning-baseline sign-off authority | High / high | Accountable and responsible for BRD decisions, all gates, acceptance review and approval. May obtain specialist input without transferring accountability implicitly. |
| STK-003: brokers | Data sources, not assumed users or approvers | Potentially high dependency influence / interest unknown | Obtain sourceable format, coverage and access evidence through the PO for GATE-001/003; no broker commitment or interview claimed. |
| STK-004: price/FX data providers | Data sources, not assumed users or approvers | Potentially high dependency influence / interest unknown | PO obtains dated coverage/rights/cost evidence for GATE-001/004. Interest and licensed access unverified. |

Accountant/partner involvement is unconfirmed and outside the current user scope.
Accessibility/context needs and financial/data-rights expertise remain coverage
gaps under GATE-003/005/007; no jurisdiction is inferred from AED reporting.
There is exactly one accountable owner per requirement and gate: STK-002.

## Design Decisions

These are business/scope decisions, not architecture. Every row follows the
[Product Decision Rubric](../DECISION-RUBRIC.md). Confidence concerns supporting
evidence, not whether an instruction was recorded accurately.

| ID | Decision | Basis | Confidence | Status | Impact | Remaining uncertainty |
| ---- | ---------- | ------- | ------------ | -------- | -------- | ----------------------- |
| DD-001 | Use completed DT context without restarting discovery or initiating RPI research. | PO-20261117; DT-H; DT-S. | Low empirical confidence; explicit instruction. | Adopted for authoring. | Evidence limits carry forward; this is not a full-validation gate pass. | Broader context, magnitude and outcomes remain GATE-005/007. |
| DD-002 | Use canonical combined concept and journey; keep provenance on demand and uncertainty explicit. | CAN; DT-5 comparison; DT-4 direction selection. | Low; concept not validated. | Adopted workshop baseline. | BR-002/003/007/008/009; no fixed screen/button design. | Comprehension; main-screen FX remains an alternative, not a silently merged requirement. |
| DD-003 | Carry import-first with manual fallback and local AED scenario forward; statement-first is the local establishment choice, not canonical wording. | DT-1/3/5; P01-E4; P02-E2/E3. | Low; preferences do not prove effectiveness. | Retained local planning choices. | BR-001/002/004/005/006; neither import-only nor automatic broker connections committed. | Statement sufficiency, coverage and rights: GATE-001/003/004. |
| DD-004 | Adopt Iteration 2 recovery; unknown cause verifies today only; drop silent overwrite. | I1 -> DT-6A concept failure -> R2 -> DT-6B D2; SELF separately. | Low; redesign unvalidated. | Adopted by PO in DT, not participant-validated. | BR-009/010/011/012; historical drafts preserved. | Known/unknown/mistaken-cause comprehension and financial consequences: GATE-002/003/004. |
| DD-005 | Use stable BR IDs for business capabilities; keep standing rules distinct as RULE IDs. | PO-20261117; workshop BRD skeleton; configurable canonical prefixes. | Authoring convention, not empirical evidence. | Adopted. | `fr: BR`, `br: RULE`; no duplicate FR aliases or semantic conflation. Never renumber existing IDs; retire rather than reuse. | Downstream consumers must honor the recorded prefix map. |
| DD-006 | Draft for workshop planning-baseline review only; keep complete open gates, not implied commitments. | PO-20261117; workshop Step 7; Gate Record; Decision Rubric. | Governance decision, not validation. | Awaiting approval of this document. | Dependencies may remain open at planning approval; no engineering authorization or automatic gate closure. | PO has not yet reviewed or signed off version 0.1.0. |

## Business Goals

**Assumption:** These are intended investor outcomes, not proven benefits.
STK-002 owns each goal. No numeric improvement, baseline, research success rate
or deadline is invented from the two summaries.

| ID / intended outcome | Priority | Candidate measure / measurement source | Baseline / target / timeframe | Evidence and evaluation gate |
| ----------------------- | ---------- | ----------------------------------------- | ------------------------------- | ------------------------------ |
| BG-001: Make maintaining a factual cross-broker record sustainable across purchase cadences. | MUST | Effort and repeated-entry steps per comparable update task; consented synthetic task observations and non-sensitive user accounts of current practice. Protocol not yet agreed. | Baseline not measured; target not agreed; evaluation date not set. Decide all before outcome evaluation, under GATE-005. | P01-E4; P02-E1/E2/E3; DT-3/4; adoption/operating feasibility GATE-007. |
| BG-002: Enable the investor to explain holdings, valuation/FX basis and as-of context without mistaking incomplete information for certainty. | MUST | Explanation of source, time, conversion and uncertainty during synthetic tasks; source-located observations scored against a PO-approved rubric. | Baseline not measured; target/rubric and date not agreed. GATE-004/005 must set them before claiming benefit. | P01-E1/E2/E3; P02-E1/E3/E4; DT-1 outcome choice; CAN. |
| BG-003: Enable evidence-appropriate recovery while distinguishing current correctness from historical completeness. | MUST | Pre-action prediction, branch selection, post-action explanation and later interpretation for known, unknown and mistaken-cause tasks. | I1 reports a failure but supplies no rate/baseline. Target, protocol and date must be agreed before GATE-002 validation. | I1; SELF separately; R2 hypothesis; DT-6A/B/C; GATE-002/003. |

**SMART status: deferred.** Specific and relevant intent is stated; measured
baselines, agreed targets, achievability and dated evaluation are not established.
This is a visible qualification on the workshop draft, not SMART compliance or
a waiver. Outcome-performance commitments require GATE-005 closure. The formal
Define-to-Govern gate requires every goal to pass SMART and remains blocked;
bounded workshop planning-baseline approval does not pass or waive that gate.

### Outcome Hypothesis Handoff Provenance

Not applicable: no `OUTCOME_HYPOTHESIS_TO_BRD_HANDOFF_V1` payload was supplied.
DT-H is an evidence-labelled DT context handoff, not that schema. It is not
reclassified or given fabricated KPI provenance.

## Business Rules

All rules are **proposed operational policies / Decision (not evidence)**,
mandatory within this baseline if approved, owned by STK-002.

| ID | Standing rule | Rationale / source | Enforcing requirements |
| ---- | --------------- | -------------------- | ------------------------ |
| RULE-001 | Recorded facts shall remain attributable to their evidence or explicitly identified as unsupported. | Trustworthy factual record; DT-1 outcome, CAN. | BR-001, BR-003, BR-005, BR-006, BR-007, BR-012. |
| RULE-002 | Evidence of today's position shall not be represented as proof of unknown historical activity or historical completeness. | No invented history; R2 and DT-6B D2. | BR-003, BR-008, BR-009, BR-010, BR-011, BR-012. |
| RULE-003 | Proposed portfolio changes shall require review and confirmation before taking effect. | Review before commitment; P02-E3 preference and DT-3/5/6B decisions. | BR-001, BR-004, BR-005, BR-009, BR-010, BR-011. |

## Functional Requirements

**BR-### are business capability requirements**, the configured functional
family, not standing rules. All are MUST for this proposed bounded baseline,
owned by STK-002 and serving STK-001. MUST is prioritization, not proof of
feasibility or delivery authorization. All acceptance is **Not Started**.
Actors are the investor unless stated otherwise. The table records the trigger,
observable obligation and outcome; links to goals and evidence follow below.
Gate-dependent behavior cannot be treated as available until its gate closes.

The **Dependency gates** column lists direct behavior dependencies. In addition,
**every BR-001 through BR-012 inherits GATE-005 (outcome commitments) and GATE-007
(viability/investment)** from the gate register. These baseline-wide dependencies
must accompany each requirement in downstream extracts; omission from a table
cell is not an exemption or gate closure.

| ID / capability | Trigger and requirement statement | Acceptance | Dependency gates |
| ----------------- | ----------------------------------- | ------------ | ------------------ |
| BR-001: Establish from attributable evidence | When the investor submits a synthetic starting statement, the Portfolio Tracker shall present a reviewable starting-position proposal with broker/source, evidence date, asset, units, currency and coverage limits, so the accepted baseline does not imply pre-baseline history. | AC-001, AC-002 | GATE-003 |
| BR-002: Consolidated factual orientation | When the investor opens the established portfolio, the Portfolio Tracker shall present a consolidated view identifying holdings, broker, asset type, native currency and dated AED valuation/status, so the investor can answer what is held and where without mistaking partial valuation for a complete total. | AC-003 | GATE-001, GATE-003, GATE-004 |
| BR-003: Bounded factual history | When the investor inspects history, the Portfolio Tracker shall distinguish recorded dated facts, corrections and unsupported intervals, so the history does not invent activity or imply forecasts. | AC-004 | GATE-003, GATE-004 |
| BR-004: Reviewed import maintenance | When an update file is submitted, the Portfolio Tracker shall stage proposed changes for review and explicit disposition of possible duplicates, conflicts and unsupported records before confirming an accepted set, so repetitive re-entry is not the only maintenance path. | AC-005, AC-006 | GATE-003 |
| BR-005: Manual maintenance fallback | When import is unavailable or occasional manual entry is chosen, the Portfolio Tracker shall offer a source-attributed, dated manual-change proposal for review before confirmation, so the investor is not restricted to import-only maintenance. | AC-007 | GATE-003 |
| BR-006: Sourced price/FX updates | When an approved valuation update is requested, the Portfolio Tracker shall obtain available price/FX inputs for the agreed coverage without repeated manual rate/price entry, so valuations can use attributable inputs rather than unlabelled manual assumptions. Unsupported coverage shall be explicit, not treated as fulfilled automation. | AC-008 | GATE-001, GATE-004 |
| BR-007: Inspectable valuation provenance | When the investor inspects a displayed valuation, the Portfolio Tracker shall expose its position basis, price source/effective time, FX source/effective time/rate direction where conversion applies, reporting currency and calculation basis or explicit unavailable status, so the value can be explained. | AC-009 | GATE-001, GATE-004 |
| BR-008: Explicit uncertainty and overview consistency | When inputs are stale, missing, disputed or historically incomplete, the Portfolio Tracker shall qualify the affected holding and portfolio summary, so a freshness claim is not mistaken for verified holdings or complete history. | AC-010, AC-011 | GATE-004, GATE-006 |
| BR-009: Understand conflict before recovery | When recovery is considered, the Portfolio Tracker shall explain conflicting evidence and current versus historical impact, ask whether the cause is known, and preview the chosen branch's effects, non-effects and remaining uncertainty before confirmation, so completion is not substituted for informed understanding. | AC-012, AC-013 | GATE-002, GATE-003 |
| BR-010: Known-cause recovery | When the investor provides evidence of missing activity and confirms its preview, the Portfolio Tracker shall record that activity and recalculate only affected history under the agreed methodology, so explained differences can be repaired without changing unrelated records. | AC-014 | GATE-002, GATE-003, GATE-004 |
| BR-011: Unknown-cause verification | When the investor knows today's holding but not the historical cause and confirms its preview, the Portfolio Tracker shall record a dated, attributable verification of today's position without rewriting historical transactions or inventing explanatory activity. | AC-015 | GATE-002, GATE-003 |
| BR-012: Recovery consequence continuity | When the investor reviews a recovery result or later revisits the holding/history, the Portfolio Tracker shall preserve the distinction between the verified current position, recorded historical changes and unresolved historical uncertainty, so verification today is not mistaken for verified history. | AC-016, AC-017 | GATE-002, GATE-003, GATE-004 |

## Non-Functional Requirements

These are reviewable quality boundaries, not performance or implementation
commitments. STK-002 owns each; all are MUST and Not Started.

### Functional Suitability

**NFR-001:** For the finite synthetic valuation/import/recovery case set approved
under GATE-003/004, every case shall reconcile with its independently reviewed
expected result or show the documented unsupported/uncertain state; no unexplained
difference may be represented as verified. Verification: case-by-case comparison,
with precision, rounding and tolerances decided in those gates, not invented here.
Links: BG-002/003; BR-002/004/006/007/010/011; RULE-001/002.

### Performance Efficiency

Not specified: no supported latency, update-frequency, load or volume evidence.
Any required outcome boundary must be justified before feature commitment through
GATE-004/005/007; no arbitrary SLA is introduced.

### Compatibility

Import-format/asset compatibility is conditional on the explicit support matrix
and unsupported-case outcomes in GATE-003. No universal broker compatibility.

### Usability

**NFR-002:** Before recovery comprehension is represented as validated, a
PO-approved, consented representative-user protocol shall record each tested
person's conflict/cause interpretation, branch choice, predicted effect,
post-action explanation and later uncertainty interpretation for known,
unknown and mistaken-cause scenarios. Report all failures and apply the success
criteria agreed **before** testing; clicking completion alone is insufficient.
Verification: source-located observation review at GATE-002; no self-test
substitution. Links: BG-003; BR-009/010/011/012; I1, R2, DT-6B.

### Reliability

**NFR-003:** In every agreed synthetic unknown-cause recovery case, historical
transaction records shall be unchanged before versus after confirmation, and
the unresolved historical state shall remain visible on later review.
Verification: compare records and observed outcomes; fixed-data confirmations
alone cannot pass this condition. Links: BG-003; BR-011/012; RULE-002;
AC-015/016; GATE-003.

### Security

CON-002 prohibits real personal financial data in all workshop inputs and
outputs. No production security posture or compliance approval is claimed;
production controls are outside this baseline.

### Maintainability

Not specified: no engineering design is authorized. Stable BR IDs and attributable
decision/gate history are document-governance obligations, not a software design.

### Portability

Not specified: no deployment/platform or portability promise is made.

## Constraints

Each is MUST, imposed by PO-20261117, owned by STK-002 and non-negotiable within
this workshop scope; exceptions require an explicit PO scope revision, not an
assumption made downstream.

| ID | Constraint | Category / boundary | Reviewable acceptance and impact | Goal |
| ---- | ------------ | --------------------- | ---------------------------------- | ------ |
| CON-001 | No trading, investment advice, forecasts, tax reporting or goal tracking. | Operational / scope. | Inspect every requirement, scenario and output: none executes/orders trades, recommends investments, predicts returns, produces tax reports or tracks investor goals. Factual recorded buys/sells are history, not order execution. Cost-basis questions do not expand scope. | BG-002 |
| CON-002 | No real personal financial data. | Operational / data. | Every workshop fixture, statement, account description and observation artifact uses safe synthetic/non-identifying material; no live holdings, credentials, balances or account identifiers. Stop processing unsafe material rather than copying it. | BG-001, BG-002, BG-003 |
| CON-003 | No architecture, implementation, restarted discovery or RPI research segment. | Organizational / workflow. | Deliver only business-level requirements and governance; no system topology, technology choice, APIs, tasks, new research execution or research-segment activation. Evidence gaps remain gates. | BG-001, BG-002, BG-003 |

## Acceptance Criteria

All are **Not Started**: these are proposed acceptance conditions, not claimed
prototype results. Use agreed synthetic fixtures only. Conditions requiring
financial rules or provider coverage remain blocked for execution by the named
requirement gates until the applicable support matrix/methodology is approved.
Criterion satisfaction does not, by itself, close a dependency or validation gate.

| ID | Given / When / Then acceptance condition | Covers |
| ---- | ----------------------------------------- | -------- |
| AC-001 | Given a synthetic starting statement, when the investor reviews its proposal, then each proposed holding shows broker/source, evidence date, asset, units, currency and explicit missing/unsupported fields; pre-statement transaction history is not asserted. | BR-001 |
| AC-002 | Given an unconfirmed baseline proposal, when the investor cancels, then no proposed starting position becomes the accepted baseline. | BR-001 |
| AC-003 | Given the agreed three-broker stock/ETF/crypto scenario, when the consolidated view is reviewed, then each holding is attributable to its broker, type and native currency and has a dated AED value or explicit unvalued state; a total excluding any holding is labelled partial with exclusions identifiable. | BR-002 |
| AC-004 | Given recorded dated activity and a position-only baseline with an unsupported earlier interval, when history is inspected, then the interval is identified as unsupported rather than populated with invented transactions, and corrections are distinguished from original facts. | BR-003 |
| AC-005 | Given an import containing ready, possible-duplicate, conflicting and unsupported records, when the accepted set is reviewed, then each record has an explicit included/excluded/unresolved disposition; unresolved records cannot silently enter the accepted set. | BR-004 |
| AC-006 | Given a staged import, when the investor cancels before confirmation, then no staged change is applied. | BR-004 |
| AC-007 | Given occasional manual maintenance or an unavailable import path, when the investor proposes a dated change, then its source/manual status and intended effect can be reviewed and cancelled before explicit confirmation; unconfirmed proposals do not change the accepted record. | BR-005 |
| AC-008 | Given coverage approved under GATE-001/004, when a price/FX update is requested, then available inputs arrive without re-keying each price/rate and retain source/effective-time context; an unavailable input is explicitly unavailable rather than replaced by an invented value. | BR-006 |
| AC-009 | Given a native-currency or converted valuation, when provenance is inspected on demand, then position, price and applicable FX evidence/times, rate direction, reporting currency and calculation basis are distinguishable; unavailable evidence and non-applicable FX are explicitly identified. | BR-007 |
| AC-010 | Given missing or stale inputs under the approved timing policy, when valuation is reviewed, then affected values and any portfolio total are qualified as partial/stale/uncertain as applicable, not presented as a fully current complete valuation. | BR-008 |
| AC-011 | Given a holding with an unresolved quantity mismatch or uncertain history and otherwise fresh prices, when overview status is reviewed, then the exception is visible and price freshness is not an unqualified assertion of position correctness or historical completeness. Exact status vocabulary remains GATE-006. | BR-008 |
| AC-012 | Given conflicting position evidence, when recovery is opened, then both evidence positions and the reason for the conflict are distinguishable from its current versus historical consequences before a cause choice is requested. | BR-009 |
| AC-013 | Given either recovery branch, when its confirmation is considered, then the investor can review what will change, what will not change and what remains uncertain, and cancel without applying the proposed change. | BR-009 |
| AC-014 | Given evidence-backed missing activity under the agreed methodology, when known-cause recovery is confirmed, then that activity is recorded and affected history recalculated; unrelated records are unchanged and other unexplained evidence stays uncertain. A missing cause is not inferred solely from a quantity difference. | BR-010 |
| AC-015 | Given attributable evidence of today's position but no known cause, when unknown-cause verification is confirmed, then today's verification is dated and source-linked, historical transactions are unchanged and no invented transaction explains the difference. | BR-011 |
| AC-016 | Given completed known- or unknown-cause recovery, when the result or later history is inspected, then changed/unchanged information and remaining uncertainty are identifiable; unknown-cause verification does not mark historical gain/loss or cost basis as verified. This does not require adding gain/loss or cost-basis views. | BR-012 |
| AC-017 | Given a suspected mistaken-cause assertion during later review, when its evidence is inspected, then the assertion and affected history remain traceable for a governed correction decision rather than being presented as proven fact; the correction procedure must be agreed under GATE-003 and validated under GATE-002 before claiming this path ready. | BR-012 |

## Traceability Matrix

Relationships use the configured namespaces: functional requirements = BR,
standing rules = RULE. Evidence links are support for decisions, not a declaration
that every detail was requested or validated by participants.

### FR-to-AC Coverage (BR namespace)

| Source ID | Source title | Target IDs | Coverage |
| ----------- | -------------- | ------------ | ---------- |
| BR-001 | Establishment | AC-001, AC-002 | 2 |
| BR-002 | Consolidation | AC-003 | 1 |
| BR-003 | Factual history | AC-004 | 1 |
| BR-004 | Reviewed import | AC-005, AC-006 | 2 |
| BR-005 | Manual fallback | AC-007 | 1 |
| BR-006 | Sourced updates | AC-008 | 1 |
| BR-007 | Provenance | AC-009 | 1 |
| BR-008 | Uncertainty | AC-010, AC-011 | 2 |
| BR-009 | Conflict/preview | AC-012, AC-013 | 2 |
| BR-010 | Known cause | AC-014 | 1 |
| BR-011 | Unknown cause | AC-015 | 1 |
| BR-012 | Consequence continuity | AC-016, AC-017 | 2 |

Coverage: **12 / 12 = 100.0%** against the 80.0% threshold. This measures authored
links only, not passed tests, validated behavior or gate closure.

### FR-to-BG Alignment (BR namespace)

| Source ID | Target goal IDs | Alignment count |
| ----------- | ----------------- | ----------------- |
| BR-001 | BG-001, BG-002 | 2 |
| BR-002 | BG-002 | 1 |
| BR-003 | BG-002, BG-003 | 2 |
| BR-004 | BG-001 | 1 |
| BR-005 | BG-001 | 1 |
| BR-006 | BG-001, BG-002 | 2 |
| BR-007 | BG-002 | 1 |
| BR-008 | BG-002, BG-003 | 2 |
| BR-009 | BG-003 | 1 |
| BR-010 | BG-003 | 1 |
| BR-011 | BG-003 | 1 |
| BR-012 | BG-002, BG-003 | 2 |

Alignment: **12 / 12 = 100.0%**. No coverage waiver needed. Goals remain
unvalidated and SMART-deferred.

### BR-to-FR Enforcement (RULE-to-BR namespaces)

| Rule ID | Enforcing requirement IDs |
| --------- | --------------------------- |
| RULE-001 | BR-001, BR-003, BR-005, BR-006, BR-007, BR-012 |
| RULE-002 | BR-003, BR-008, BR-009, BR-010, BR-011, BR-012 |
| RULE-003 | BR-001, BR-004, BR-005, BR-009, BR-010, BR-011 |

### DT Evidence and Decision Traceability

| Requirement | Evidence / locator | Decision basis and interpretation limit |
| ------------- | -------------------- | ----------------------------------------- |
| BR-001 | P02-E2/E3 directionally; DT-5 original concept / establishment. | DD-003 statement-first local choice; statement sufficiency unproven, not canonical text. |
| BR-002 | P01-E1; P02-E1; DT-1 PO desired outcome; CAN orient. | DD-002/003; three brokers/assets/currencies are scenario choices, not participant attributes. |
| BR-003 | P01-E3; P02-E4; CAN factual story; DT-5 history-coverage questions. | DD-002/004; history semantics require GATE-003/004. |
| BR-004 | P02-E2/E3; DT-3 PO maintenance decision; CAN maintain/import. | DD-003; staging/duplicate boundaries are authored proposals, not proven import correctness. |
| BR-005 | P01-E4 contrasted with P02-E2; DT-3 PO decision. | DD-003; occasional versus repetitive work preserved, not "all entry is bad." |
| BR-006 | P01-E2 trust concern; P02-E3 automation preference. | DD-003; related but different signals; licensed coverage not established. |
| BR-007 | P01-E2; P02-E3; DT-1 PO calculation/as-of outcome; CAN trust. | DD-002; on-demand provenance is baseline; main-screen FX alternative unvalidated. |
| BR-008 | CAN explicit uncertainty; SELF Iteration 1 overview mismatch; DT-6C. | DD-002/004; overview consistency is a proposed boundary from self-test, not a participant finding or claimed fix. |
| BR-009 | I1 recovery failure; DT-6A; R2 conflict/cause/preview. | DD-004; concept repair hypothesis, not cosmetic relabelling or validated comprehension. |
| BR-010 | R2; DT-6B known-cause branch; SELF separately. | DD-004; modelled recalculation not verified mutation; financial methodology gated. |
| BR-011 | R2; DT-6B D2 and unknown-cause branch. | DD-004; current verification cannot prove historical cause; silent overwrite superseded. |
| BR-012 | DT-6B branch uncertainties and future validation; SELF Iteration 2 open questions. | DD-004; mistaken-cause correction and later interpretation unvalidated, GATE-002/003. |

P01-E5 goal tracking is explicitly excluded, not overlooked. P02-E4 composition
remains an individual signal/open scope detail, not generalized demand.
No other divergent idea, parked alternative, or concept-card prompt is promoted
to a requirement merely because it appears in a source.

## Risks and Assumptions

### Key Assumptions

| ID | Assumption | Evidence status / label | Impact if false | Mitigation / source |
| ---- | ------------ | ------------------------- | ----------------- | --------------------- |
| A-001 | Import-first/manual fallback reduces unacceptable upkeep across cadences. | Assumption; partially supported preferences, low confidence; not tested effectiveness. | Workflow may add work or exclude actual practice. | GATE-003/005; P01-E4, P02-E2, DT-3. |
| A-002 | Attributable price/FX and inspectable provenance improve factual understanding. | Assumption; related directional signals, not causally demonstrated. | Automation/provenance may be misunderstood or uneconomic. | GATE-001/004/005/007; P01-E2, P02-E3, CAN. |
| A-003 | Iteration 2 enables sound cause judgment and understood recovery. | Assumption; PO self-test only, no Iteration 2 participant evidence. | Mechanically completed recovery can still create misplaced certainty. | GATE-002/003; R2, SELF, DT-6B. |
| A-004 | Statements/history support the local asset/currency scenario and fractional quantities. | Assumption; feasibility unverified; scenario not participant-validated. | Unsupported positions or misleading historical calculations. | GATE-001/003/004; DT-5 and DT-H. |
| A-005 | Wider users/contexts and sustainable operation justify continuing. | Assumption; no prevalence, adoption/payment or cost evidence. | Planning baseline may not justify investment. | GATE-005/007; DT-H M5/D/F/V. |

The fictional month-end wrong-total story and multi-app growth belief remain
unvalidated and are not necessary premises for approving this bounded document.

### Research Finding Dispositions

No RPI segment or RPI findings exist. Research was explicitly declined; DT source
dispositions are recorded above, not relabelled as RPI evidence or receipts.

### Risk Register

Probability is **unknown** for all risks: limited evidence does not justify
inventing likelihood ratings. Impact below is a planning judgment, not measured
frequency. STK-002 owns each mitigation.

| ID | Risk | Potential impact | Mitigation |
| ---- | ------ | ------------------ | ------------ |
| RISK-001 | Provider coverage, licensing or costs cannot support the scenario. | High: promised valuations may be unavailable or unsustainable. | GATE-001/007; retain explicit unsupported states, revise scope rather than presume rights. |
| RISK-002 | Recovery remains misunderstood, including mistaken-cause assertion. | High: current correctness mistaken for complete history. | GATE-002/003; prediction/explanation validation, no invented history. |
| RISK-003 | Import or methodology mishandles duplicates, fractions, fees or corporate actions. | High: incorrect factual record. | GATE-003/004; expert-reviewed cases and support boundaries before commitment. |
| RISK-004 | Fresh overview status masks stale inputs or unresolved mismatch. | High: misleading certainty. | GATE-004/006; independent freshness/current/history semantics. |
| RISK-005 | Low-confidence summaries or self-tests are promoted into proof of demand or readiness. | High: unjustified product/delivery commitment. | Preserve source labels; GATE-005/007; explicit planning-only approval. |

## Open Questions

All are **Open**, not deferred or resolved. No calendar due dates were supplied;
the concrete decision triggers in the gate register are the current deadlines.
The PO must assign evaluation dates in the exit evidence before claiming
outcome/validation gates closed. No question below requests discovery now.

| ID | Question or gap | Why it matters | Owner | Target / status | Source |
| ---- | ----------------- | ---------------- | ------- | ----------------- | -------- |
| OQ-001 | Which assets/currencies/dates can be priced and converted under licensed access/retention terms and affordable limits? | Conditional automation/coverage. | STK-002 | GATE-001 trigger / Open | DT-H candidate gates; CAN. |
| OQ-002 | Can representative users judge known/unknown/mistaken cause and explain current/history consequences, including later uncertainty? | Recovery comprehension, not click completion. | STK-002 | GATE-002 trigger / Open | I1; R2; DT-6B. |
| OQ-003 | What statement/history/format coverage and financial rules handle fractions, duplicates, fees, corporate actions, corrections and unsupported cases? | Factual correctness, baseline limits and mistaken-cause repair. | STK-002 | GATE-003 trigger / Open | DT-5; DT-H. |
| OQ-004 | What are completed-market cutoffs/timezones, crypto timing, rate direction, rounding, stale thresholds and missing-input/uncertainty propagation? | Valuation meaning; no assumed synchronized timestamps. | STK-002 | GATE-004 trigger / Open | CAN; DT-5/6B. |
| OQ-005 | What effort/comprehension measures, baselines, targets, dates and contextual/accessibility coverage are meaningful; are adjacent roles relevant? | Unknown benefit and unrepresented needs. | STK-002 | GATE-005 trigger / Open | DT-1/3; DT-H. |
| OQ-006 | How should overview status distinguish fresh prices, verified positions and unresolved history? | Self-test trust-consistency concern. | STK-002 | GATE-006 trigger / Open | SELF Iteration 1 only; DT-6A/C. |
| OQ-007 | Are costs, support/correction burden, adoption/payment and operating model sustainable? | No viability/business-case proof. | STK-002 | GATE-007 trigger / Open | DT-5 D/F/V; DT-H. |
| OQ-008 | Is a composition breakdown needed, and does main-screen FX improve understanding versus on-demand provenance? | P02-only signal and retained local alternative, not baseline promises. | STK-002 | Before any scope expansion; GATE-005 / Open | P02-E4; DT-5 comparison. |

### Dependency and Validation Gate Register

Every record completes all fields in [Gate Record](../GATE-RECORD.md).
**Open governed dependencies** do not automatically block approval of a bounded
workshop planning baseline. They **do** block treating their dependent behavior,
coverage, validation or business outcome as ready/established. Untraceable
requirements or unreviewable acceptance boundaries would instead be approval
blockers requiring document repair. A PO planning approval cannot silently
close these gates.

#### GATE-001

- **Gate ID:** GATE-001
- **Title:** Price/FX provider coverage and licensing.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; availability and rights not committed.
- **Affected requirements/features:** BR-002, BR-006, BR-007; NFR-001; attributable AED valuation and sourced updates.
- **Exit evidence:** Dated provider/terms references; coverage matrix for agreed assets, currencies and dates; permitted use/display/retention and redistribution where relevant; access/rate limits, costs and explicit gaps; PO-recorded supported-scope/rights decision with specialist review where needed.
- **Next decision trigger:** Before committing provider-dependent valuation/automation features for engineering planning or claiming their coverage.
- **Remaining uncertainty:** Whether needed price/FX evidence can be obtained, used and retained at acceptable cost/frequency; no provider selected or rights verified.

#### GATE-002

- **Gate ID:** GATE-002
- **Title:** Representative-user validation of Iteration 2 recovery.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; redesign hypothesis, self-test only.
- **Affected requirements/features:** BR-009, BR-010, BR-011, BR-012; NFR-002; conflict/cause/preview and consequence continuity.
- **Exit evidence:** PO-approved protocol, participant/context rationale, consent and safe synthetic tasks; success criteria and evaluation date agreed before testing; source-located observations of conflict comprehension, cause judgment, branch choice, pre-action prediction, post-action explanation, mistaken-cause recovery and later uncertain-history interpretation; failures/limits and PO disposition recorded. Mechanical completion and PO self-test cannot substitute.
- **Next decision trigger:** Before claiming recovery comprehension validated or committing its dependent workflow as validated for engineering planning.
- **Remaining uncertainty:** Whether non-author representative users distinguish present from history, recognize unknown/mistaken cause and retain the correct uncertainty model later.

#### GATE-003

- **Gate ID:** GATE-003
- **Title:** Import/baseline coverage and financial methodology.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; support boundaries and correction rules unverified.
- **Affected requirements/features:** BR-001, BR-002, BR-003, BR-004, BR-005, BR-009, BR-010, BR-011, BR-012; NFR-001, NFR-003; attributable establishment, maintenance and history.
- **Exit evidence:** Reviewed statement/history/format support matrix; synthetic expected-result cases for fractional quantities, duplicate/uncertain imports, fees, corporate actions, baseline-history gaps, unsupported assets/formats, evidence-backed missing activity, unknown cause and mistaken-cause correction; agreed correction/reversal procedure and relevant gain/loss/cost-basis limitations without tax scope; appropriate financial expertise and PO decision recorded.
- **Next decision trigger:** Before accepting import/history/recovery behavior as financially correct or committing dependent features for engineering planning.
- **Remaining uncertainty:** Statement sufficiency, historical availability, asset/format variation, duplicate/corporate-action logic, financial calculation rules and safe correction of mistaken causes.

#### GATE-004

- **Gate ID:** GATE-004
- **Title:** Valuation/FX meaning, timing and uncertainty.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no agreed timing/precision/freshness policy.
- **Affected requirements/features:** BR-002, BR-003, BR-006, BR-007, BR-008, BR-010, BR-012; NFR-001; dated valuation/provenance and uncertain totals/history.
- **Exit evidence:** PO-approved definitions and reviewed synthetic cases covering completed-market price basis, cutoffs/timezones and crypto timing; price versus FX effective time, rate direction, precision/rounding/tolerances, stale/missing-input policy, partial totals and propagation of current/history uncertainty; provenance availability and unresolved exceptions explicitly recorded.
- **Next decision trigger:** Before claiming current/complete/correct AED valuations or committing valuation/history behavior for engineering planning.
- **Remaining uncertainty:** Which timing/FX policies are meaningful and sourceable, and how incomplete inputs and uncertain history constrain factual values.

#### GATE-005

- **Gate ID:** GATE-005
- **Title:** Outcome measurement and broader-context coverage.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; goals SMART-deferred, no prevalence or measured benefit.
- **Affected requirements/features:** BR-001 through BR-012; NFR-002; BG-001, BG-002, BG-003; any proposed composition or main-screen-FX scope addition.
- **Exit evidence:** PO-approved operational measures, safe baseline source/data, meaningful targets, evaluation dates and decision criteria for maintenance effort and factual/recovery understanding; documented user/context/accessibility coverage and adjacent-role disposition; explicit assessment of remaining generalizability limits. No prevalence/market-growth claim without appropriate separate evidence.
- **Next decision trigger:** Before adopting outcome-performance commitments, claiming broader demand/benefit, or approving expanded user/context scope.
- **Remaining uncertainty:** Actual magnitude, baseline effort, achievable improvement, representative contexts, adjacent roles and value of retained alternatives.

#### GATE-006

- **Gate ID:** GATE-006
- **Title:** Overview trust-status consistency.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; self-test concern, no participant finding or verified fix.
- **Affected requirements/features:** BR-008; AC-011; portfolio/holding trust and freshness summaries.
- **Exit evidence:** PO decision separating price freshness, position verification and historical completeness; synthetic mismatch/fresh-price/uncertain-history cases showing overview does not assert unqualified certainty and links affected holdings; source-located comprehension observations and failure dispositions. Preserve the self-test-only origin.
- **Next decision trigger:** Before accepting overview status semantics or claiming the reported inconsistency resolved.
- **Remaining uncertainty:** Appropriate summary vocabulary/aggregation and whether users interpret it correctly while unresolved exceptions remain.

#### GATE-007

- **Gate ID:** GATE-007
- **Title:** Viability, support burden and operating assumptions.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no viable operating model established.
- **Affected requirements/features:** BR-001 through BR-012; BG-001, BG-002, BG-003; continued investment in the proposed baseline.
- **Exit evidence:** Documented provider/import/correction support costs and assumptions; operating/support responsibilities and capacity; non-sensitive adoption/payment evidence appropriate to the intended model; PO-recorded proceed/revise/stop decision with explicit remaining limits.
- **Next decision trigger:** Before treating this baseline as an investable business case, making operational commitments or authorizing engineering expenditure.
- **Remaining uncertainty:** Coverage/licensing economics, ongoing reconciliation/support effort, adoption/payment and who can sustain operation; no budget or service promise inferred.

## Glossary

| Term | Meaning in this BRD |
| ------ | -------------------- |
| AED | Reporting currency chosen for this workshop scenario; not proof of jurisdiction or provider coverage. |
| Factual history | Attributable dated recorded information with explicit coverage/uncertainty, not a forecast or claim of complete transaction history. |
| Current verification | Evidence-linked confirmation of a position at a stated time; not proof of how it arose. |
| Known cause | Missing activity supported by evidence, not merely a plausible explanation for a quantity difference. |
| Unknown cause | Today's position may be evidenced while the historical explanation/completeness remains unknown. |
| Provenance | Distinguishable source, effective time and calculation context; attribution does not itself prove accuracy or licensed rights. |
| Partial total | A qualified valuation excluding identifiable unsupported inputs/holdings, not a complete AED portfolio value. |
| Gate | Owned decision checkpoint with exit evidence, trigger and remaining uncertainty; inherited downstream until explicitly closed. |
| Planning-baseline approval | PO accepts business scope/requirements/governance for workshop planning; not research validation, feasibility sign-off or engineering authorization. |

## Sign-Off

### Approval Checklist

| Review or decision | Authority / current status |
| -------------------- | ---------------------------- |
| Business scope and planning-baseline sign-off | Workshop Product Owner (requesting user; STK-002); **Pending** review of version 0.1.0. Being named authority is not approval. |
| Evidence fidelity and traceability | Authored from DT-H and linked sources; source limits retained. Formal quality review recorded separately in the state. |
| Acceptance boundaries | BR-to-AC 12/12 and BR-to-BG 12/12; no conditions executed or behavior validated by authoring them. |
| Open governed dependencies | GATE-001 through GATE-007 remain Open; approval must explicitly preserve them. |
| Engineering, financial, legal/provider-rights approval | Not granted. Specialist evidence where needed belongs to the gates; no additional workshop signatory invented. |

Approval date: **Not approved; no date recorded.**

The contract-backed quality assessment is **complete**:
[standard findings](../../.copilot-tracking/brd-sessions/portfolio-tracker.standard-findings.yml)
and [quality report](../../.copilot-tracking/brd-sessions/portfolio-tracker.quality-report.yml).
It supersedes the earlier missing-contract attempt. Formal result: **FAIL**,
Define exit **BLOCKED**, Govern **NOT_EVALUATED**, because BG-001 through BG-003
do not pass SMART. No baseline, target, date, evidence or waiver was invented.

For the distinct workshop planning-baseline decision, the reviewer found no
missing requirement basis, unreviewable acceptance boundary, inflated evidence
or incomplete decision/gate record. The dependency-column ambiguity in
`req-qual-031` is reconciled by the explicit baseline-wide inheritance above;
the original review finding remains preserved with its disposition in state.
No workshop approval blocker remains identified. All seven governed dependencies
remain Open, and **your planning-baseline approval is still pending**. Such an
approval would neither close those gates nor authorize formal lifecycle
advancement, engineering, expenditure or an approved downstream handoff.

### Waivers

None requested or granted. No fabricated waiver for SMART gaps, coverage or
validation. Workshop-baseline approval and full lifecycle Govern exit are
different decisions.

### Handoff Readiness

Status: **Not issued**. The requested artifact is the BRD draft for PO review.
No approved `BRD_TO_PRD_HANDOFF_V1` payload is emitted without explicit review
and sign-off, the required quality decision and complete Govern evidence.
No PRD, backlog or implementation work is initiated.

Current identifier counts: 3 BG / 12 BR (functional family) / 17 AC / 3 NFR /
3 CON / 3 RULE (standing-rule family) / 6 DD. Authored BR-to-AC and BR-to-BG
coverage are both 100.0%; neither is execution coverage.
Signoff SHA-256: not yet applicable; no signed artifact exists. The reviewed
draft hash and quality artifact references belong to the lifecycle state so the
document is not given a self-referential content hash.

## Disclaimer

> [!CAUTION]
> **Disclaimer:** This agent is an assistive tool only. It does not provide business approval, regulatory compliance validation, or executive sign-off and does not replace business analysts, stakeholder representatives, compliance teams, or other qualified human reviewers. The output consists of suggested business requirements, objectives, and scope definitions to support a user's own business analysis and decision-making. All Business Requirements Documents, business objectives, stakeholder analysis, and requirement traceability generated by this tool must be independently reviewed and validated by appropriate business and compliance reviewers before adoption. Outputs from this tool do not constitute business approval, requirements sign-off, or stakeholder commitment.

## Document Metadata

- Template Version: 1.0.0.
- Canonical structure: `requirements-author/templates/brd/brd-full.md` and frontmatter overlay; optional process diagrams omitted (`diagram_format: none`).
- Local overlay: [BRD skeleton](../../workshop/05-common/BRD-SKELETON.md), [Gate Record](../GATE-RECORD.md), [Decision Rubric](../DECISION-RUBRIC.md).
- Namespace overlay: functional capabilities use BR; standing business rules use RULE, preserving distinct canonical families.
- Lifecycle state: [portfolio-tracker.state.json](../../.copilot-tracking/brd-sessions/portfolio-tracker.state.json).
- License: CC-BY 4.0 (Microsoft HVE-Core).
- Template attribution: Microsoft HVE-Core Team.
