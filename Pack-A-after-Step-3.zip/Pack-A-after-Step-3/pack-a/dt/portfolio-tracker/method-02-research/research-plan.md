# Method 2: Design Research - approach and protocol

Status: planning only, following the Product Owner's instruction to proceed.
Method 1's full validation-oriented exit remains unmet. No research has been
conducted, supplied, or validated. All scenario pain points remain assumptions.
Decision (not evidence), Product Owner, 2026-11-17: use a proportionate protocol
within a 10-minute planning timebox; research will be supplied, not run by us.
The Product Owner authorized a reasonable protocol without a further approval
round. This authorizes the approach, not any finding or research completion.

## Objectives, in order

1. Discover how real self-directed investors review holdings across platforms:
   triggers, environment, tools, sequence, frequency and meaningful outcomes.
2. Test whether record trust, price/FX staleness and repeated entry are actual
   obstacles; seek episodes where current tools work well and contrary evidence.
3. Understand how investors establish value, provenance and timing. Explore the
   meaning of closing/completed-market valuations, including crypto and different
   market calendars, without prescribing definitions or features.
4. Investigate access/licensing constraints separately with relevant sources if
   available. Do not use provider opinions as evidence of investor pain.

## Targets and access

| Priority | Target | Access strategy and outstanding gap |
|---|---|---|
| Tier 1 | Real self-directed multi-platform investors, including people with effective existing workarounds | Product Owner will supply Method 2 research. Check distinct participant/source provenance; recruitment, consent and dates are not yet supplied. Do not require every participant to match the fictional portfolio. |
| Tier 2 | Accountant, partner or other adjacent person only if investor accounts establish involvement | Discover relevance first; access and participation are not assumed. |
| Tier 3 | Broker data-access contacts and price/FX licensing specialists or authoritative documentation | Request sourceable constraint information through approved access. No contacts or rights confirmed. |

## Methods and sequence

Environmental observation -> workflow interviews -> constraint validation ->
unmet-need exploration. For supplied material, identify which of these it actually
covers and retain explicit gaps rather than fabricating missing observations.

Use consented, non-identifying descriptions and synthetic walkthroughs only:
no live accounts, balances, statements, account identifiers, screenshots containing
personal financial information, or broker credentials. Synthetic task behavior
is not evidence of real financial outcomes or actual holdings.

Start with "Walk me through the last time you reviewed holdings across platforms."
Follow actual actions and what happened, not "Would a tracker help?"
Explore how totals and mistakes are checked, how new purchases are reflected,
what "as of" means in that task, and who else is involved. Do not assume a
spreadsheet, month-end cadence, lost trust, or hand-typed FX rates.

## Evidence handling and measurement proposals

For each supplied source retain a stable source/participant alias, date if known,
context, exact non-sensitive quote or observation, and original location.
Keep Evidence / Decision (not evidence) / Assumption / Open question separate.
Mark simulated, fictional, paraphrased, or unattributed material explicitly.
Do not treat workshop broker apps as real-investor research.

Proposed research measures, not success commitments: task steps and elapsed effort
where safely observable, entry/reconciliation frequency, discrepancy detection and
resolution, ability to explain sources and timestamps, and reported confidence
with reasons. Definitions, baseline, meaningful improvement and target agreement
remain open; do not invent numerical targets or imply greater investment returns.

Compare multiple independent sources, keep contradictions and negative cases,
and avoid prevalence claims from a small convenience sample. The claim that
multi-app investing is growing requires separate dated market evidence if retained;
it is not needed to assume an individual problem worth investigating.

## Timeline and stop conditions

The 25-minute limit applies to Method 1 only. The new 10-minute timebox applies
to preparing this approach, not participant recruitment or fieldwork. Planning
allocation: 2 minutes for targets/privacy, 4 for observation and questions,
3 for recording/confidence rules, and 1 for the intake checklist.
This is an allocation, not a claim of elapsed time. No fieldwork is scheduled.
Next checkpoint: receive the Product Owner's research and check provenance,
privacy and coverage before interpreting it. Then identify follow-up gaps and
agree any additional collection schedule; no participant appointments are claimed.

Do not advance to Method 3 until source-grounded interview/observation material,
environmental context, constraint documentation and assumption results are
sufficient for multi-source synthesis. Missing evidence remains missing, not a
confirmed need. Revisit Method 1 scope if the evidence challenges the framing.

## Contextual-inquiry / interview protocol

This is a guide for supplied-research coverage, not a claim that we interviewed
anyone. Existing research need not follow this script; record differences and
missing coverage without retrofitting answers. Do not fetch or interpret evidence
as part of this planning task.

### Who and how

Prioritize several independent Tier 1 investor accounts, varying platforms,
currencies, review cadence and experience, including people content with their
current approach. AED reporting is a scenario choice, not a recruitment fact.
Use Tier 2 only when involvement emerges; use Tier 3 for access/licensing facts.
The Product Owner supplies permitted material; actual sample, contacts, dates and
coverage remain unknown. No sample count alone establishes representativeness.

### What to observe, in sequence

| Stage | Capture without interpretation |
|---|---|
| Environment | Device/tool types, setting, interruptions and time pressures; distinguish observed context from a participant's description. |
| Workflow | Trigger, tool switching, action order, copying/re-entry, checks, workarounds and stopping point. Record smooth paths as well as difficulties. |
| Constraints | Where information comes from, its timestamp/currency, how discrepancies are handled and any access limits. Record licensing claims separately for authoritative verification. |
| Unmet need | What the person was trying to accomplish, actual consequences and what a satisfactory result meant to them, without proposing a tracker. |

For any walkthrough described in the material, distinguish naturally observed
behavior, retrospective self-report and synthetic reenactment. Never label a
reconstruction as direct observation. A missing observation is "not supplied,"
not "did not happen."

### Key questions

Use the first question as an anchor; follow the participant's sequence rather
than treating these as a mandatory questionnaire.

1. "Think of the last time you reviewed investments across platforms. What
   prompted it, and what were you trying to establish?"
2. "Where were you, which tools did you use, and what did you do first and next?"
   A demonstration, if applicable, must use synthetic examples only.
3. "How did you decide which holdings, prices and exchange rates to use, and
   which point in time they represented?" Probe closing prices or crypto timing
   only if relevant; do not assume month-end or AED.
4. "How did you check the result? Tell me about a time it was straightforward
   and, if there was one, a time something did not match. What happened next?"
5. "What happens when holdings change? Which steps, if any, do you repeat,
   how often, and with what effort or consequence?"
6. "Who else, if anyone, was involved? What would have made that occasion
   satisfactory, and what already worked well?"

For provider/context sources, ask separately what data use/access is permitted,
under which dated terms, with what coverage, timing and restrictions. Seek a
document reference; do not infer legal approval or investor need from the answer.
Avoid feature voting, advice, hypothetical purchase intent and leading prompts
such as "Did stale FX make you lose trust?"

### Recording provenance

Keep original supplied files unchanged. Use stable aliases and one row per
non-sensitive excerpt/observation in later research notes:

| Field | Recording rule |
|---|---|
| Record/source IDs | Unique record ID plus stable source and participant alias; link repeated excerpts to the same underlying participant so they are not counted as independent. |
| Locator | Supplied path plus page, line, section or timestamp; retain original wording for a direct quote. |
| Origin/context | Creator/collector and date if supplied, date received, method, setting and relevant non-identifying participant context. Use "not supplied" for unknown metadata. |
| Material status | Real-research account, fictional/workshop fixture, synthetic reenactment, or unknown; include permission/consent status as supplied, never presumed. |
| Content kind | Direct observation, verbatim quote, self-report, paraphrase or secondary claim; no quotation marks around paraphrases. |
| Epistemic label | Evidence / Decision (not evidence) / Assumption / Open question, preserving the supplier's label and noting any provenance limitation separately. A supplier's "Evidence" label does not establish authenticity. |
| Limitations | Missing context, source dependence, simulation, contradictions or unverified rights. Keep researcher reflections in a separate field, not inside raw content. |

Do not request or retain real personal financial data or identifying financial
details. If supplied material contains it, stop processing that material and
request a safe synthetic/non-sensitive replacement; do not copy it into notes.
Missing permission/provenance is an intake gap, not permission to assume consent.

### Confidence rules - defined now, applied later

No evidence or hypothesis confidence is assigned in this planning task.
At intake, record provenance completeness and limitations separately from
confidence in any later claim. Quotation accuracy is not proof that a claim is
true; a participant's expressed confidence is not researcher confidence.

| Later claim confidence | Basis and required qualification |
|---|---|
| High | Multiple independent, relevant sources corroborate a bounded claim, with clear provenance and material contradictions addressed. Not a population estimate or proof of a requirement. |
| Medium | Clear, relevant evidence supports a narrow claim, but source diversity or contextual coverage is limited. |
| Low | Weak, indirect, ambiguous or incomplete support; further validation needed. |
| Not assessed / no evidence | No relevant material yet, or assessment intentionally deferred. Decisions and fictional assumptions are not promoted to evidence by assigning confidence. |

Every later assessment must cite record IDs, state the claim's scope and
limitations, and retain contrary evidence. Repeated excerpts from one source do
not raise confidence. Fictional fixtures can support workshop exercises only,
not claims about real investors.

### Supplied-material intake checkpoint

When material arrives, first register sources, permission/privacy status,
real-versus-simulated status and available locators; flag missing information.
Do not force retrospective coverage of this protocol or invent quotes,
observations, participants or dates. This task ends with the protocol ready:
no themes, assumption verdicts, findings or Method 3 transition.
