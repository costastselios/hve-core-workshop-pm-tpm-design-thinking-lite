# Method 2: supplied research record

## Status and provenance

Decision (not evidence): on 2026-11-17 the Product Owner instructed the coach to
use these two records as completed Method 2 research for this workshop, with
low-confidence directional evidence. This supersedes the earlier requirement to
wait for fuller supplied material for workshop progression, not the evidence
limitations or real-world validation needs.

The coach read both original files in full. Originals are unchanged. These are
participant summaries, not transcripts, direct observations or verbatim quotes.
All evidence below is paraphrased from the narrative paragraph (line 4) of each
source. Metadata is at line 2. Confidence remains Low throughout.

| Source ID | Original path | Coverage and limitations |
|---|---|---|
| P01 | `workshop/02-research-evidence/participant-01-research-summary.md` | Participant 01 supplied summary; one participant, no raw transcript/verbatim quotes. |
| P02 | `workshop/02-research-evidence/participant-02-research-summary.md` | Participant 02 supplied summary; one participant, no raw transcript/verbatim quotes. |

Received/read: 2026-11-17. Collector, interview dates, recruitment, consent details,
setting, observation method and independence of collection are not supplied.
The files identify different participants; independent collection is not verified.
Workshop acceptance does not authenticate real-world research provenance.
No actual financial values, accounts or credentials are recorded here.

## Evidence register - separate participant records

| Record ID | Source/locator | Evidence: supplied-summary paraphrase |
|---|---|---|
| P01-E1 | P01, line 4 | Uses multiple brokers and manually consolidates. |
| P01-E2 | P01, line 4 | Manually maintained closing values/FX reduce trust. |
| P01-E3 | P01, line 4 | Wants factual portfolio history; prefers facts over forecasts. |
| P01-E4 | P01, line 4 | Occasional manual entry is acceptable. |
| P01-E5 | P01, line 4 | Goal tracking matters to this participant only. |
| P02-E1 | P02, line 4 | Uses multiple brokers/markets and makes regular fractional purchases. |
| P02-E2 | P02, line 4 | Repetitive manual re-entry is unacceptable; file import is acceptable. |
| P02-E3 | P02, line 4 | Wants review before commitment and automatic prices/FX. |
| P02-E4 | P02, line 4 | Wants composition and factual history; prefers facts over forecasts. |

These are reported behaviors/preferences, not proven usability outcomes or
validated product requirements. Do not infer prevalence or statistical
representativeness from two participants.

## Constraint and coverage record

Reported workflow contexts: multiple brokers for both; manual consolidation for
P01; multiple markets and regular fractional purchases for P02. Actual physical
environment, device behavior, time/effort measurements, error rates, access,
licensing and operational constraints are not supplied.

Product Owner exclusions remain fixed workshop boundaries, not research findings:
no trading, advice, forecasts, tax reporting or real personal financial data.
Research has not established numeric accuracy/freshness thresholds or success
targets. Do not invent observation logs, transcripts or provider confirmation.

## Method 2 exit

Completed as the Product Owner's bounded workshop decision. The full protocol's
raw-observation, provenance and environmental coverage are incomplete; these
gaps carry into synthesis, rather than being represented as satisfied.
Proceed to Method 3 to compare the supplied evidence; no increase in confidence
is warranted solely because both records mention a topic.
