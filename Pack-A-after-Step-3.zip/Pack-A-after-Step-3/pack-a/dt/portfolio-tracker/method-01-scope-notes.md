# Method 1: Scope Conversations - scope and exit check

Status: workshop scoping recorded; provisional handoff to Method 2 planning
authorized by the Product Owner. No interviews, observed behavior, validated
problem statement, requirements, or agreed quantitative success measures yet.

## Starting point

Source: `workshop/00-start/ambiguous-product-idea.md`

> I want to build a wealth portfolio tracker for a self-directed investor with investments spread across multiple platforms. The idea includes consolidated holdings, factual history, completed-market valuations, multiple asset types/currencies, and ways to establish and maintain holdings.

Initial coach routing assessment: start with Method 1, sub-method 1a (Scope Planning).
Treat this as a frozen, solution-led request for exploration: a tracker and
capabilities are named before the underlying problem is established. "Frozen"
describes the request's framing, not a commitment to build it. The user explicitly
keeps the idea open as hypotheses.

## Evidence

No direct investor evidence has been supplied. The idea file records a proposal,
not proof that investors experience a particular problem. No quotes, observations,
frequency, impact, current workarounds, or measurements are available.

## Decision (not evidence)

The Product Owner chose the project identifier `portfolio-tracker`, requested HVE
Core Design Thinking, and specified the four evidence labels used here.
This exploration must not advance into BRD, PRD, backlog, or implementation.
These are workshop boundaries, not evidence of investor needs.

## Assumption

The fictional audience is now a Product Owner decision, not an observed segment;
actual investor workflows and unmet needs remain unverified.

Each proposed capability remains a separate hypothesis, not a scope commitment:
consolidated holdings, factual history, completed-market valuations, support for
multiple asset types/currencies, and establishing or maintaining holdings.
Neither the meaning nor necessity of these capabilities has been established.

Coach-generated problem hypothesis, not a stakeholder finding: an investor may
struggle to answer an important portfolio question using their existing sources.
The question, obstacle, consequence, and value of addressing it remain unknown.

## Initial stakeholder map

| Stakeholder | Status and relationship |
|---|---|
| Workshop Product Owner | Confirmed decision-maker for this workshop; explicitly not the fictional investor. Decisions are not investor evidence. |
| Self-directed investor | Fictional primary user without an adviser; three brokers, stocks, ETFs, some crypto, USD/EUR/AED and AED reporting are scenario decisions. No real participant identified or contacted. |
| Brokers | Product Owner identifies Broker 1, 2 and 3 from Step 0 as data sources. Actual access, rights and constraints are unverified. |
| Price/FX data providers | Product Owner identifies licensing as a dependency to investigate, not an established license or constraint. |
| Accountant or partner | Relevance is an open question, not an assumed user role or confirmed need. |
| Data-access/privacy specialists | Conditional system-context contacts; no jurisdiction or regulatory applicability assumed from AED reporting. |

## Scope boundaries

Fixed for this workshop: remain in problem discovery, preserve evidence labels,
and do not treat AI-generated content or Product Owner decisions as user evidence.
Trading, investment advice, forecasts, tax reporting, and any real personal
financial data are excluded by Product Owner decision. Method 1 has a 25-minute
facilitator timebox; this is not a research duration or a product constraint.

Fixed scenario choices for this exercise, not validated market constraints:
the fictional investor and three brokers, asset/currency mix, and AED reporting.
Fluid discovery hypotheses: problem severity, workflows, product shape,
capabilities, and terminology. Licensing and access remain unverified.

## Open question

First discovery focus: actual investors' recent portfolio-review episodes.
The month-end story below is fictional and cannot answer this evidence question.
Capture triggers, actions, consequences, and counterexamples without assuming friction.

Subsequent gaps, not a questionnaire to complete all at once: who experiences the
problem directly, current workarounds, frequency and consequences, why now,
what "completed-market" means to the requester, and what a better outcome would
look like independently of a tracker. Record supplied evidence with its source
and context; keep interpretations and decisions separately labeled.

## Product Owner input - 2026-11-17

Source: the Product Owner's labelled live-conversation answers. Labels below
preserve their epistemic status; none is promoted to Evidence.

| Label | Recorded input |
|---|---|
| Decision (not evidence) | Investor is not the Product Owner: a fictional self-directed investor with no adviser and holdings at three brokers, the Broker 1, 2 and 3 apps from Step 0. Holdings include stocks, ETFs and some crypto priced in USD, EUR and AED, with totals in AED. |
| Assumption | At month-end they open three apps and manually update a spreadsheet; a stale hand-typed FX rate once made the total wrong and they stopped trusting it. This is a hypothetical episode, not a reported real incident. |
| Assumption | They use separate broker apps plus a spreadsheet with hand-typed closing prices and FX rates; re-entering every purchase is tedious. |
| Assumption | More people now invest across several apps; this belief has not been checked. |
| Decision (not evidence) | Brokers are data sources and price/FX providers raise licensing considerations in the scenario. |
| Open question | Whether an accountant or partner is affected or relevant. |
| Decision (not evidence) | Desired outcome: a factual, trustworthy consolidated record of what is held, where, its value, how that value was worked out, and as of when. |
| Decision (not evidence) | Exclude trading, investment advice, forecasts, tax reporting, and all real personal financial data. |
| Facilitator timebox | 25 minutes for Method 1. No claim that this time has elapsed. |
| Decision (not evidence) | Product Owner agrees real-investor research is needed, will supply research in Method 2, and authorizes planning and proceeding. This is not a claim that research already exists or was conducted. |

## Reframed problem hypothesis

Assumption, coach formulation from the supplied scenario: during month-end review,
a self-directed multi-broker investor may struggle to establish and explain a
trustworthy AED view of their holdings because manually maintained holdings,
closing prices and FX rates may be stale or inconsistent; repetitive entry may
add effort. Whether this happens, matters, or requires a new product is unknown.

This shifts from "build a tracker with capabilities" to understanding record
trustworthiness and maintenance effort. It is not a validated problem statement.

## Method 1 exit check

Workshop Step 1 asks that "User, problem hypothesis, desired outcome, boundaries
and unknowns are explicit." These are now present. HVE's broader sequencing exit
signal is "Problem differs from original request; stakeholders identified"; its
key output includes a validated problem statement. The transition guidance also
calls for interview contacts/priorities and success criteria/measurement approaches.

| Check | Assessment |
|---|---|
| User and decision-maker explicit | Met for workshop: fictional investor is distinct from Product Owner. |
| Problem reframed from solution request | Met as a hypothesis only; not validated. |
| Desired outcome and boundaries explicit | Met as decisions, with fixed workshop/scenario choices distinguished from fluid hypotheses. |
| Stakeholder map and unknowns explicit | Met provisionally at role level; adjacent roles and actual contacts remain open. |
| Investor and multi-stakeholder validation | Not met; no real-investor evidence supplied. |
| Interview targets, access and priorities | Roles prioritized in the research plan; participants, access and scheduling missing. |
| Success criteria and measurement | Qualitative outcome supplied; operational definitions, baseline, targets and agreement on measurement missing. Research probes proposed, not adopted targets. |
| Environment and dependency constraints | Hypothetical apps/spreadsheet workflow captured; actual setting, access, licensing and constraints unverified. |

Disposition: workshop scoping is sufficient to prepare research; the full HVE
validation-oriented exit is not satisfied. Proceed to Method 2 planning on the
Product Owner's explicit instruction, with these gaps visible. Do not list Method 1
as fully completed or infer validation from the transition. Revisit scope if
research contradicts it. Remaining in Method 1 could refine definitions but
cannot manufacture missing investor evidence; moving to synthesis or solutions
would be premature. Collaborative-board export is deferred; no board writes occur.
