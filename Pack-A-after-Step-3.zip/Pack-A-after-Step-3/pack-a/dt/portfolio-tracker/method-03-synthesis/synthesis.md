# Method 3: Input Synthesis - workshop completion

Status: complete for this workshop only, under the Product Owner's bounded
acceptance criteria on 2026-11-17. Evidence remains low-confidence directional. Evidence
IDs refer to `../method-02-research/findings-summary.md`, which locates the
original supplied records. No prevalence, causal proof, validated requirements
or real-world research completion is claimed.

## Input inventory and approach

Inputs: P01 and P02 supplied summaries, kept separate in the Method 2 evidence
register; Method 1 scope notes supply separately labelled decisions/assumptions.
The research plan is methodology, not additional participant evidence.
Compare record by record, cluster only shared material, retain single-participant
signals and tensions, then frame provisional problems and HMW questions.
No transcripts, direct observations, environmental logs, provider evidence or
quantitative measures are available. Missing mentions are not negative responses.

## Affinity clusters and insight statements

| Cluster | Both participants | Interpretation and limit |
|---|---|---|
| Cross-broker context | P01-E1, P02-E1: both use multiple brokers. | Cross-broker understanding is a relevant exploration context for these two records. Manual consolidation is stated only for P01; no universal workflow inferred. |
| Factual understanding over prediction | P01-E3, P02-E4: both want factual history and prefer facts over forecasts. | Explore understanding holdings through factual records rather than predictive guidance. This does not establish a common definition of history or demand across a market. |

Both clusters are Low confidence. Two summarized accounts provide a directional
connection, not a robust generalizable theme.

## Single-participant signals

| Participant | Signal | Interpretation boundary |
|---|---|---|
| P01 | Manual close/FX maintenance reduces trust (P01-E2). | Trust concern is explicit here; do not claim P02 reported lost trust or an actual FX error. |
| P01 | Occasional manual entry is acceptable (P01-E4). | Some manual work may be tolerable in this context; frequency/effort threshold unknown. |
| P01 | Goal tracking matters (P01-E5). | Individual signal only; not shared scope or a reason to add goals to the product. |
| P02 | Regular fractional purchases across brokers/markets (P02-E1). | Context for investigating maintenance effort; impact magnitude is not measured. |
| P02 | Repeated re-entry unacceptable; import acceptable (P02-E2). | Explore repetitive-work burden. Import is a stated solution preference, not the only acceptable or proven approach. |
| P02 | Review before commitment; automatic prices/FX (P02-E3). | Explore control and information-maintenance needs. What is committed/reviewed is unspecified; do not interpret this as trading. |
| P02 | Composition matters (P02-E4). | Individual preference; desired breakdown and task remain unknown. |

## Tensions and different behaviors

P01 accepts occasional manual entry; P02 rejects repetitive manual re-entry.
Keep both findings. They concern different cadence/burden, so they are not proof
of a logical contradiction and cannot be resolved as "all manual entry is bad"
or "manual entry is sufficient." Actual tolerance and context need clarification.

P01 reports trust effects of manual price/FX maintenance; P02 requests automatic
prices/FX. These are related inquiry directions, not two reports of the same
trust failure. No direct contradictory factual accounts are supplied. Goal
tracking and composition are separate single-person signals; absence from the
other summary does not establish opposition.

## Assumptions and decisions kept separate

| Prior item | Current status |
|---|---|
| Month-end three-app spreadsheet episode, stale hand-typed FX causing a wrong total and lost trust | Still Assumption. P01 supports the broader manual-maintenance/trust concern but does not confirm that fictional event, cadence, spreadsheet or specific error. |
| Re-entering every purchase is tedious | Directionally supported for repetitive work by P02-E2, with P01-E4 limiting any universal interpretation. Frequency, burden and causal explanation remain unverified. |
| More people now invest across several apps | Unanswered Assumption; these two records establish neither growth nor prevalence. |
| Exactly three brokers; stocks/ETFs/crypto; USD/EUR/AED; AED totals; no adviser | Product Owner scenario Decisions (not evidence), not established participant characteristics. |
| Explain how value was worked out and as of when | Product Owner outcome Decision (not evidence); participant support for that precise need is not established by these summaries. |
| Trading/advice/forecasts/tax/personal-data exclusions | Workshop Decisions (not evidence). Facts-over-forecasts preference aligns with the forecasts exclusion but does not validate all boundaries. |
| Import, automated pricing and pre-commit review | P02 preferences, not validated requirements. Import-first with manual fallback is now a separate Product Owner decision; see below. |

## Product Owner synthesis decisions (not evidence)

Source: live conversation, 2026-11-17.

1. Prioritize sustainable maintenance versus trust. Preserve both behaviors
   through an import-first direction with manual entry as fallback, not import-only.
   Neither participant established this combined workflow; it is a workshop
   direction, not a validated solution or an implementation commitment.
2. Keep goal tracking as P01-specific and outside the opportunity frame.
3. Focus also on trustworthy valuation/currency conversion with visible provenance,
   grounded directionally in P01-E2 and P02-E3. Visible provenance is a Product
   Owner choice, not a request explicitly shared by both participants.
4. Leave success measures/baselines open. Accept stakeholder coverage beyond two
   participants as a known workshop limitation, not a completion blocker.

## Provisional problem definition

Coach interpretation, Low confidence: the two supplied accounts point toward
understanding holdings across brokers through factual history rather than
forecasts. Within that shared direction, P01 reports reduced trust from manual
closing-value/FX maintenance, while P02 rejects repetitive entry in a context
of regular fractional purchases. The design challenge is to explore reliable
factual understanding without assuming one maintenance workflow fits both.

This differs from the original capability list, but neither a common root cause
nor the magnitude of the problem is established. The fictional portfolio remains
a workshop scenario, not a composite of verified participant attributes.

## Focused opportunity frame

How might we make maintaining a factual cross-broker portfolio record sustainable
across different purchase cadences while making valuations and currency conversion
understandable and trustworthy?

Evidence basis: shared factual-history orientation (P01-E3, P02-E4), different
entry tolerances (P01-E4, P02-E1/E2), and related but distinct valuation signals
(P01-E2, P02-E3). Confidence stays Low.

Product Owner guardrails, not inferred common needs: explore import-first with
manual fallback, and visible provenance explaining valuation/FX source, basis
and timing. This is not import-only. No goal tracking in this frame; composition
remains P02-specific, not promoted into shared scope. AED reporting remains a
scenario decision. Existing exclusions and the no-real-personal-data boundary
remain in effect. No concepts, architecture, backlog or implementation are created.

## Unanswered questions

What does factual history include for each person: transactions, valuations,
corrections or something else? How do they check sources, price/FX dates and
discrepancies? What effort and error consequences occur, at what cadence?
Where is the boundary between tolerable occasional entry and repetitive burden?
What does P02 mean by review before commitment and composition? What job does
goal tracking serve for P01? Are any adjacent people involved?

Actual environment, accessibility needs, source independence, recruitment,
collection/consent provenance, data rights, access, licensing, crypto valuation
timing and measurable success thresholds remain unknown. AED reporting and the
precise fictional asset mix have not been tested with these participants.

## Five-dimension exit check

| Dimension | Assessment |
|---|---|
| Research fidelity | Met at supplied-summary level: source-located paraphrases, separate decisions/assumptions, no invented quotes. Raw-data verification missing. |
| Stakeholder completeness | Two perspectives represented without erasing differences. Wider coverage missing; explicitly accepted as nonblocking for this workshop. |
| Pattern robustness | Shared signals trace to both records; individual signals and tensions retained. Low confidence; independent collection and generalizability not established. |
| Actionability | Focused problem/HMW frame plus explicit Product Owner guardrails. Success measures/baselines remain open by decision, not silently satisfied. |
| Team alignment | Product Owner supplied the synthesis priorities, treatment of differences and accepted workshop limitations; completion is assessed against those instructions. This does not claim participant endorsement or approval of unseen wording. |

HVE's Problem-to-Solution readiness requires "Synthesis validation shows strength
across all five dimensions with remaining gaps explicitly acknowledged."
The full validation-strength gate remains unmet; a workshop completion label
does not convert this into validated research or readiness for delivery.
The bounded workshop exit is satisfied: source inventory, shared and individual
signals, tensions, assumptions, questions, focused problem/HMW frame and explicit
Product Owner priorities are recorded. Mark Method 3 complete for this workshop
only. This supersedes the prior pending-review status.

Still missing: raw transcripts/observations and collection provenance; wider
stakeholder/context coverage; validated entry-tolerance and valuation definitions;
data-access/licensing facts; success measures and baselines. These remain visible
limitations/open questions, not newly invented blockers or completed checks.

Stop here as explicitly requested: current method stays 3 in Problem Space;
Method 4 has not started. No RPI, BRD/PRD, backlog or implementation handoff.
Canonical asset mapping is possible from this problem/opportunity frame, but
optional deck/board offers and generation are deferred to honor the requested
stop. No snapshot, customer-card output or board write occurred; no decline is
inferred from the user's stop instruction.
