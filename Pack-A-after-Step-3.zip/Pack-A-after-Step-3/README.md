# Pack A: shared starting point for the brainstorm (load it after the research walkthrough)

**Everyone loads this pack.** You did Step 1 yourselves. This pack gives every pair the same Design Thinking state after Steps 2–3 (research and synthesis), so all pairs brainstorm from the same evidence in the **next step**. Made by the real **DT Coach** agent (HVE Core v3.2.2), answering from the persona and decision card.

**Get the pack:** download `Pack-A-after-Step-3.zip` from https://github.com/costastselios/hve-core-workshop-pm-tpm-design-thinking-lite/raw/main/Pack-A-after-Step-3.zip (also posted in the workshop Teams channel) and unzip it (**Mac:** double-click; **Windows:** right-click → **Extract All…** → **Extract**). Nothing is hidden: you'll see this `README.md`, the screenshot and **one folder to drag**.

**Golden rule:** if VS Code ever asks **"Replace?"**, click **Cancel**.

![Drag pack-a onto the empty space at the bottom of the VS Code file panel](pack-a-drag.png)

## Load and resume

**Drag (one sentence):** Drag the **`pack-a`** folder from the unzipped pack onto the **empty space at the bottom of the VS Code file panel**, so it lands at the top level next to `docs` and `workshop`.

**Screenshot:** `pack-a-drag.png`

**Check:** the VS Code file panel now shows a top-level folder **`pack-a`**. Open it to see `pack-a › dt › portfolio-tracker › coaching-state.md`. Your own Step 1 files in `.copilot-tracking` are untouched.

**Resume (new chat):**
1. Open a **new** Copilot Chat and pick **DT Coach**. Don't continue your Step 1 chat.
2. Attach `pack-a/dt/portfolio-tracker/coaching-state.md` with **Add Context** or by dragging the file into the chat.
3. Paste:

```text
Resume the Design Thinking project saved in pack-a/dt/portfolio-tracker/ and keep saving its files there. Read coaching-state.md and the Method 1–3 artifacts it lists. Summarize only the state you can access, in at most 8 short bullets: methods completed, the evidence and its confidence (P01 and P02 kept separate), the opportunity frame, my Product Owner decisions, and the open questions. Do not reconstruct missing evidence and make no prevalence claims. Then stop and wait: I will start Method 4 (Workshop Step 4 — Brainstorming) in my next message.
```

**You should see:** about 8 bullets (Methods 2–3 complete for the workshop, P01/P02 kept separate at low confidence, the opportunity frame, Product Owner decisions, open questions), ending with Method 4 *not started* and *waiting*. Then, in the **same chat**, paste the Step 4 brainstorm prompt.

**Fallback, if dragging doesn't work:** open **VS Code → Terminal → New Terminal** (it opens at your repo root) and paste one line.
- **Mac:**
  ```bash
  cp -R ~/Downloads/Pack-A-after-Step-3/pack-a .
  ```
- **Windows (PowerShell; if the prompt doesn't start with `PS`, type `powershell` first):**
  ```powershell
  $pack='Pack-A-after-Step-3'; $s=(Get-ChildItem "$HOME\Downloads" -Directory -Recurse -Depth 3 -Filter pack-a -ErrorAction SilentlyContinue | Where-Object FullName -like "*$pack*" | Select-Object -First 1).FullName; if (-not (Test-Path workshop)) { 'STOP: run this in the VS Code terminal of your workshop repo (the folder with docs, workshop, workshop-output)' } elseif (-not $s) { "STOP: unzip $pack into your Downloads folder first" } else { robocopy "$s" pack-a /E /NFL /NDL /NJH /NJS /NP; if ($LASTEXITCODE -lt 8) { "OK - copied from $s" } else { "ERROR: robocopy exit code $LASTEXITCODE" } }
  ```
  Expected output: one line starting `OK - copied from`.


## What the pack already decided (so you don't have to)

| | |
|---|---|
| **Shared by P01 and P02** | multiple brokers; want factual history; facts over forecasts |
| **P01 only** | manual close/FX reduces trust; occasional manual entry OK; goal tracking matters |
| **P02 only** | repeated re-entry unacceptable; file import OK; wants review before commitment, automatic prices/FX, composition |
| **Product Owner decisions** | import-first with manual fallback, not import-only; goal tracking stays out of the frame; trustworthy valuation/FX with visible provenance |
| **Opportunity frame** | *How might we make maintaining a factual cross-broker portfolio record sustainable across different purchase cadences while making valuations and currency conversion understandable and trustworthy?* |

All evidence is two low-confidence summaries. Nothing here says "users want…".

## Files in the pack

```text
pack-a/dt/portfolio-tracker/coaching-state.md                       DT Coach state: attach this to resume
pack-a/dt/portfolio-tracker/method-01-scope-notes.md                Method 1: user, problem, outcome, boundaries
pack-a/dt/portfolio-tracker/method-02-research/research-plan.md     Method 2: interview protocol
pack-a/dt/portfolio-tracker/method-02-research/findings-summary.md  Method 2: P01 and P02 evidence, kept separate
pack-a/dt/portfolio-tracker/method-03-synthesis/synthesis.md        Method 3: synthesis and opportunity frame
```

Your own Step 1 files stay in `.copilot-tracking/dt/<your-folder>/`. The pack doesn't touch them, and DT Coach keeps saving the brainstorm under `pack-a/`.
