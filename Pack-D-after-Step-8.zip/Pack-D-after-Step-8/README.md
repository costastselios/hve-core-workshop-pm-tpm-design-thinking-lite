# Pack D: approved BRD and PRD for the guided read and Step 9 (load at 14:40)

**Everyone loads this pack.** It holds an approved BRD and PRD produced by the real **BRD Builder** and **PRD Builder** agents (HVE Core plugin v3.2.2), starting from the same evidence as Pack A.
- **14:40:** guided read of the BRD and PRD, using the "Where to look" table below.
- **15:05:** Step 9 hands-on in a **new PRD Builder chat**.

**Get the pack:** download `Pack-D-after-Step-8.zip` from https://github.com/costastselios/hve-core-workshop-reference/raw/main/Pack-D-after-Step-8.zip (also posted in the workshop Teams channel) and unzip it (**Mac:** double-click; **Windows:** right-click → **Extract All…** → **Extract**). Nothing is hidden: you'll see this `README.md`, the screenshot and **one folder to drag**.

**Golden rule:** if VS Code ever asks **"Replace?"**, click **Cancel**.

![Drag project-planning onto the docs folder](pack-d-drag.png)

## At 14:40: load the pack

**Drag (one sentence):** Drag the **`project-planning`** folder from the unzipped pack **onto the `docs` folder** in the VS Code file panel.

**Screenshot:** `pack-d-drag.png`

**Check:** the VS Code file panel now shows **`docs › project-planning`** with 4 files:
- `portfolio-tracker-brd.md`: the approved BRD
- `portfolio-tracker.md`: the approved PRD, the file for Step 9
- `portfolio-tracker-brd-to-prd-handoff.md`
- `portfolio-tracker-brd-v0.1.0.md`

If `project-planning` appears at the top level instead of inside `docs`, drag it onto `docs`.


## 14:40–15:05: guided read. Where to look

Each document is about 60 KB, so don't read it top to bottom. Links inside the BRD/PRD to `docs/` and `workshop/` files work. Links to `.copilot-tracking/…` agent session records don't open, because those records aren't part of this pack, and you don't need them. In VS Code, use **Cmd/Ctrl+F** with the search text, or **Ctrl+G** to go to the line number.

| What to find | BRD: `portfolio-tracker-brd.md` | PRD: `portfolio-tracker.md` |
|---|---|---|
| **1. The summary.** What it's for, the evidence (low confidence) and what was decided | `## Executive Summary` (line 35) | `## Executive Summary` (line 41) |
| **2. Scope and exclusions.** In, out and not specified | `### Scope and exclusions` (line 79) | `### Scope and exclusions` (line 120) and `### Deferred and alternative scope` (line 429) |
| **3. One trace, end to end:** valuation/FX provenance | `\| BR-007:` (line 214) in `## Functional Requirements` | `\| FR-007:` (line 194). Then `### BR-to-FR and inherited gate coverage` (line 349) shows `BR-007 → FR-007 → GATE-001, GATE-004, GATE-005, GATE-007` |
| **4. The gate register.** Each gate has all 8 Gate Record fields | `### Dependency and Validation Gate Register` (line 449). Start with `#### GATE-001` (FX provider) | `## Dependency and Validation Gate Register` (line 508). The same 7 gates, all **Open**, plus their FR mapping |
| **5. The SMART waiver.** Approval with an open governed dependency | `**SMART assessment: FAIL; scoped waiver WVR-001.**` (line 165), then `### Waivers` (line 583) | `### Waivers` (line 631): inherited WVR-001 plus the separate **WVR-PRD-001** |
| **6. What approval means** | `## Sign-Off` (line 550) | `## Sign-Off` (line 607): approved *for Epic/Feature decomposition only*, not for engineering |

The trace in row 3 is the same chain as `docs/WORKED-EXAMPLES.md`, with this run's real IDs.

**Discussion prompts:**
- Which statements are **Evidence** and which are **Decision (not evidence)**?
- Why can the BRD be approved while GATE-001…007 are open and SMART fails?
- What would be an *approval blocker* instead?

### Traceability at a glance

| FR | Capability | Traces to | Gates (all Open) |
|---|---|---|---|
| FR-001 | Attributable establishment | BR-001 | GATE-003, 005, 007 |
| FR-002 | Consolidated orientation | BR-002 | GATE-001, 003, 004, 005, 007 |
| FR-003 | Bounded factual history | BR-003 | GATE-003, 004, 005, 007 |
| FR-004 | Reviewed import maintenance | BR-004 | GATE-003, 005, 007 |
| FR-005 | Manual fallback | BR-005 | GATE-003, 005, 007 |
| FR-006 | Sourced price/FX updates | BR-006 | GATE-001, 004, 005, 007 |
| FR-007 | On-demand valuation provenance | BR-007 | GATE-001, 004, 005, 007 |
| FR-008 | Uncertainty and overview consistency | BR-008 | GATE-004, 005, 006, 007 |
| FR-009 | Conflict, cause and consequence preview | BR-009 | GATE-002, 003, 005, 007 |
| FR-010 | Evidence-backed known cause | BR-010 | GATE-002, 003, 004, 005, 007 |
| FR-011 | Current-only unknown cause | BR-011 | GATE-002, 003, 005, 007 |
| FR-012 | Recovery consequence continuity | BR-012 | GATE-002, 003, 004, 005, 007 |

| Gate | Topic |
|---|---|
| GATE-001 | FX/price provider coverage and licensing |
| GATE-002 | Representative-user validation of Iteration 2 recovery |
| GATE-003 | Import/baseline coverage and financial methodology |
| GATE-004 | Valuation/FX meaning, timing and uncertainty |
| GATE-005 | Outcome measurement |
| GATE-006 | Overview trust-status consistency (self-test origin) |
| GATE-007 | Viability and operating assumptions |

**Excluded:** trading, advice, forecasts, tax reporting, goal tracking, real personal data.
**Deferred alternatives:** composition breakdown; FX source/time on the main screen.

## At 15:05: Step 9 in a new PRD Builder chat (about 5 minutes for the agent)

1. Open a **new** Copilot Chat and select **PRD Builder** (`hve-core:prd-builder`). Don't reuse the DT Coach chat or any earlier chat.
2. Attach these three files with **Add Context** or `#file`:
   - `docs/project-planning/portfolio-tracker.md`
   - `docs/WORKED-EXAMPLES.md`
   - `docs/ARTIFACT-CHECKLIST.md`
3. Paste:

```text
The attached file is the approved PRD planning baseline (PRD-2026-Q4-001 v1.0.0, approved as the workshop product planning baseline for Epic/Feature decomposition). It includes its inherited exclusions and open gates GATE-001 to GATE-007. Do not rely on any earlier chat.

Create a planning-only Epic/Feature proposal from that baseline:
- Epics are outcomes; Features are capabilities. Epics and Features only — no Stories, Tasks, architecture, estimates, RPI or code.
- Every Feature traces to the PRD FR IDs (and through them to BR IDs) in the approved baseline.
- Deferred and excluded scope stays out (trading, advice, forecasts, tax reporting, goal tracking, real personal financial data; composition breakdown and main-screen FX remain deferred alternatives, not Features).
- Gated capabilities stay conditional: mark each affected Feature "conditional on GATE-00x" and show the gate status (Open). Don't close any gate.
- Do not edit the approved PRD. Do not hand off to a tracker or Functional Planner, and do not start a new PRD.
Save the proposal as docs/project-planning/portfolio-tracker-epic-feature-proposal.md and show me a short summary.
```

**What you'll see:**
- A new file, `docs/project-planning/portfolio-tracker-epic-feature-proposal.md`, with **3 outcome Epics and 12 Features**. Each Feature traces FR → BR and is marked "conditional on GATE-…" (Open).
- The approved PRD is unchanged.
- Epic names and Feature numbering vary from run to run. That's normal.

**If the agent:**
- creates Stories or Tasks: stop it and roll them back;
- edits the PRD or starts a new one: decline;
- offers a tracker or Functional Planner handoff: decline.
