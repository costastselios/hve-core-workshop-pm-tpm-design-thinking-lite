---
prd_id: "PRD-2026-Q4-001"
title: "Portfolio Tracker Product Requirements"
status: "approved"
version: "1.0.0"
owners: ["Workshop Product Owner (requesting user)"]
reviewers: ["Workshop Product Owner (requesting user)"]
created_date: "2026-11-17"
last_updated: "2026-11-17"
product_goal_ids: ["GOAL-001", "GOAL-002", "GOAL-003"]
product_goal_smart_status: "fail"
fr_to_ac_coverage_threshold_pct: 80.0
fr_to_goal_coverage_threshold_pct: 100.0
diagram_format: "none"
lineage:
  supersedes: []
  superseded_by: []
source_brd_id: "BRD-2026-Q4-001"
source_brd_version: "1.0.0"
source_brd_sha256: "f27dfb22983662d8bd903879eec5f97f10cacd0c6226cb685313c9e795690356"
requirement_id_prefixes:
  fr: "FR"
  ac: "AC"
  nfr: "NFR"
  con: "CON"
  goal: "GOAL"
  rule: "RULE"
  decision: "DD"
license: "CC-BY 4.0 (Microsoft HVE-Core)"
---

# Portfolio Tracker Product Requirements

> **PRD-2026-Q4-001** | Approved | Version 1.0.0 | 2026-11-17
>
> Approved by the Workshop Product Owner as the workshop product planning
> baseline for Epic/Feature decomposition only, under WVR-PRD-001.
> **Decision (not evidence):** Not validation, gate closure or engineering authorization.
> All seven inherited gates remain **Open**; all acceptance is **Not Started**.

## Executive Summary

Portfolio Tracker is intended to help a self-directed multi-broker investor
understand what is held, where, its factual dated value, how that value was
derived, and what remains uncertain. Sustainable maintenance and understandable
valuation are the intended benefits, not better investment performance.

**Evidence:** The approved BRD carries two supplied participant summaries with
low-confidence, directional signals only. The separate Iteration 1 supplied
participant-test summary reports recovery-comprehension problems but establishes
neither representative validation nor source independence. Iteration 2 has
Product Owner self-test only; its recovery model remains an **unvalidated
redesign hypothesis**, not verified financial processing.

**Decision (not evidence):** Elaborate the approved business scope into product
requirements without new discovery, architecture, implementation, RPI or tracker
upload. Import-first/manual fallback, AED reporting, on-demand provenance and
evidence-appropriate recovery remain workshop planning choices. The Product
Owner is the sole workshop planning-baseline sign-off authority, not a proxy
for investor evidence.

The primary candidate outcome measure is maintenance effort per comparable
portfolio-update task. Its protocol, baseline, meaningful target and evaluation
date are not established. No delivery horizon, budget, outcome target or SLO is
committed. This approved planning baseline records testable boundaries, not completed tests,
closed gates, a viable business case or engineering authorization.

## Product Context

### Authority and source receipt

The [approved BRD](portfolio-tracker-brd.md) is authoritative for business scope.
The [YAML handoff](../../.copilot-tracking/brd-sessions/portfolio-tracker.handoff.yml)
and [per-BR handoff](portfolio-tracker-brd-to-prd-handoff.md) supply the inherited
coverage, waiver, exclusions, decisions and complete gate records.

| Receipt field | Value |
| --- | --- |
| BRD identity / version | BRD-2026-Q4-001 / 1.0.0 |
| Approved BRD SHA-256 | `f27dfb22983662d8bd903879eec5f97f10cacd0c6226cb685313c9e795690356` |
| Handoff | BRD-2026-Q4-001-handoff-20261117T100033Z; schema BRD_TO_PRD_HANDOFF_V1 |
| Source approval | 2026-11-17T09:55:28.411Z; Workshop Product Owner; workshop BRD planning baseline only |
| Signoff / quality | WAIVED; Govern APPROVED_WITH_COMMENTS; overall quality FAIL; unwaived Define BLOCKED |
| Source counts | 12 BR capabilities, 17 AC, 3 NFR, 3 CON, 3 RULE, 3 BG |
| Source authored coverage | BR-to-AC 100.0%; BR-to-BG 100.0%; neither is execution coverage |
| Consumer validation | Hash, version, prefix map, counts, coverage, Govern report, signoff, WVR-001 and seven complete Open gate records checked against supplied artifacts |

WVR-001 accepts missing SMART evidence for the **workshop BRD planning baseline
only**. It is not extended to approve this PRD; the PO separately granted
WVR-PRD-001 and approved this product planning baseline on
2026-11-17T10:15:31.253Z, as **Decision (not evidence)**. No recorded expiry
trigger is exercised by this document-only elaboration; later consumers must
recheck the event-based expiry. The historical handoff's statements that its
production creates no PRD are producer-scope history, not instructions overriding
the current Product Owner request to create this PRD.

### Evidence labels and interpretation

The [BRD evidence/source register](portfolio-tracker-brd.md#evidence-and-source-register)
remains the source locator authority. Source IDs below retain those meanings;
this PRD adds no interviews, observations, market research or evidence receipts.

| Label / source | Permitted interpretation and limit |
| --- | --- |
| **Evidence:** P01 / P01-E1-E5 | Supplied single-participant summary, low confidence. Manual consolidation and trust concerns; occasional entry is not equivalent to P02's repetitive re-entry objection. No verbatim transcript, prevalence or validated benefit inferred. |
| **Evidence:** P02 / P02-E1-E4 | Supplied single-participant summary, low confidence. Import/review and automatic-input preferences; composition is participant-specific. Goal tracking from P01 remains excluded. |
| **Evidence:** I1 / DT-6A | Supplied Iteration 1 test summary, low-confidence directional signal: mechanical completion did not establish comprehension. Raw notes/run identity and independence from P01/P02 are not established; no participant count or success rate inferred. |
| **Evidence:** SELF | PO self-test only. Iteration 1 overview-status concern is self-test-origin, not a participant finding. Iteration 2 self-test is not representative-user evidence. Embedded participant references repeat I1. |
| **Decision (not evidence):** CAN; BRD DD-001 through DD-008; DT-6B D2 | Canonical concept, workshop choices, PO adoption of recovery and BRD approval/waiver. Adoption is not validation. |
| **Decision (not evidence):** PO approval and WVR-PRD-001, 2026-11-17T10:15:31.253Z | User reviewed the PRD against the skeleton, Decision Rubric and Artifact Checklist and found no document-repair blockers. Approves the workshop product planning baseline for Epic/Feature decomposition only; separate PRD SMART waiver. No evidence upgrade or gate closure. |
| **Assumption:** R2; BRD A-001 through A-005 | Iteration 2 recovery, sustainable maintenance, understandable provenance, feasible coverage and viability remain unvalidated or partially supported hypotheses. |
| **Open question:** BRD OQ-001 through OQ-008 | Unresolved product/coverage/measurement/viability decisions, carried below without assumed answers. |

The month-end spreadsheet story, stale-FX incident and multi-app market-growth
claim remain fictional or untested, not business-case facts. Market magnitude,
adoption, willingness to pay, operating costs and support burden are unknown.
Completed workshop DT methods are not retrospectively promoted to full research
or validation gate passes.

### Scope and exclusions

| Boundary | Product planning baseline |
| --- | --- |
| In scope, conditional | Attributable establishment; consolidated holdings; bounded factual dated history; reviewed imports; occasional manual fallback; sourced prices/FX; on-demand provenance; explicit uncertainty; conflict/cause/preview; evidence-backed known-cause recovery; current-only unknown-cause verification; later consequence continuity. |
| Fictional scenario | Self-directed investor without an adviser; three brokers; stocks, ETFs and some crypto; USD/EUR/AED inputs and AED reporting. These are scenario choices, not validated segment attributes or coverage commitments. GATE-001/003/004 remain Open. |
| Excluded | Trading/order execution; investment advice/recommendations; forecasts; tax reporting; goal tracking; real personal financial data. Factual recorded buys/sells are history, not trade execution. |
| Alternatives / deferred, not committed | Composition breakdown; main-screen FX source/as-of instead of baseline on-demand provenance. Neither has a delivery allocation. Fully connected/import-only and entirely manual operation are not selected baselines. |
| Dropped, not deferred | Silent overwrite of historical transactions to match today's position. Unknown cause does not authorize invented history. |
| Not specified or authorized | APIs, data models, integrations, storage, technology/provider choices, architecture, engineering tasks, delivery dates, budgets, production controls, numeric service commitments or tracker/backlog mutation. |

## Users and Personas

| Role | Job and tension | Intended success / authority |
| --- | --- | --- |
| STK-001: self-directed multi-broker investor | Establish, maintain and explain an attributable cross-broker record; avoid repetitive re-entry without losing source trust or concealing historical gaps. P01/P02 supply limited perspectives, not a representative persona. | Understand holdings, valuation basis, time and limits; distinguish current verification from known historical activity. All FR actors are this investor. |
| STK-002: Workshop Product Owner (requesting user) | Own scope, decisions, gates and acceptance review. Not a substitute research participant. | Sole accountable owner for each requirement, criterion, risk and gate; sole workshop planning-baseline signatory. |
| STK-003 / STK-004: brokers and price/FX sources | Potential evidence/coverage dependencies. Access, rights and involvement unverified. | Data sources, not assumed users, committed partners or signatories. No provider selected. |

Accountant/partner roles remain unconfirmed and outside current user scope.
Broader contexts and accessibility needs remain GATE-005 coverage gaps.
AED reporting does not establish a jurisdiction.

## Design Decisions

These are product scope/authoring decisions, not architecture. BRD DD-001 through
DD-008 remain unchanged in their source document; PRD-local DD IDs continue from
DD-009 to avoid confusing inherited and new decisions. Confidence describes
supporting evidence, not the accuracy of recording the user's instruction.

| ID / Decision | Basis | Confidence | Status | Impact | Remaining uncertainty |
| --- | --- | --- | --- | --- | --- |
| DD-009: Elaborate the approved scope without discovery, architecture, implementation, RPI or upload. | Current PO request; BRD DD-001/006; CON-003. | Explicit instruction; no new empirical evidence. | Adopted for PRD authoring. | File-only product requirements and governance; no provider selection. | Gate exit evidence remains absent. |
| DD-010: Assign stable FR IDs with explicit BR back-references; retain inherited AC/NFR/CON/RULE IDs with document-qualified source links. | Current PO request; BRD DD-005; both handoffs. | Authoring convention, not evidence. | Adopted. | Twelve product capability requirements map to twelve BRs; no source renumbering or duplicate BR aliases. | Financial/format details remain gate-dependent, not silently specified. |
| DD-011: Retain import-first/manual fallback, local AED scenario and on-demand provenance. | BRD DD-002/003; CAN; P01/P02 as qualified above. | Low empirical confidence. | Inherited workshop baseline. | FR-001 through FR-007; no composition or main-screen-FX commitment. | Coverage, affordability and comprehension: GATE-001/003/004/005/007. |
| DD-012: Retain adopted Iteration 2 as an unvalidated redesign hypothesis; unknown cause verifies today only; silent overwrite stays dropped. | BRD DD-004; I1; R2; DT-6B D2; SELF separately. | Low; self-test only for Iteration 2. | Inherited PO decision, not validation. | FR-009 through FR-012; preserve current/history distinction. | Known/unknown/mistaken-cause comprehension and correctness: GATE-002/003/004. |
| DD-013: Carry every gate Open; do not extend BRD approval or WVR-001 into unseen PRD approval. | Initial PO request; BRD DD-006/008; Gate Record; Decision Rubric. | Governance decision, not empirical evidence. | Adopted; separate explicit approval now recorded in DD-014. | No invented targets, waiver, gate closure or engineering authorization. | Measurement evidence remains absent; BRD waiver scope unchanged. |
| DD-014: Approve version 1.0.0 in place as the workshop product planning baseline for Epic/Feature decomposition only. | PO approval, 2026-11-17T10:15:31.253Z; user review against PRD skeleton, Decision Rubric and Artifact Checklist; no document-repair blockers. | Explicit PO decision, not empirical evidence. | Approved; Decision (not evidence). | All seven gates stay Open; no Functional Planner/tracker handoff or Epics, Features, Stories or Tasks created in this chat. Step 9 is separate. | No validation, gate closure, financial-correctness claim or engineering authorization; dependent evidence gaps remain. |
| DD-015: Grant separate PRD-scoped WVR-PRD-001 for non-SMART GOAL-001, GOAL-002 and GOAL-003. | PO waiver, 2026-11-17T10:15:31.253Z; no baselines/targets exist and none will be invented. | Explicit scoped waiver, not empirical evidence. | Granted by Workshop Product Owner; Decision (not evidence). | Workshop product planning baseline only; GATE-005 governance and event-based expiry; SMART remains FAIL. | Measurement decisions remain unresolved; no outcome-performance commitment or continuing-product waiver. |

## Product Goals

All goals are MUST, owned by STK-002 and inherited as intended outcomes, not
validated benefits. The separate GOAL namespace provides product-to-business
traceability without renaming the BRD goals.

| ID | Intended outcome | BRD goal | Candidate signal | SMART status |
| --- | --- | --- | --- | --- |
| GOAL-001 | Make maintaining a factual cross-broker record sustainable across purchase cadences. | BG-001 | Effort and repeated-entry steps per comparable update task. | FAIL; baseline, target, achievability and evaluation date not established; GATE-005/007. |
| GOAL-002 | Enable the investor to explain holdings, valuation/FX basis and as-of context without mistaking incomplete information for certainty. | BG-002 | Source/time/conversion/uncertainty explanation against a PO-approved rubric. | FAIL; rubric, baseline, target, achievability and evaluation date not established; GATE-004/005. |
| GOAL-003 | Enable evidence-appropriate recovery while distinguishing current correctness from historical completeness. | BG-003 | Cause judgment, pre-action prediction, post-action explanation and later interpretation. | FAIL; no measured baseline, agreed protocol/target, supported achievability or evaluation date; GATE-002/003/005. |

Specific and relevant intent is retained; missing measurement evidence is not
filled with invented values. BRD WVR-001 and the historical SMART FAIL are
preserved. The PO separately accepts these three product-goal gaps under
WVR-PRD-001 for this workshop product planning baseline only; SMART is not
relabelled PASS. GATE-005 remains Open.

## Functional Requirements

All FRs are **MUST** within the approved bounded planning baseline, owned by STK-002,
serve actor STK-001 and have acceptance status **Not Started**. MUST does not
mean feasible, funded or authorized for delivery. Every FR inherits CON-001
through CON-003 and GATE-005/007 in addition to its direct gates. The complete
per-FR gate set appears in Traceability Matrix; no table omission is an exemption.

| ID / capability | Trigger and observable obligation | Source BR / product goal | Acceptance |
| --- | --- | --- | --- |
| FR-001: Attributable establishment | When the investor submits a synthetic starting statement, the product shall present a reviewable starting-position proposal identifying broker/source, evidence date, asset, units, currency and missing/unsupported fields. The proposed baseline shall not assert earlier transaction history and shall take effect only after explicit confirmation. | BR-001; GOAL-001, GOAL-002 | AC-001, AC-002 |
| FR-002: Consolidated orientation | When the investor opens the established portfolio, the product shall present each holding's broker, asset type, native currency and dated AED valuation or explicit unvalued state. A total excluding any holding shall be labelled partial with its exclusions identifiable. | BR-002; GOAL-002 | AC-003 |
| FR-003: Bounded factual history | When the investor inspects history, the product shall distinguish attributable dated facts, corrections and unsupported intervals, without inventing pre-baseline activity or forecasts. | BR-003; GOAL-002, GOAL-003 | AC-004 |
| FR-004: Reviewed import maintenance | When the investor submits an update file, the product shall present proposed changes and record dispositions for ready, possible-duplicate, conflicting and unsupported records before explicit confirmation of the accepted set. Unresolved records shall not silently become accepted changes. | BR-004; GOAL-001 | AC-005, AC-006 |
| FR-005: Manual fallback | When import is unavailable or occasional manual maintenance is chosen, the product shall present a dated, source/manual-labelled change proposal with its intended effect for review and explicit confirmation. Unconfirmed proposals shall not change accepted information. | BR-005; GOAL-001 | AC-007 |
| FR-006: Sourced price/FX updates | When an update is requested within approved coverage, the product shall obtain available attributable price/FX inputs without requiring each price/rate to be re-keyed. Missing or unsupported inputs shall be explicitly unavailable, not invented or represented as fulfilled automation. | BR-006; GOAL-001, GOAL-002 | AC-008 |
| FR-007: On-demand valuation provenance | When the investor inspects a valuation, the product shall expose distinguishable position basis, price source/effective time, applicable FX source/effective time/rate direction, reporting currency and calculation basis, with explicit unavailable or non-applicable states. | BR-007; GOAL-002 | AC-009 |
| FR-008: Uncertainty and overview consistency | While inputs or history are stale, missing, disputed or incomplete, the product shall qualify affected holding values and portfolio summaries so fresh prices do not imply verified positions or complete history. Exact timing policy and status vocabulary remain unresolved. | BR-008; GOAL-002, GOAL-003 | AC-010, AC-011 |
| FR-009: Conflict, cause and consequence preview | When recovery is considered, the product shall present conflicting evidence and current/history implications before asking whether the cause is known, then present the selected branch's changes, non-changes and remaining uncertainty for review before confirmation. Either branch shall remain cancellable without applying the proposal. | BR-009; GOAL-003 | AC-012, AC-013 |
| FR-010: Evidence-backed known cause | When the investor supplies evidence of missing activity and confirms the preview, the product shall record that activity and recalculate only affected history under the agreed methodology. A quantity difference alone shall not establish cause; unrelated facts and other unresolved uncertainty shall remain unchanged. | BR-010; GOAL-003 | AC-014 |
| FR-011: Current-only unknown cause | When today's position is evidenced but its cause is unknown and the investor confirms the preview, the product shall record a dated, attributable current-position verification without rewriting historical transactions or inventing explanatory activity. | BR-011; GOAL-003 | AC-015 |
| FR-012: Recovery consequence continuity | When the investor reviews a recovery result or later revisits the holding/history, the product shall distinguish current verification, historical changes and unresolved historical uncertainty. A suspected mistaken-cause assertion shall remain evidence-traceable for a governed correction decision, not presented as established fact. | BR-012; GOAL-002, GOAL-003 | AC-016, AC-017 |

Financially sensitive acceptance uses future PO-approved synthetic expected
results and support boundaries under GATE-003/004. Unsupported-state handling
is a required boundary, not a blanket substitute for providing supported
behavior or for closing feasibility gates.

## Non-Functional Requirements

The three BRD quality obligations retain their IDs and meaning; no numeric
performance, availability or usability targets are added. The categories below
use the canonical PRD quality framing; extra result-integrity detail preserves
the BRD boundary rather than inventing a service metric. All are MUST,
owned by STK-002, **Not Started**, and inherit CON-001 through CON-003.

### Performance and Capacity

Not specified: no supported latency, update-frequency, load or volume evidence.
Any future commitment requires justified PO decisions under GATE-004/005/007.

### Reliability and Resilience

**NFR-003: Historical preservation during unknown-cause recovery.** In every
agreed synthetic unknown-cause case, historical transactions shall be identical
before and after confirmation, and unresolved history shall remain visible on
later review. Verify by before/after factual-record comparison and observed
outcomes, not fixed-data confirmation screens. Source: BRD NFR-003; BR-011/012;
FR-011/012; AC-015/016; GOAL-003; RULE-002; GATE-003/005/007.
This is a preservation invariant, not an availability or recovery-time promise.

### Security

No production-security posture, mechanism or certification is specified.
CON-002 prohibits real personal financial data in workshop inputs and outputs;
it is not a claim that production protection has been designed.

### Privacy

CON-002 requires safe synthetic/non-identifying workshop material only, with
no live holdings, credentials, balances or account identifiers. Future consent
and contextual coverage belong to GATE-002/005; no real-data collection is
authorized by this PRD.

### Scalability and Elasticity

Not specified: the fictional three-broker scenario is not a load/capacity target.

### Maintainability and Operability

No engineering-maintenance or operational-service promise. GATE-007 retains
support/correction burden, capacity and responsibilities as unresolved.
Stable document identifiers are governance, not a software architecture.

### Observability

No production telemetry or SLO requirement is introduced. User-inspectable
financial provenance is FR-007, not an internal logging or monitoring design.

### Usability and Accessibility

**NFR-002: Recovery-comprehension evidence boundary.** Before claiming recovery
comprehension validated, a PO-approved, consented representative-user protocol
shall record each tested person's conflict/cause interpretation, branch choice,
pre-action prediction, post-action explanation and later uncertain-history
interpretation for known, unknown and mistaken-cause scenarios. Report failures
and apply criteria agreed before testing; clicking completion or PO self-test
cannot substitute. Source: BRD NFR-002; FR-009 through FR-012; GOAL-003;
I1/R2/DT-6B; GATE-002/005/007. No success rate or accessibility conformance
level is invented; contextual/accessibility coverage remains GATE-005.
This specifies future validation evidence, not execution of research now.

### Compatibility and Interoperability

Compatibility remains conditional on the GATE-003 statement/history/format and
asset support matrix and explicit unsupported outcomes. No universal broker
compatibility, connection method or supported file-format list is promised.

### Portability

Not specified: no target platform, deployment environment or portability promise.

### Financial Result Integrity

**NFR-001: Reconciliation or explicit uncertainty.** For the finite synthetic
valuation/import/recovery case set approved under GATE-003/004, every case shall
reconcile with its independently reviewed expected result or show its documented
unsupported/uncertain state. No unexplained difference shall be represented as
verified. Verification is case-by-case comparison using precision, rounding and
tolerances decided in those gates, not this PRD. Source: BRD NFR-001;
BR-002/004/006/007/010/011; FR-002/004/006/007/010/011; GOAL-002/003;
RULE-001/002; GATE-001/003/004/005/007.
This preserves financial-result correctness, not a new analytics capability.

## Constraints

All are MUST, imposed by the Product Owner, owned by STK-002 and inherited from
the same-numbered BRD constraint. They apply to every FR, NFR, scenario and
acceptance condition; changing them requires an explicit PO scope revision.

| ID | Non-negotiable boundary | Category / acceptance effect |
| --- | --- | --- |
| CON-001 | No trading/order execution, investment advice/recommendations, forecasts, tax reporting or goal tracking. | Operational/scope. Review requirements and outputs for excluded behavior; factual recorded purchases/sales do not execute trades. Cost-basis uncertainty does not authorize tax or new analytics scope. |
| CON-002 | No real personal financial data. | Operational/data. Only safe synthetic/non-identifying material; no live holdings, credentials, balances or account identifiers. Stop processing unsafe material rather than copying it. |
| CON-003 | No architecture, implementation, restarted discovery or RPI research; no tracker upload or backlog execution. | Organizational/workflow. File-only product requirements and governance; no APIs, data models, technology/provider decisions, engineering tasks or new research. Current PO authorization permits this PRD; historical producer-only prohibitions on creating a PRD are not reinterpreted as current scope. |

### Inherited standing rules

These are **Decision (not evidence)** operational policies, not FR aliases.

| ID | Binding policy | Enforcing product requirements |
| --- | --- | --- |
| RULE-001 | Recorded facts remain attributable to evidence or explicitly identified as unsupported. | FR-001, FR-003, FR-005, FR-006, FR-007, FR-012 |
| RULE-002 | Today's position evidence does not prove unknown historical activity or historical completeness. | FR-003, FR-008, FR-009, FR-010, FR-011, FR-012 |
| RULE-003 | Proposed portfolio changes require review and confirmation before taking effect. | FR-001, FR-004, FR-005, FR-009, FR-010, FR-011 |

## Acceptance Criteria

All criteria are **Not Started**, not prototype results. PRD AC IDs preserve the
same-numbered [BRD AC](portfolio-tracker-brd.md#acceptance-criteria) boundary;
the Covers column names the product FR. Only agreed synthetic fixtures may be
used. Gate-dependent cases cannot be accepted as correct before the relevant
support/methodology decisions; passing a case never automatically closes a gate.

| ID | Given / When / Then acceptance boundary | Covers |
| --- | --- | --- |
| AC-001 | Given a synthetic starting statement, when the investor reviews its proposal, then each proposed holding shows broker/source, evidence date, asset, units, currency and explicit missing/unsupported fields; pre-statement transaction history is not asserted. | FR-001 |
| AC-002 | Given an unconfirmed baseline proposal, when the investor cancels, then no proposed starting position becomes the accepted baseline. | FR-001 |
| AC-003 | Given the agreed three-broker stock/ETF/crypto scenario, when the investor reviews consolidation, then every holding retains broker, type and native currency and a dated AED value or explicit unvalued state; a total excluding any holding is labelled partial with exclusions identifiable. | FR-002 |
| AC-004 | Given recorded dated activity and a position-only baseline with an unsupported earlier interval, when the investor inspects history, then that interval is identified as unsupported rather than populated with invented transactions and corrections are distinguished from original facts. | FR-003 |
| AC-005 | Given an import with ready, possible-duplicate, conflicting and unsupported records, when the investor reviews the accepted set, then each record has an explicit included/excluded/unresolved disposition and no unresolved record silently enters the accepted set. | FR-004 |
| AC-006 | Given a staged import, when the investor cancels before confirmation, then no staged change is applied. | FR-004 |
| AC-007 | Given occasional manual maintenance or unavailable import, when the investor proposes a dated change, then its source/manual status and intended effect are reviewable and cancellable before explicit confirmation; unconfirmed proposals do not change the accepted record. | FR-005 |
| AC-008 | Given coverage approved under GATE-001/004, when the investor requests an update, then available prices/FX arrive without re-keying each input and retain source/effective-time context; an unavailable input is explicitly unavailable rather than replaced by an invented value. | FR-006 |
| AC-009 | Given a native-currency or converted valuation, when the investor inspects provenance on demand, then position, price and applicable FX evidence/times, rate direction, reporting currency and calculation basis are distinguishable; unavailable evidence and non-applicable FX are explicitly identified. | FR-007 |
| AC-010 | Given missing or stale inputs under the approved timing policy, when the investor reviews valuation, then affected values and any portfolio total are qualified as partial/stale/uncertain as applicable rather than fully current and complete. | FR-008 |
| AC-011 | Given a holding with unresolved quantity mismatch or uncertain history and otherwise fresh prices, when the investor reviews overview status, then the exception is visible and price freshness does not assert unqualified position correctness or historical completeness. Exact vocabulary remains GATE-006. | FR-008 |
| AC-012 | Given conflicting position evidence, when the investor opens recovery, then both evidence positions and the reason for conflict are distinguishable from current versus historical consequences before a cause choice is requested. | FR-009 |
| AC-013 | Given either recovery branch, when the investor considers confirmation, then changes, non-changes and remaining uncertainty are reviewable and cancellation applies no proposed change. | FR-009 |
| AC-014 | Given evidence-backed missing activity under the agreed methodology, when the investor confirms known-cause recovery, then that activity is recorded and affected history recalculated; unrelated records are unchanged and other unexplained evidence stays uncertain. A quantity difference alone does not establish cause. | FR-010 |
| AC-015 | Given attributable evidence of today's position but no known cause, when the investor confirms unknown-cause verification, then today's verification is dated and source-linked, historical transactions are unchanged and no invented transaction explains the difference. | FR-011 |
| AC-016 | Given completed known- or unknown-cause recovery, when the investor inspects its result or later history, then changed/unchanged information and remaining uncertainty are identifiable; unknown-cause verification does not mark historical gain/loss or cost basis as verified. No gain/loss or cost-basis view is required. | FR-012 |
| AC-017 | Given a suspected mistaken-cause assertion during later review, when the investor inspects its evidence, then the assertion and affected history remain traceable for a governed correction decision rather than being presented as proven fact. The correction procedure must be agreed under GATE-003 and validated under GATE-002 before claiming this path ready. | FR-012 |

## Traceability Matrix

IDs are document-scoped: BR-### means source BRD capability; FR-### means this
PRD's product requirement. Same-numbered AC/NFR/CON/RULE records retain their
source meaning, not new independent evidence. BRD source/decision locators use
the [BRD evidence trace](portfolio-tracker-brd.md#dt-evidence-and-decision-traceability).

### BR-to-FR and inherited gate coverage

Every listed gate is **Open**. GATE-005 and GATE-007 are explicitly repeated per
FR so a downstream extract cannot lose baseline-wide dependencies.

| Source BR | Product FR | Evidence / decision basis (qualified above) | Full inherited gate set |
| --- | --- | --- | --- |
| BR-001 | FR-001 | P02-E2/E3; DT-5; BRD DD-003 | GATE-003, GATE-005, GATE-007 |
| BR-002 | FR-002 | P01-E1; P02-E1; DT-1; CAN; BRD DD-002/003 | GATE-001, GATE-003, GATE-004, GATE-005, GATE-007 |
| BR-003 | FR-003 | P01-E3; P02-E4; CAN; DT-5; BRD DD-002/004 | GATE-003, GATE-004, GATE-005, GATE-007 |
| BR-004 | FR-004 | P02-E2/E3; DT-3; CAN; BRD DD-003 | GATE-003, GATE-005, GATE-007 |
| BR-005 | FR-005 | P01-E4 versus P02-E2; DT-3; BRD DD-003 | GATE-003, GATE-005, GATE-007 |
| BR-006 | FR-006 | P01-E2; P02-E3; BRD DD-003 | GATE-001, GATE-004, GATE-005, GATE-007 |
| BR-007 | FR-007 | P01-E2; P02-E3; DT-1; CAN; BRD DD-002 | GATE-001, GATE-004, GATE-005, GATE-007 |
| BR-008 | FR-008 | CAN; SELF Iteration 1 only; DT-6C; BRD DD-002/004 | GATE-004, GATE-005, GATE-006, GATE-007 |
| BR-009 | FR-009 | I1; DT-6A; R2; BRD DD-004 | GATE-002, GATE-003, GATE-005, GATE-007 |
| BR-010 | FR-010 | R2; DT-6B; SELF separately; BRD DD-004 | GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 |
| BR-011 | FR-011 | R2; DT-6B D2; BRD DD-004 | GATE-002, GATE-003, GATE-005, GATE-007 |
| BR-012 | FR-012 | DT-6B; SELF Iteration 2 open questions; BRD DD-004 | GATE-002, GATE-003, GATE-004, GATE-005, GATE-007 |

BR-to-FR coverage: **12 / 12 = 100.0%**. Every FR has one explicit BR parent;
no excluded or deferred idea has been allocated an FR.

### FR-to-AC Coverage

| Source ID | Source title | Target IDs | Coverage |
| --- | --- | --- | --- |
| FR-001 | Establishment | AC-001, AC-002 | 2 |
| FR-002 | Consolidation | AC-003 | 1 |
| FR-003 | Factual history | AC-004 | 1 |
| FR-004 | Reviewed import | AC-005, AC-006 | 2 |
| FR-005 | Manual fallback | AC-007 | 1 |
| FR-006 | Sourced updates | AC-008 | 1 |
| FR-007 | Provenance | AC-009 | 1 |
| FR-008 | Uncertainty | AC-010, AC-011 | 2 |
| FR-009 | Conflict/preview | AC-012, AC-013 | 2 |
| FR-010 | Known cause | AC-014 | 1 |
| FR-011 | Unknown cause | AC-015 | 1 |
| FR-012 | Consequence continuity | AC-016, AC-017 | 2 |

Authored coverage: **12 / 12 = 100.0%**, above the 80.0% document threshold.
All seventeen ACs remain Not Started; this is not a test-pass rate.

### FR-to-GOAL Alignment

| Source ID | Target IDs | Coverage |
| --- | --- | --- |
| FR-001 | GOAL-001, GOAL-002 | 2 |
| FR-002 | GOAL-002 | 1 |
| FR-003 | GOAL-002, GOAL-003 | 2 |
| FR-004 | GOAL-001 | 1 |
| FR-005 | GOAL-001 | 1 |
| FR-006 | GOAL-001, GOAL-002 | 2 |
| FR-007 | GOAL-002 | 1 |
| FR-008 | GOAL-002, GOAL-003 | 2 |
| FR-009 | GOAL-003 | 1 |
| FR-010 | GOAL-003 | 1 |
| FR-011 | GOAL-003 | 1 |
| FR-012 | GOAL-002, GOAL-003 | 2 |

Authored alignment: **12 / 12 = 100.0%**, meeting the 100.0% target. GOAL-001,
GOAL-002 and GOAL-003 map respectively to BG-001, BG-002 and BG-003.
No relationship-coverage waiver is needed; SMART remains FAIL.

## MVP and Release Framing

**Decision (not evidence):** FR-001 through FR-012 define the conditional
workshop product scope, not a promised first release or an approved MVP. The
learning hypothesis is that sustainable maintenance with inspectable evidence
and explicit current/history limits can support factual understanding.
Its outcome criteria are not yet agreed, so this is not an MVP-validation claim.

No release sequence, first-release subset, delivery date or engineering cut line
has been authorized. No BR is silently deferred; all twelve are retained as
conditional planning requirements. Gate triggers govern any later readiness or
investment claim. The PO approved this PRD for Epic/Feature decomposition as a
workshop planning baseline only. Decomposition belongs to a separate Step 9
chat; no Functional Planner or tracker handoff and no Epics, Features, Stories
or Tasks are created here.

### Deferred and alternative scope

| Item | Disposition / rationale | Re-entry condition |
| --- | --- | --- |
| Composition breakdown | Alternative/deferred, no FR or release allocation; P02-specific signal, not general demand. | Explicit PO scope decision under GATE-005, preserving evidence limits. |
| Main-screen FX source/as-of | Alternative/deferred, no FR or release allocation; on-demand provenance remains baseline. | Explicit PO comparison/scope decision under GATE-005; timing/rights remain GATE-001/004. |
| Fully connected/import-only operation | Unselected alternative; no connection or import-only commitment. | Separate PO scope revision and applicable coverage/rights gates. |
| Entirely manual operation | Unselected alternative; occasional manual fallback remains FR-005. | Separate PO scope revision, not removal of import-first by assumption. |
| Gain/loss or cost-basis views | Not committed; recovery must not imply these are verified if discussed. No new analytics or tax scope. | Separate PO scope decision; applicable financial-methodology gates. |

Trading, advice, forecasts, tax reporting, goal tracking and real personal
financial data remain **excluded**, not a deferred release list.
Silent overwrite is **dropped**, not an alternative awaiting selection.

## Success Metrics

These are candidate evaluation signals inherited from the BRD, not production
telemetry, new KPI targets or financial-return promises. STK-002 owns all
measurement decisions. No measurements or research are executed by this task.

| Goal / candidate measure | Operational boundary / possible safe source | Baseline / target / window | Required decision |
| --- | --- | --- | --- |
| GOAL-001 / maintenance effort (primary) | Effort and repeated-entry steps for a comparable portfolio-update task; consented synthetic task observations and non-sensitive accounts of current practice. Comparable-task definition/protocol not agreed. | Baseline not measured; target not agreed; evaluation window/date not set. | GATE-005 defines protocol, meaningful comparison and decision criteria before outcome claims; GATE-007 retains viability. |
| GOAL-002 / factual explanation | Explanation of source, effective time, conversion and uncertainty during synthetic tasks, scored against a PO-approved rubric; source-located observations. Rubric not yet agreed. | Baseline not measured; rubric/target not agreed; evaluation window/date not set. | GATE-004/005 approve meaning and measurement before benefit claims. |
| GOAL-003 / recovery comprehension | Known, unknown and mistaken-cause tasks: pre-action prediction, cause/branch judgment, post-action explanation and later uncertain-history interpretation; consented source-located observations. Completion alone is insufficient. | I1 supplies a failure signal, not a rate baseline; target/protocol and evaluation window/date not set. | GATE-002/005 approve criteria before testing; GATE-003 retains financial-methodology limits. |

No percentage improvement, task-time target, sample size, SLO, evaluation date,
retention/adoption threshold or revenue forecast is invented. Neither WVR-001
nor WVR-PRD-001 authorizes outcome-performance commitments.

## Risks and Assumptions

### Key Assumptions

These retain the BRD assumption IDs, sources and low confidence. All mitigations
are owned by STK-002; gate work is future conditional work, not initiated here.

| ID | Assumption | Evidence status / source | Impact if false | Mitigation |
| --- | --- | --- | --- | --- |
| A-001 | Import-first/manual fallback reduces unacceptable upkeep across cadences. | Assumption; partially supported preferences, low confidence, not tested effectiveness; P01-E4, P02-E2/E3, DT-3. | Maintenance can add work or exclude actual practice. | GATE-003/005. |
| A-002 | Attributable price/FX and inspectable provenance improve factual understanding. | Assumption; directional signals, not causally demonstrated; P01-E2, P02-E3, CAN. | Automation/provenance may be misunderstood or uneconomic. | GATE-001/004/005/007. |
| A-003 | Iteration 2 enables sound cause judgment and understood recovery. | Assumption; PO self-test only, no Iteration 2 participant results; R2, SELF, DT-6B. | Completion may create misplaced certainty. | GATE-002/003. |
| A-004 | Statements/history support the local assets/currencies and fractional quantities. | Assumption; feasibility unverified; DT-5, DT-H; scenario not participant-validated. | Unsupported positions or misleading history. | GATE-001/003/004. |
| A-005 | Wider users/contexts and sustainable operation justify continuing. | Assumption; prevalence, adoption/payment and cost evidence absent; DT-H, DT-5 D/F/V. | Planning scope may not justify investment. | GATE-005/007. |

No RPI or feasibility handoff was supplied or activated. No RPI finding
disposition, feasibility candidate register, new research receipt or fabricated
evidence record is created.

### Risk Register

Probability is **unknown** for every risk; impacts are inherited planning
judgments, not measured frequencies. STK-002 owns each mitigation.

| ID | Risk | Potential impact | Mitigation |
| --- | --- | --- | --- |
| RISK-001 | Coverage/licensing/cost cannot support the scenario. | High: unavailable or unsustainable valuations. | GATE-001/007; explicit unsupported states; revise scope rather than presume rights. |
| RISK-002 | Recovery remains misunderstood, including mistaken-cause assertion. | High: current correctness mistaken for complete history. | GATE-002/003; prediction/explanation validation, no invented history. |
| RISK-003 | Imports/methodology mishandle duplicates, fractions, fees or corporate actions. | High: incorrect factual record. | GATE-003/004; reviewed expected-result cases and support boundaries before commitment. |
| RISK-004 | Fresh overview status masks missing inputs or unresolved mismatch/history. | High: misleading certainty. | GATE-004/006; distinguish freshness, current verification and history; no fix claimed. |
| RISK-005 | Summaries/self-tests or planning approval are promoted into evidence of demand/readiness. | High: unjustified product or delivery commitment. | Preserve source labels and GATE-005/007; PRD approval is planning-only, not validation or engineering authorization. |

## Open Questions

No new discovery questions are needed to author this bounded PRD. The inherited
questions remain **Open**, not answered, closed or silently deferred by authoring.
STK-002 owns each. Event-based triggers apply; no calendar due dates are invented.

| ID | Inherited unresolved decision | Decision point / status |
| --- | --- | --- |
| OQ-001 | Which assets/currencies/dates have lawful, sourceable, affordable price/FX coverage, limits and retention rights? | GATE-001 trigger / Open. |
| OQ-002 | Can representative users judge known/unknown/mistaken cause and explain current/history consequences, including later uncertainty? | GATE-002 trigger / Open. |
| OQ-003 | What statement/history/format support and rules cover fractions, duplicates, fees, corporate actions, corrections and unsupported cases? | GATE-003 trigger / Open. |
| OQ-004 | What cutoffs/timezones, crypto timing, rate direction, precision/rounding, stale/missing policy and uncertainty propagation are meaningful? | GATE-004 trigger / Open. |
| OQ-005 | What effort/comprehension measures, baselines, targets, dates and contextual/accessibility coverage are meaningful; are adjacent roles relevant? | GATE-005 trigger / Open. |
| OQ-006 | How should overview status distinguish fresh prices, verified positions and unresolved history? | GATE-006 trigger / Open; self-test-origin concern only. |
| OQ-007 | Are costs, support/correction burden, adoption/payment and operating responsibilities sustainable? | GATE-007 trigger / Open. |
| OQ-008 | Is a composition breakdown needed, and does main-screen FX improve understanding versus on-demand provenance? | Before scope expansion; GATE-005 / Open; both remain alternatives/deferred. |

## Dependency and Validation Gate Register

All eight [Gate Record](../GATE-RECORD.md) fields are reproduced per gate from the
approved handoff, with product FR mappings added to affected requirements.
Source BR/NFR/AC references retain their BRD meaning. No exit evidence has been
produced by writing this PRD; no gate is closed, waived or claimed resolved.
Open dependencies permit a bounded planning document, not dependent readiness,
validated behavior, financial correctness or outcome claims.

### GATE-001

- **Gate ID:** GATE-001
- **Title:** Price/FX provider coverage and licensing.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; availability and rights not committed.
- **Affected requirements/features:** BR-002, BR-006, BR-007; NFR-001; attributable AED valuation and sourced updates. Product mapping: FR-002, FR-006, FR-007; inherited NFR-001.
- **Exit evidence:** Dated provider/terms references; coverage matrix for agreed assets, currencies and dates; permitted use/display/retention and redistribution where relevant; access/rate limits, costs and explicit gaps; PO-recorded supported-scope/rights decision with specialist review where needed.
- **Next decision trigger:** Before committing provider-dependent valuation/automation features for engineering planning or claiming their coverage.
- **Remaining uncertainty:** Whether needed price/FX evidence can be obtained, used and retained at acceptable cost/frequency; no provider selected or rights verified.

### GATE-002

- **Gate ID:** GATE-002
- **Title:** Representative-user validation of Iteration 2 recovery.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; redesign hypothesis, self-test only.
- **Affected requirements/features:** BR-009, BR-010, BR-011, BR-012; NFR-002; conflict/cause/preview and consequence continuity. Product mapping: FR-009, FR-010, FR-011, FR-012; inherited NFR-002.
- **Exit evidence:** PO-approved protocol, participant/context rationale, consent and safe synthetic tasks; success criteria and evaluation date agreed before testing; source-located observations of conflict comprehension, cause judgment, branch choice, pre-action prediction, post-action explanation, mistaken-cause recovery and later uncertain-history interpretation; failures/limits and PO disposition recorded. Mechanical completion and PO self-test cannot substitute.
- **Next decision trigger:** Before claiming recovery comprehension validated or committing its dependent workflow as validated for engineering planning.
- **Remaining uncertainty:** Whether non-author representative users distinguish present from history, recognize unknown/mistaken cause and retain the correct uncertainty model later.

### GATE-003

- **Gate ID:** GATE-003
- **Title:** Import/baseline coverage and financial methodology.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; support boundaries and correction rules unverified.
- **Affected requirements/features:** BR-001, BR-002, BR-003, BR-004, BR-005, BR-009, BR-010, BR-011, BR-012; NFR-001, NFR-003; attributable establishment, maintenance and history. Product mapping: FR-001, FR-002, FR-003, FR-004, FR-005, FR-009, FR-010, FR-011, FR-012; inherited NFR-001/003.
- **Exit evidence:** Reviewed statement/history/format support matrix; synthetic expected-result cases for fractional quantities, duplicate/uncertain imports, fees, corporate actions, baseline-history gaps, unsupported assets/formats, evidence-backed missing activity, unknown cause and mistaken-cause correction; agreed correction/reversal procedure and relevant gain/loss/cost-basis limitations without tax scope; appropriate financial expertise and PO decision recorded.
- **Next decision trigger:** Before accepting import/history/recovery behavior as financially correct or committing dependent features for engineering planning.
- **Remaining uncertainty:** Statement sufficiency, historical availability, asset/format variation, duplicate/corporate-action logic, financial calculation rules and safe correction of mistaken causes.

### GATE-004

- **Gate ID:** GATE-004
- **Title:** Valuation/FX meaning, timing and uncertainty.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no agreed timing/precision/freshness policy.
- **Affected requirements/features:** BR-002, BR-003, BR-006, BR-007, BR-008, BR-010, BR-012; NFR-001; dated valuation/provenance and uncertain totals/history. Product mapping: FR-002, FR-003, FR-006, FR-007, FR-008, FR-010, FR-012; inherited NFR-001.
- **Exit evidence:** PO-approved definitions and reviewed synthetic cases covering completed-market price basis, cutoffs/timezones and crypto timing; price versus FX effective time, rate direction, precision/rounding/tolerances, stale/missing-input policy, partial totals and propagation of current/history uncertainty; provenance availability and unresolved exceptions explicitly recorded.
- **Next decision trigger:** Before claiming current/complete/correct AED valuations or committing valuation/history behavior for engineering planning.
- **Remaining uncertainty:** Which timing/FX policies are meaningful and sourceable, and how incomplete inputs and uncertain history constrain factual values.

### GATE-005

- **Gate ID:** GATE-005
- **Title:** Outcome measurement and broader-context coverage.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; goals fail SMART with workshop-only waiver WVR-001, no prevalence or measured benefit.
- **Affected requirements/features:** BR-001 through BR-012; NFR-002; BG-001, BG-002, BG-003; any proposed composition or main-screen-FX scope addition. Product mapping: every FR-001 through FR-012; inherited NFR-002; GOAL-001, GOAL-002, GOAL-003; retained alternatives are not committed.
- **Exit evidence:** PO-approved operational measures, safe baseline source/data, meaningful targets, evaluation dates and decision criteria for maintenance effort and factual/recovery understanding; documented user/context/accessibility coverage and adjacent-role disposition; explicit assessment of remaining generalizability limits. No prevalence/market-growth claim without appropriate separate evidence.
- **Next decision trigger:** Before adopting outcome-performance commitments, claiming broader demand/benefit, or approving expanded user/context scope.
- **Remaining uncertainty:** Actual magnitude, baseline effort, achievable improvement, representative contexts, adjacent roles and value of retained alternatives.

### GATE-006

- **Gate ID:** GATE-006
- **Title:** Overview trust-status consistency.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; self-test concern, no participant finding or verified fix.
- **Affected requirements/features:** BR-008; AC-011; portfolio/holding trust and freshness summaries. Product mapping: FR-008; inherited AC-011.
- **Exit evidence:** PO decision separating price freshness, position verification and historical completeness; synthetic mismatch/fresh-price/uncertain-history cases showing overview does not assert unqualified certainty and links affected holdings; source-located comprehension observations and failure dispositions. Preserve the self-test-only origin.
- **Next decision trigger:** Before accepting overview status semantics or claiming the reported inconsistency resolved.
- **Remaining uncertainty:** Appropriate summary vocabulary/aggregation and whether users interpret it correctly while unresolved exceptions remain.

### GATE-007

- **Gate ID:** GATE-007
- **Title:** Viability, support burden and operating assumptions.
- **Owner:** Workshop Product Owner (requesting user; STK-002).
- **Status:** Open; no viable operating model established.
- **Affected requirements/features:** BR-001 through BR-012; BG-001, BG-002, BG-003; continued investment in the proposed baseline. Product mapping: every FR-001 through FR-012; GOAL-001, GOAL-002, GOAL-003.
- **Exit evidence:** Documented provider/import/correction support costs and assumptions; operating/support responsibilities and capacity; non-sensitive adoption/payment evidence appropriate to the intended model; PO-recorded proceed/revise/stop decision with explicit remaining limits.
- **Next decision trigger:** Before treating this baseline as an investable business case, making operational commitments or authorizing engineering expenditure.
- **Remaining uncertainty:** Coverage/licensing economics, ongoing reconciliation/support effort, adoption/payment and who can sustain operation; no budget or service promise inferred.

## Glossary

| Term | Product meaning |
| --- | --- |
| Baseline | Accepted starting-position evidence, not proof of pre-baseline transactions. |
| Factual history | Attributable dated information with explicit coverage/uncertainty, not a forecast or completeness guarantee. |
| Known cause | Evidence-backed missing activity, not an inference from quantity difference alone. |
| Unknown cause / current verification | Today's evidenced position may be verified at a stated time without explaining or rewriting historical transactions. |
| Mistaken cause | A prior asserted explanation suspected to be wrong; correction methodology and comprehension remain GATE-003/002. |
| Provenance | Source, effective time and calculation context; attribution alone proves neither accuracy nor rights. |
| Partial total | Qualified valuation with identifiable exclusions, not a complete AED portfolio value. |
| Planning-baseline approval | PO acceptance of bounded product requirements/governance, not research validation, financial correctness, engineering authorization or expenditure approval. |

## Sign-Off

### Approval Checklist

| Review / decision | Authority and status |
| --- | --- |
| PRD product planning-baseline approval | **Approved** by Workshop Product Owner (requesting user; STK-002), sole sign-off authority, at 2026-11-17T10:15:31.253Z; workshop product planning baseline for Epic/Feature decomposition only. Decision (not evidence). |
| Source BRD approval | Approved 2026-11-17T09:55:28.411Z, workshop BRD baseline only; unchanged. |
| Content / traceability | Twelve FRs trace to twelve BRs; seventeen acceptance boundaries; three inherited NFRs, constraints and rules; three product-to-business goals. Authored coverage is not validation. |
| Evidence / dependencies | Low confidence retained; Iteration 2 remains an unvalidated redesign hypothesis; GATE-001 through GATE-007 Open. |
| Product Owner review / SMART disposition | PO reviewed goals/users, scope/exclusions, stable BR-linked FR IDs, testable boundaries, deferred scope, complete Open gates and no architecture against the workshop overlays; no document-repair blockers. Grants WVR-PRD-001 for the three non-SMART product goals, not a SMART PASS. |
| Technical / financial / provider-rights approval | Not granted or implied; no specialist signatory invented. Evidence/decisions belong to applicable gates. |

PRD approval date: **2026-11-17T10:15:31.253Z**
(2026-11-17T14:15:31.253+04:00). Version **1.0.0 / Approved**.
Authority: **Workshop Product Owner (requesting user; STK-002)**.
Scope: **workshop product planning baseline for Epic/Feature decomposition only**.
Label: **Decision (not evidence)**.

This approval is not validation, gate closure, financial-correctness approval,
engineering authorization, expenditure approval or an operational commitment.
All acceptance remains Not Started. No new discovery, architecture, RPI,
Functional Planner/tracker handoff or work-item creation is authorized here.

### Waivers

| Field | Inherited WVR-001 |
| --- | --- |
| Scope | Non-SMART BG-001, BG-002 and BG-003; source Define findings req-qual-022/023/024 and corresponding Govern SMART findings; **workshop BRD planning baseline only**. Related product GOAL-001/002/003 retain the same gaps. |
| Owner / grantor | Workshop Product Owner (requesting user; STK-002). |
| Decision / date | Granted in the BRD as Decision (not evidence), 2026-11-17T09:55:28.411Z. |
| Rationale | No baselines or targets exist and none will be invented. |
| Governance / expiry | GATE-005 remains Open. Expires at its next decision trigger or before any outcome-performance commitment, whichever occurs first. Event-based; no calendar expiry invented. |
| Limits | Not SMART compliance, research validation, gate closure, financial-correctness approval, engineering/expenditure authorization or a new PRD waiver. |
| PRD waiver status | WVR-001 is unchanged and not extended; separate WVR-PRD-001 below is explicitly granted, not inferred. No relationship-coverage waiver needed. |

| Field | WVR-PRD-001 |
| --- | --- |
| Scope / covered findings | Non-SMART GOAL-001, GOAL-002 and GOAL-003; initial Validate findings prd-qual-020, prd-qual-021 and prd-qual-022 and corresponding Finalize SMART findings. Workshop product planning baseline for Epic/Feature decomposition only. |
| Owner / grantor | Workshop Product Owner (requesting user; STK-002). |
| Decision / date | Granted explicitly as Decision (not evidence), 2026-11-17T10:15:31.253Z. Separate from BRD-scoped WVR-001. |
| Rationale | No baselines/targets exist and we will not invent them. |
| Governance | GATE-005, which remains Open with its full exit evidence and trigger unchanged. |
| Expiry | At the GATE-005 next decision trigger or before any outcome-performance commitment, whichever occurs first. Event-based; no calendar expiry invented. |
| Limits | Not SMART compliance, research or representative-user validation, gate closure, financial correctness, engineering/expenditure authorization, production readiness or an ongoing-product waiver. Does not waive traceability or close any GATE-001 through GATE-007. |

### Quality Review and Handoff Readiness

The initial [standard findings](../../.copilot-tracking/prd-sessions/portfolio-tracker.standard-findings.yml)
and [quality report](../../.copilot-tracking/prd-sessions/portfolio-tracker.quality-report.yml)
remain unchanged: **FAIL / Validate BLOCKED / Finalize NOT_EVALUATED** for
version 0.1.0 due to prd-qual-020/021/022. No document-repair blocker was found.
The PO now explicitly dispositions those gaps under WVR-PRD-001; their SMART
assessment is not relabelled PASS.

The separate [Finalize findings](../../.copilot-tracking/prd-sessions/portfolio-tracker.finalize-standard-findings.yml)
and [Finalize quality report](../../.copilot-tracking/prd-sessions/portfolio-tracker.finalize-quality-report.yml)
record the version 1.0.0 approval/waiver and drift assessment. The report alone
owns lifecycle gate decisions: **FAIL / Validate BLOCKED / Finalize
APPROVED_WITH_COMMENTS**. WVR-PRD-001 covers all three blocking SMART gaps for
this planning baseline; no unwaived blocker remains. The parent-owned Finalize
rollup uses the initial reviewer findings and exact approval-only drift checks;
the fresh reviewer invocation was blocked on contract access and emitted no
payload. This does not rewrite the initial review or close any inherited gate.

This approved PRD is saved in place for the separate Step 9 chat, not handed
off in this chat. No Functional Planner or tracker handoff, Epics, Features,
Stories, Tasks, upload or RPI segment is created.
The persistent [session state](../../.copilot-tracking/prd-sessions/portfolio-tracker.state.json)
records source validation, review results and pending decisions.

## Disclaimer

> [!CAUTION]
> **Disclaimer:** This agent is an assistive tool only. It does not provide product management approval, technical feasibility validation, or business sign-off and does not replace product managers, engineering leads, business stakeholders, or other qualified human reviewers. The output consists of suggested requirements, acceptance criteria, and product specifications to support a user's own product planning and decision-making. All Product Requirements Documents, functional requirements, non-functional requirements, and constraint definitions generated by this tool must be independently reviewed and validated by appropriate product and engineering reviewers before adoption. Outputs from this tool do not constitute product approval, requirements sign-off, or engineering commitment.

## Document Metadata

- Template Version: 1.0.0; canonical `requirements-author/templates/prd/prd-full.md`.
- Local overlay: [PRD skeleton](../../workshop/05-common/PRD-SKELETON.md),
  [Decision Rubric](../DECISION-RUBRIC.md),
  [Artifact Checklist](../ARTIFACT-CHECKLIST.md) and [Gate Record](../GATE-RECORD.md).
- Process diagrams omitted (`diagram_format: none`); no architecture authorized.
- Source BRD and both handoffs are authoritative as qualified in the source receipt;
  no new discovery or research sources introduced.
- License: CC-BY 4.0 (Microsoft HVE-Core).
- Template attribution: Microsoft HVE-Core Team.
